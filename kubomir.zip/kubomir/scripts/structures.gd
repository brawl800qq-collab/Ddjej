class_name Structures
extends RefCounted
## Деревни и затонувшие корабли. Всё детерминировано от сида: каждый чанк строит свою часть сам.

const VCELL := 8          # размер ячейки деревни в чанках (128 блоков)
const SEA := 24
const R := 26             # радиус деревни


class Ctx:
	var d: PackedByteArray
	var wx0: int
	var wz0: int
	var chests: Array = []
	var spawns: Array = []

	func inside(x: int, z: int) -> bool:
		return x >= wx0 and x < wx0 + 16 and z >= wz0 and z < wz0 + 16

	func put_chest(x: int, y: int, z: int, table: Array, lo: int, hi: int) -> void:
		if not inside(x, z):
			return
		put(x, y, z, G.CHEST)
		var r := RandomNumberGenerator.new()
		r.seed = (x * 73856093) ^ (z * 19349663) ^ (y * 83492791)
		chests.append([Vector3i(x, y, z), Loot.roll(r, table, lo, hi)])

	func spawn(kind: String, x: float, y: float, z: float) -> void:
		if inside(floori(x), floori(z)):
			spawns.append([kind, Vector3(x, y, z)])

	func put(x: int, y: int, z: int, id: int) -> void:
		var lx := x - wx0
		var lz := z - wz0
		if lx < 0 or lx >= 16 or lz < 0 or lz >= 16 or y < 0 or y >= 64:
			return
		d[lx + lz * 16 + y * 256] = id

	func at(x: int, y: int, z: int) -> int:
		var lx := x - wx0
		var lz := z - wz0
		if lx < 0 or lx >= 16 or lz < 0 or lz >= 16 or y < 0 or y >= 64:
			return -1
		return d[lx + lz * 16 + y * 256]

	## выровнять область под уровень g: срезать верх, досыпать низ
	func pad(x0: int, z0: int, x1: int, z1: int, g: int, top: int, mix: int) -> void:
		var ax := maxi(x0, wx0)
		var bx := mini(x1, wx0 + 15)
		var az := maxi(z0, wz0)
		var bz := mini(z1, wz0 + 15)
		for z in range(az, bz + 1):
			for x in range(ax, bx + 1):
				var lx := x - wx0
				var lz := z - wz0
				for y in range(g + 1, mini(g + 17, 64)):
					d[lx + lz * 16 + y * 256] = 0
				var yy := g - 1
				var n := 0
				while yy > 0 and n < 14:
					var i := lx + lz * 16 + yy * 256
					var v := d[i]
					if v == 0 or v == 9 or v == 27 or v == 28 or v == 29 or v == 33 or v == 35 or v == 36 or v == 37:
						d[i] = 2
					else:
						break
					yy -= 1
					n += 1
				var t := top
				if mix > 0 and ((x * 7 + z * 13) & 7) < mix:
					t = 8
				d[lx + lz * 16 + g * 256] = t


static func village_for_cell(gen: WorldGen, cx: int, cz: int) -> Dictionary:
	var h := gen._ih(cx, cz, 77)
	if h % 100 >= 24:
		return {}
	var px := cx * VCELL * 16 + 40 + gen._ih(cx, cz, 78) % 48
	var pz := cz * VCELL * 16 + 40 + gen._ih(cx, cz, 79) % 48
	var info := gen.col_info(px, pz)
	var b := info.y
	if info.x <= SEA + 1 or info.x > SEA + 14:
		return {}
	if not (b == WorldGen.B_PLAINS or b == WorldGen.B_FOREST or b == WorldGen.B_DESERT or b == WorldGen.B_SNOW or b == WorldGen.B_BIRCH or b == WorldGen.B_MEADOW):
		return {}
	var mn := info.x
	var mx := info.x
	for dx in [-24, 0, 24]:
		for dz in [-24, 0, 24]:
			var ci := gen.col_info(px + dx, pz + dz)
			if ci.x <= SEA or ci.y == WorldGen.B_OCEAN or ci.y == WorldGen.B_SWAMP:
				return {}
			mn = mini(mn, ci.x)
			mx = maxi(mx, ci.x)
	if mx - mn > 7:
		return {}
	var style := 0
	if b == WorldGen.B_DESERT:
		style = 1
	elif b == WorldGen.B_SNOW:
		style = 2
	return {"x": px, "z": pz, "g": info.x, "seed": h, "style": style}


static func in_village(vil: Dictionary, wx: int, wz: int, margin: int) -> bool:
	return absi(wx - int(vil.x)) <= R + margin and absi(wz - int(vil.z)) <= R + margin


# ------------------------------------------------------------------
static func layout(vil: Dictionary) -> Array:
	var rng := RandomNumberGenerator.new()
	rng.seed = vil.seed
	var cx: int = vil.x
	var cz: int = vil.z
	var res := []
	var types := [0, 0, 0, 1, 1, 2, 4, 4, 5, 7, 7, 6, 0, 1]
	var want := 6 + rng.randi() % 6
	var has_tower := false
	var has_smith := false
	var tries := 0
	if rng.randf() < 0.6:
		types = [3] + types
	while res.size() < want and tries < 120:
		tries += 1
		var t: int = types[rng.randi() % types.size()] if tries > 1 or res.size() > 0 else (3 if rng.randf() < 0.5 else 0)
		if t == 3 and has_tower:
			continue
		if t == 2 and has_smith:
			continue
		var w := 7
		var d := 6
		var floors := 1
		match t:
			0:
				w = 7 + rng.randi() % 3
				d = 5 + rng.randi() % 2
			1:
				w = 7
				d = 7
				floors = 2
			2:
				w = 8
				d = 6
			3:
				w = 5
				d = 5
			4:
				w = 9
				d = 7
			5:
				w = 5
				d = 3
			6:
				w = 5
				d = 5
			7:
				w = 7
				d = 7
		var x0 := cx - 24 + rng.randi() % (49 - w)
		var z0 := cz - 24 + rng.randi() % (49 - d)
		if x0 <= cx + 3 and x0 + w - 1 >= cx - 3:
			continue
		if z0 <= cz + 3 and z0 + d - 1 >= cz - 3:
			continue
		var ok := true
		for o in res:
			if x0 <= o.x + o.w + 1 and x0 + w + 1 >= o.x and z0 <= o.z + o.d + 1 and z0 + d + 1 >= o.z:
				ok = false
				break
		if not ok:
			continue
		var bx := x0 + w / 2 - cx
		var bz := z0 + d / 2 - cz
		var side := 0
		if absi(bx) < absi(bz):
			side = 2 if bx > 0 else 3
		else:
			side = 0 if bz > 0 else 1
		if t == 3:
			has_tower = true
		if t == 2:
			has_smith = true
		res.append({"t": t, "x": x0, "z": z0, "w": w, "d": d, "floors": floors, "side": side, "s": rng.randi()})
	return res


static func _mats(style: int, rng: RandomNumberGenerator) -> Dictionary:
	var m := {}
	if style == 1:
		m.wall = G.SANDSTONE
		m.corner = G.SANDSTONE if rng.randf() < 0.5 else G.LOG
		m.floor = G.SANDSTONE
		m.roof = G.SANDSTONE if rng.randf() < 0.6 else G.PLANKS
		m.flat = rng.randf() < 0.7
	elif style == 2:
		var wl := [G.PLANKS, G.COBBLE, G.PLANKS, G.STONE_BRICKS]
		m.wall = wl[rng.randi() % wl.size()]
		m.corner = G.SPRUCE_LOG
		m.floor = G.PLANKS
		var rl := [G.WOOL, G.COBBLE, G.SPRUCE_LOG]
		m.roof = rl[rng.randi() % rl.size()]
		m.flat = false
	else:
		var wl2 := [G.PLANKS, G.COBBLE, G.PLANKS, G.WOOL, G.STONE_BRICKS]
		m.wall = wl2[rng.randi() % wl2.size()]
		m.corner = G.LOG if rng.randf() < 0.7 else G.BIRCH_LOG
		m.floor = G.PLANKS
		var rl2 := [G.PLANKS, G.COBBLE, G.WOOL, G.STONE_BRICKS, G.SPRUCE_LOG]
		m.roof = rl2[rng.randi() % rl2.size()]
		m.flat = rng.randf() < 0.18
	return m


static func apply_village(gen: WorldGen, d: PackedByteArray, vil: Dictionary, wx0: int, wz0: int, tops: PackedInt32Array, spawns: Array, chests: Array) -> void:
	var cx: int = vil.x
	var cz: int = vil.z
	if wx0 + 15 < cx - R - 3 or wx0 > cx + R + 3 or wz0 + 15 < cz - R - 3 or wz0 > cz + R + 3:
		return
	var c := Ctx.new()
	c.d = d
	c.wx0 = wx0
	c.wz0 = wz0
	c.chests = chests
	c.spawns = spawns
	var g: int = vil.g
	var style: int = vil.style
	var top_id := G.GRASS
	var path_id := G.GRAVEL
	var mix := 2
	if style == 1:
		top_id = G.SAND
		path_id = G.SANDSTONE
		mix = 0
	elif style == 2:
		top_id = G.SNOW
	# дороги
	c.pad(cx - 1, cz - R, cx + 1, cz + R, g, path_id, mix)
	c.pad(cx - R, cz - 1, cx + R, cz + 1, g, path_id, mix)
	_well(c, cx, cz, g, path_id)
	# фонари вдоль дорог
	c.spawn("golem", cx + 3.5, g + 1.2, cz + 3.5)
	for k in [-18, -9, 9, 18]:
		_lamp(c, cx + k, cz + 2, g)
		_lamp(c, cx - 2, cz + k, g)
	for b in layout(vil):
		var bx0: int = b.x
		var bz0: int = b.z
		if bx0 + b.w + 2 < wx0 or bx0 - 2 > wx0 + 15 or bz0 + b.d + 2 < wz0 or bz0 - 2 > wz0 + 15:
			continue
		var rng := RandomNumberGenerator.new()
		rng.seed = b.s
		var m := _mats(style, rng)
		match int(b.t):
			3:
				c.pad(bx0 - 1, bz0 - 1, bx0 + b.w, bz0 + b.d, g, top_id, 0)
				_tower(c, b, g, style)
			4:
				c.pad(bx0 - 1, bz0 - 1, bx0 + b.w, bz0 + b.d, g, top_id, 0)
				_farm(c, b, g, rng)
			5:
				c.pad(bx0 - 1, bz0 - 1, bx0 + b.w, bz0 + b.d, g, top_id, 0)
				_stall(c, b, g, rng)
			7:
				c.pad(bx0 - 1, bz0 - 1, bx0 + b.w, bz0 + b.d, g, top_id, 0)
				_pen(c, b, g, rng)
			_:
				c.pad(bx0 - 1, bz0 - 1, bx0 + b.w, bz0 + b.d, g, top_id, 0)
				_house(c, b, g, m, rng)


static func _p(c: Ctx, sw: bool, a: int, y: int, b: int, id: int) -> void:
	if sw:
		c.put(a, y, b, id)
	else:
		c.put(b, y, a, id)


static func _well(c: Ctx, cx: int, cz: int, g: int, path_id: int) -> void:
	c.pad(cx - 2, cz - 2, cx + 2, cz + 2, g, path_id, 2)
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			if dx == 0 and dz == 0:
				c.put(cx, g, cz, G.WATER)
				c.put(cx, g - 1, cz, G.WATER)
				c.put(cx, g - 2, cz, G.WATER)
			else:
				c.put(cx + dx, g, cz + dz, G.COBBLE)
				c.put(cx + dx, g + 1, cz + dz, G.COBBLE if (dx == 0 or dz == 0) else G.LOG)
	for sx in [-1, 1]:
		for sz in [-1, 1]:
			c.put(cx + sx, g + 2, cz + sz, G.LOG)
			c.put(cx + sx, g + 3, cz + sz, G.LOG)
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			c.put(cx + dx, g + 4, cz + dz, G.PLANKS)
	c.put(cx, g + 5, cz, G.PLANKS)


static func _lamp(c: Ctx, x: int, z: int, g: int) -> void:
	c.put(x, g + 1, z, G.FENCE)
	c.put(x, g + 2, z, G.FENCE)
	c.put(x, g + 3, z, G.TORCH)


static func _house(c: Ctx, b: Dictionary, g: int, m: Dictionary, rng: RandomNumberGenerator) -> void:
	var x0: int = b.x
	var z0: int = b.z
	var w: int = b.w
	var d: int = b.d
	var fl: int = b.floors
	var H := fl * 4
	var wall: int = m.wall
	var corner: int = m.corner
	var flr: int = m.floor
	var roof: int = m.roof
	var side: int = b.side
	var ddx := x0 + w / 2
	var ddz := z0
	match side:
		1:
			ddz = z0 + d - 1
		2:
			ddx = x0
			ddz = z0 + d / 2
		3:
			ddx = x0 + w - 1
			ddz = z0 + d / 2
	# пол и очистка объёма
	for z in range(z0, z0 + d):
		for x in range(x0, x0 + w):
			c.put(x, g, z, flr)
			for y in range(g + 1, g + H + 3):
				c.put(x, y, z, 0)
	# стены
	for y in range(1, H + 1):
		for z in range(z0, z0 + d):
			for x in range(x0, x0 + w):
				var edge := x == x0 or x == x0 + w - 1 or z == z0 or z == z0 + d - 1
				if not edge:
					continue
				var is_c := (x == x0 or x == x0 + w - 1) and (z == z0 or z == z0 + d - 1)
				var id := wall
				if is_c:
					id = corner
				elif y % 4 == 0:
					id = corner
				elif y % 4 == 2 and (x + z) % 3 == 0 and not (x == ddx and z == ddz):
					id = G.GLASS
				if x == ddx and z == ddz and y <= 2:
					id = G.DOOR_BASE + (0 if side < 2 else 1) + (4 if y == 2 else 0)
				c.put(x, g + y, z, id)
	# ступенька у двери
	var stx := ddx
	var stz := ddz
	match side:
		0:
			stz -= 1
		1:
			stz += 1
		2:
			stx -= 1
		3:
			stx += 1
	c.put(stx, g, stz, G.SLAB_BASE + 1)
	# перекрытия
	var levels := [H]
	if fl == 2:
		levels = [4, H]
	for ly in levels:
		for z in range(z0 + 1, z0 + d - 1):
			for x in range(x0 + 1, x0 + w - 1):
				if fl == 2 and ly == 4 and z == z0 + 1 and x >= x0 + 1 and x <= x0 + 3:
					continue
				c.put(x, g + ly, z, flr)
	if fl == 2:
		for i in 3:
			for y in range(1, i + 2):
				c.put(x0 + 1 + i, g + y, z0 + 1, G.PLANKS)
	# обстановка
	var bedx := x0 + w - 2
	var bedz := z0 + d - 2
	c.put(bedx, g + 1, bedz, G.BED)
	c.put(bedx, g + 1, bedz - 1, G.BED_HEAD)
	c.put(x0 + 1, g + 1, z0 + d - 2, G.TABLE)
	c.put(x0 + 1, g + 2, z0 + d - 2, G.TORCH)
	if int(b.t) == 2 or rng.randf() < 0.55:
		c.put_chest(x0 + w - 2, g + 1, z0 + 1, Loot.VILLAGE, 2, 5)
	if rng.randf() < 0.3:
		c.put(x0 + w - 3, g + 1, z0 + 1, G.HAY)
	c.spawn("villager", x0 + w / 2 + 0.5, g + 1.2, z0 + d / 2 + 0.5)
	if fl == 2:
		c.put(bedx, g + 5, bedz, G.BED)
		c.put(bedx, g + 5, bedz - 1, G.BED_HEAD)
		c.put(x0 + w - 2, g + 5, z0 + 2, G.TORCH)
	# крыша
	if m.flat:
		for z in range(z0 - 1, z0 + d + 1):
			for x in range(x0 - 1, x0 + w + 1):
				var rim := x == x0 - 1 or x == x0 + w or z == z0 - 1 or z == z0 + d
				c.put(x, g + H + 1, z, roof)
				if not rim and (x == x0 or x == x0 + w - 1 or z == z0 or z == z0 + d - 1):
					c.put(x, g + H + 2, z, wall)
	else:
		_roof(c, x0, z0, w, d, g + H + 1, roof, wall)
	# кузница-подобные дополнения случайно
	if int(b.t) == 2:
		c.put(x0 + 1, g + 1, z0 + 1, G.FURNACE)
		c.put(x0 + 2, g + 1, z0 + 1, G.FURNACE)
		for y in range(H, H + 6):
			c.put(x0 + 1, g + y, z0 + 1, G.COBBLE)
	elif rng.randf() < 0.4:
		# цветник у входа
		c.put(x0 - 1 if side != 2 else x0 - 1, g + 1, z0 - 1, G.FLOWER_PINK)
		c.put(x0 + w, g + 1, z0 + d, G.FLOWER_BLUE)


static func _stair_idx(id: int) -> int:
	if id == G.PLANKS:
		return 0
	if id == G.COBBLE:
		return 1
	if id == G.STONE_BRICKS:
		return 2
	if id == G.SANDSTONE:
		return 3
	return -1


static func _roof(c: Ctx, x0: int, z0: int, w: int, d: int, y0: int, roof: int, gable: int) -> void:
	var sw := d > w
	var a0 := x0 if sw else z0
	var al := w if sw else d
	var b0 := z0 if sw else x0
	var bl := d if sw else w
	var k := 0
	while k < 8:
		var za := a0 - 1 + k
		var zb := a0 + al - k
		if za > zb:
			break
		for bb in range(b0 - 1, b0 + bl + 1):
			for aa in range(za, zb + 1):
				if aa < za + 2 or aa > zb - 2:
					var rid := roof
					var si := _stair_idx(roof)
					if si >= 0 and (aa == za or aa == zb) and k < 7:
						var low := aa == za
						var f := 0
						if sw:
							f = 3 if low else 2
						else:
							f = 1 if low else 0
						rid = G.STAIR_BASE + si * 4 + f
					_p(c, sw, aa, y0 + k, bb, rid)
		for bb in [b0, b0 + bl - 1]:
			for aa in range(za + 2, zb - 1):
				_p(c, sw, aa, y0 + k, bb, gable)
		k += 1


static func _tower(c: Ctx, b: Dictionary, g: int, style: int) -> void:
	var x0: int = b.x
	var z0: int = b.z
	var side: int = b.side
	var wall := G.STONE_BRICKS if style != 1 else G.SANDSTONE
	var ddx := x0 + 2
	var ddz := z0
	match side:
		1:
			ddz = z0 + 4
		2:
			ddx = x0
			ddz = z0 + 2
		3:
			ddx = x0 + 4
			ddz = z0 + 2
	for z in range(z0, z0 + 5):
		for x in range(x0, x0 + 5):
			c.put(x, g, z, G.PLANKS)
			for y in range(g + 1, g + 17):
				c.put(x, y, z, 0)
	for y in range(1, 10):
		for z in range(z0, z0 + 5):
			for x in range(x0, x0 + 5):
				if not (x == x0 or x == x0 + 4 or z == z0 or z == z0 + 4):
					continue
				var id := wall
				var is_c := (x == x0 or x == x0 + 4) and (z == z0 or z == z0 + 4)
				if is_c:
					id = G.LOG
				elif (y == 3 or y == 6) and (x == x0 + 2 or z == z0 + 2):
					id = G.GLASS
				if x == ddx and z == ddz and y <= 2:
					id = G.DOOR_BASE + (0 if side < 2 else 1) + (4 if y == 2 else 0)
				c.put(x, g + y, z, id)
	# винтовая лестница по кольцу 3x3
	var ring := [Vector2i(1, 1), Vector2i(2, 1), Vector2i(3, 1), Vector2i(3, 2), Vector2i(3, 3), Vector2i(2, 3), Vector2i(1, 3), Vector2i(1, 2)]
	for i in 8:
		var rv: Vector2i = ring[i]
		for y in range(1, i + 2):
			c.put(x0 + rv.x, g + y, z0 + rv.y, G.PLANKS)
	# площадка колокольни
	for z in range(z0, z0 + 5):
		for x in range(x0, x0 + 5):
			var hole := (x == x0 + 1 and z == z0 + 3) or (x == x0 + 1 and z == z0 + 2)
			if not hole:
				c.put(x, g + 9, z, wall)
	for sx in [0, 4]:
		for sz in [0, 4]:
			c.put(x0 + sx, g + 10, z0 + sz, G.LOG)
			c.put(x0 + sx, g + 11, z0 + sz, G.LOG)
	c.put(x0 + 2, g + 10, z0 + 2, G.TORCH)
	for k in 4:
		var hs := 3 - k
		for z in range(z0 + 2 - hs, z0 + 2 + hs + 1):
			for x in range(x0 + 2 - hs, x0 + 2 + hs + 1):
				if k == 3 or absi(x - (x0 + 2)) == hs or absi(z - (z0 + 2)) == hs:
					c.put(x, g + 12 + k, z, G.COBBLE if style != 1 else G.SANDSTONE)
	c.put(x0 + 2, g + 1, z0 + 2, G.TORCH)


static func _farm(c: Ctx, b: Dictionary, g: int, rng: RandomNumberGenerator) -> void:
	var x0: int = b.x
	var z0: int = b.z
	var w: int = b.w
	var d: int = b.d
	var mid := z0 + d / 2
	for z in range(z0, z0 + d):
		for x in range(x0, x0 + w):
			if z == mid:
				c.put(x, g, z, G.WATER)
				continue
			c.put(x, g, z, G.FARMLAND)
			var r := rng.randf()
			if r < 0.88:
				c.put(x, g + 1, z, G.WHEAT0 + (3 if r < 0.55 else rng.randi() % 3))
	# забор по периметру с калиткой-проходом
	for x in range(x0 - 1, x0 + w + 1):
		for zz in [z0 - 1, z0 + d]:
			if not (zz == z0 - 1 and x == x0 + w / 2):
				c.put(x, g + 1, zz, G.FENCE)
	for z in range(z0, z0 + d):
		for xx in [x0 - 1, x0 + w]:
			c.put(xx, g + 1, z, G.FENCE)
	for sx in [x0 - 1, x0 + w]:
		for sz in [z0 - 1, z0 + d]:
			c.put(sx, g + 2, sz, G.TORCH)
	c.put(x0 - 1, g + 1, mid, G.HAY)
	c.put(x0 + w, g + 1, mid, G.HAY)
	c.put(x0 + w, g + 2, mid, G.HAY)
	c.spawn("villager", x0 + w / 2 + 0.5, g + 1.4, mid + 1.5)


static func _pen(c: Ctx, b: Dictionary, g: int, rng: RandomNumberGenerator) -> void:
	var x0: int = b.x
	var z0: int = b.z
	var w: int = b.w
	var d: int = b.d
	for x in range(x0, x0 + w):
		for z in range(z0, z0 + d):
			var edge := x == x0 or x == x0 + w - 1 or z == z0 or z == z0 + d - 1
			for y in range(1, 4):
				c.put(x, g + y, z, 0)
			if edge:
				if not (z == z0 and x == x0 + w / 2):
					c.put(x, g + 1, z, G.FENCE)
			elif rng.randf() < 0.18:
				c.put(x, g + 1, z, G.TALL_GRASS)
	c.put(x0 + 1, g + 1, z0 + d - 2, G.HAY)
	c.put(x0 + 2, g + 1, z0 + d - 2, G.HAY)
	c.put(x0 + 1, g + 2, z0 + d - 2, G.HAY)
	c.put(x0 + w - 2, g + 1, z0 + 1, G.HAY)
	var kinds := ["pig", "cow", "sheep", "chicken"]
	var kind: String = kinds[rng.randi() % kinds.size()]
	var n := 2 + rng.randi() % 3
	for k in n:
		c.spawn(kind, x0 + 2.0 + rng.randf() * (w - 4), g + 1.3, z0 + 2.0 + rng.randf() * (d - 4))
	for sx in [x0, x0 + w - 1]:
		for sz in [z0, z0 + d - 1]:
			c.put(sx, g + 2, sz, G.FENCE)
			c.put(sx, g + 3, sz, G.TORCH)


static func _stall(c: Ctx, b: Dictionary, g: int, rng: RandomNumberGenerator) -> void:
	var x0: int = b.x
	var z0: int = b.z
	var w: int = b.w
	var d: int = b.d
	for sx in [x0, x0 + w - 1]:
		for sz in [z0, z0 + d - 1]:
			for y in range(1, 4):
				c.put(sx, g + y, sz, G.LOG)
	for z in range(z0 - 1, z0 + d + 1):
		for x in range(x0 - 1, x0 + w + 1):
			c.put(x, g + 4, z, G.WOOL if ((x + z) & 1) == 0 else G.PLANKS)
	c.put(x0 + w / 2, g + 1, z0 + d / 2, G.TABLE)
	c.put(x0 + w / 2, g + 2, z0 + d / 2, G.TORCH)
	c.put(x0 + 1, g + 1, z0 + 1, G.HAY)
	c.put(x0 + w - 2, g + 1, z0 + 1, G.HAY)
	c.spawn("villager", x0 + w / 2 + 0.5, g + 1.2, z0 + d / 2 + 1.5)
	if rng.randf() < 0.5:
		c.put(x0 + 1, g + 1, z0 + d - 2, G.FLOWER_PINK)


# ------------------------------------------------------------------
#  Затонувший корабль (внутри одного чанка)
# ------------------------------------------------------------------
static func apply_ship(gen: WorldGen, d: PackedByteArray, key: Vector2i, wx0: int, wz0: int) -> void:
	if gen._ih(key.x, key.y, 61) % 55 != 0:
		return
	var info := gen.col_info(wx0 + 8, wz0 + 8)
	if info.y != WorldGen.B_OCEAN or info.x > SEA - 7:
		return
	var g := info.x
	for p in [Vector2i(1, 8), Vector2i(14, 8), Vector2i(8, 4), Vector2i(8, 12)]:
		var ci := gen.col_info(wx0 + p.x, wz0 + p.y)
		if absi(ci.x - g) > 3:
			return
	var c := Ctx.new()
	c.d = d
	c.wx0 = wx0
	c.wz0 = wz0
	var hw := [0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 1, 1]
	var rng := RandomNumberGenerator.new()
	rng.seed = gen._ih(key.x, key.y, 62)
	var zc := wz0 + 8
	for ix in 14:
		var x := wx0 + 1 + ix
		var h: int = hw[ix]
		for dz in range(-h, h + 1):
			var z := zc + dz
			c.put(x, g, z, G.PLANKS)
			if absi(dz) == h:
				for y in range(1, 4):
					if y >= 2 and rng.randf() < 0.22:
						continue
					c.put(x, g + y, z, G.PLANKS if y != 3 else G.LOG)
			else:
				for y in range(1, 4):
					c.put(x, g + y, z, G.WATER)
				if y_deck(ix) and rng.randf() > 0.3:
					c.put(x, g + 2, z, G.PLANKS)
	for y in range(1, 4 + rng.randi() % 5):
		c.put(wx0 + 8, g + 2 + y, zc, G.LOG)
	c.put(wx0 + 5, g + 1, zc, G.GOLD_ORE)
	c.put(wx0 + 6, g + 1, zc + 1, G.IRON_ORE)
	if rng.randf() < 0.5:
		c.put(wx0 + 4, g + 1, zc - 1, G.DIAMOND_ORE)
	c.put(wx0 + 11, g + 1, zc, G.TABLE)


static func y_deck(ix: int) -> bool:
	return ix > 2 and ix < 12
