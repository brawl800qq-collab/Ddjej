class_name Weather
extends Node
## Погода: ясно / облачно / дождь / гроза. Дождь, лужи и грязь, ветер, молнии, гром, фоновая музыка.

const OVER := [0.0, 0.55, 0.8, 1.0]
const RAIN := [0.0, 0.0, 0.55, 1.0]

var game: Node3D
var player: Player
var world: World

var state := 0
var timer := 200.0
var overcast := 0.0
var rain := 0.0
var wet := 0.0
var wind := 1.0
var flash := 0.0
var sheltered := false

var rain_fx: CPUParticles3D
var bolt_t := 8.0
var pending_thunder: Array = []
var t := 0.0


func setup(g: Node3D, p: Player, w: World) -> void:
	game = g
	player = p
	world = w
	timer = randf_range(120.0, 260.0)

	rain_fx = CPUParticles3D.new()
	rain_fx.amount = 520
	rain_fx.lifetime = 1.0
	rain_fx.emitting = false
	rain_fx.local_coords = false
	rain_fx.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain_fx.emission_box_extents = Vector3(15.0, 0.3, 15.0)
	rain_fx.direction = Vector3(0.12, -1.0, 0.05)
	rain_fx.spread = 2.0
	rain_fx.initial_velocity_min = 24.0
	rain_fx.initial_velocity_max = 28.0
	rain_fx.gravity = Vector3.ZERO
	rain_fx.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	var bm := BoxMesh.new()
	bm.size = Vector3(0.012, 0.55, 0.012)
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(0.75, 0.82, 0.95, 0.55)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bm.material = mat
	rain_fx.mesh = bm
	game.add_child(rain_fx)


func _next_state() -> void:
	var r := randf()
	var s := 0
	if state == 0:
		s = 1 if r < 0.5 else (2 if r < 0.75 else 0)
	elif state == 1:
		s = 0 if r < 0.4 else (2 if r < 0.8 else 3)
	elif state == 2:
		s = 1 if r < 0.4 else (3 if r < 0.55 else 0)
	else:
		s = 2 if r < 0.6 else 1
	state = s
	timer = randf_range(110.0, 300.0)


func update(dt: float) -> void:
	t += dt
	timer -= dt
	if timer <= 0.0:
		_next_state()
	var to := float(OVER[state])
	var tr := float(RAIN[state])
	overcast = move_toward(overcast, to, dt * 0.02)
	rain = move_toward(rain, tr, dt * 0.03)
	if rain > 0.08:
		wet = move_toward(wet, 1.0, dt * 0.05)
	else:
		wet = move_toward(wet, 0.0, dt * 0.007)
	var gust := 0.5 + 0.5 * sin(t * 0.37) * sin(t * 0.11 + 1.0)
	wind = 0.8 + 0.7 * overcast + 1.1 * rain + gust * 0.6
	G.set_weather(wet, wind, overcast)

	# укрытие от дождя
	var px := floori(player.position.x)
	var pz := floori(player.position.z)
	var top := world.column_top(px, pz)
	sheltered = player.underground or (top >= 0 and float(top) > player.position.y + 2.0)

	rain_fx.global_position = player.position + Vector3(0, 13, 0)
	rain_fx.emitting = rain > 0.05 and not sheltered
	var ext := 15.0 / sqrt(clampf(rain, 0.15, 1.0))
	rain_fx.emission_box_extents = Vector3(ext, 0.3, ext)

	# молнии и гром
	flash = maxf(0.0, flash - dt * 2.6)
	if state == 3 and rain > 0.6:
		bolt_t -= dt
		if bolt_t <= 0.0:
			bolt_t = randf_range(6.0, 17.0)
			flash = 1.0
			pending_thunder.append(randf_range(0.5, 2.6))
	for i in range(pending_thunder.size() - 1, -1, -1):
		pending_thunder[i] -= dt
		if pending_thunder[i] <= 0.0:
			pending_thunder.remove_at(i)
			Sfx.play(game, "thunder", null, -3.0 - (8.0 if player.underground else 0.0), randf_range(0.85, 1.1))
