class_name Arrow
extends Node3D
## Стрела скелета.

var world: World
var player: Player
var vel := Vector3.ZERO
var life := 6.0


func _ready() -> void:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(0.55, 0.4, 0.22)
	var shaft := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.05, 0.05, 0.7)
	shaft.mesh = bm
	shaft.material_override = m
	add_child(shaft)
	var m2 := StandardMaterial3D.new()
	m2.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m2.albedo_color = Color(0.75, 0.75, 0.78)
	var tip := MeshInstance3D.new()
	var tm := BoxMesh.new()
	tm.size = Vector3(0.09, 0.09, 0.12)
	tip.mesh = tm
	tip.material_override = m2
	tip.position = Vector3(0, 0, -0.38)
	add_child(tip)
	var m3 := StandardMaterial3D.new()
	m3.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m3.albedo_color = Color(0.9, 0.9, 0.9)
	var fl := MeshInstance3D.new()
	var fm := BoxMesh.new()
	fm.size = Vector3(0.14, 0.02, 0.14)
	fl.mesh = fm
	fl.material_override = m3
	fl.position = Vector3(0, 0, 0.33)
	add_child(fl)


func _process(dt: float) -> void:
	dt = minf(dt, 0.05)
	life -= dt
	if life <= 0.0 or world == null:
		queue_free()
		return
	vel.y -= 14.0 * dt
	var np := position + vel * dt
	if world.is_solid_at(floori(np.x), floori(np.y), floori(np.z)):
		Sfx.play(self, "hit", position, -8.0, 1.4)
		queue_free()
		return
	position = np
	if vel.length() > 0.1:
		look_at(position + vel, Vector3.UP)
	if player != null and not player.dead:
		var c := player.position + Vector3(0, 0.9, 0)
		var d := c - position
		if absf(d.y) < 1.0 and Vector2(d.x, d.z).length() < 0.55:
			player.hurt(3.0)
			var away := vel.normalized()
			player.vel += Vector3(away.x * 4.0, 2.5, away.z * 4.0)
			queue_free()
