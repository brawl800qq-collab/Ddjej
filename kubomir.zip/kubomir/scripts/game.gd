extends Node3D
## Игровая сцена: окружение и шейдеры неба, день/ночь, взаимодействие, мобы, дроп, сохранение.

var world: World
var player: Player
var hud: Hud
var mobs: Node3D
var drops: Node3D
var sun: DirectionalLight3D
var env: Environment
var clouds: MeshInstance3D
var highlight: MeshInstance3D
var crack: MeshInstance3D
var crack_meshes: Array = []
var break_fx: CPUParticles3D

var tod := 0.2             # время суток: 0 рассвет, 0.25 полдень, 0.5 закат, 0.75 полночь
var state := "loading"     # loading | play | ui
var breaking := false
var break_pos := Vector3i(0, -999, 0)
var break_prog := 0.0
var target: Dictionary = {}
var has_target := false
var mob_target: Mob = null
var mob_dist := 999.0
var atk_cd := 0.0
var zombie_t := 0.0
var autosave_t := 0.0
var spawn_point := Vector3(0.5, 40, 0.5)
var save_data = null
var wind := 0.0
var lamp := 0.0
var last_ao := true
var last_leaf := true
var fps_acc := 0.0
var fps_n := 0
var adapt_t := 0.0
var adapt_steps := 0
var loaded_from_save := false
var load_t := 0.0
var sh_img: Image
var sh_tex: ImageTexture
var sh_origin := Vector2i(-99999, -99999)
var sh_t := 0.0
var sleeping := 0.0
var weather: Weather
var respawn_wait := 0.0
var crack_t := 0.0
var cave_t := 0.0


var safe_mode := false
var run_t := 0.0
var crop_t := 0.0
var ok_logged := false


func _log(msg: String) -> void:
	var f := FileAccess.open("user://kubomir_log.txt", FileAccess.READ_WRITE)
	if f == null:
		f = FileAccess.open("user://kubomir_log.txt", FileAccess.WRITE)
	if f == null:
		return
	f.seek_end()
	f.store_line("%s  %s" % [Time.get_time_string_from_system(), msg])
	f.flush()
	f.close()


func _clear_flag() -> void:
	if FileAccess.file_exists("user://run.flag"):
		DirAccess.remove_absolute(ProjectSettings.globalize_path("user://run.flag"))


func _ready() -> void:
	randomize()
	safe_mode = FileAccess.file_exists("user://run.flag")
	var rf := FileAccess.open("user://run.flag", FileAccess.WRITE)
	if rf:
		rf.store_string("running")
		rf.close()
	_log("start safe=%s" % str(safe_mode))
	save_data = G.load_game()

	world = World.new()
	world.name = "World"
	add_child(world)
	world.setup(G.seed_value)
	if safe_mode:
		world.threaded = false
	_log("world.setup ok")
	world.animal_spawn.connect(_on_animal_spawn)

	mobs = Node3D.new()
	mobs.name = "Mobs"
	add_child(mobs)
	drops = Node3D.new()
	drops.name = "Drops"
	add_child(drops)

	_make_environment()
	_make_helpers()

	player = Player.new()
	player.world = world
	add_child(player)
	player.active = false
	player.died.connect(func(): breaking = false)
	player.want_drop.connect(_on_player_drop)

	hud = Hud.new()
	add_child(hud)
	hud.setup(self, player)
	player.tool_broke.connect(func(): hud.toast("Предмет сломался!"))
	weather = Weather.new()
	add_child(weather)
	if not safe_mode:
		weather.setup(self, player, world)
	_log("weather ok")

	var start := Vector3.ZERO
	if save_data is Dictionary:
		loaded_from_save = true
		world.load_edits(save_data.get("edits", PackedInt32Array()))
		world.containers = save_data.get("chests", {})
		spawn_point = save_data.get("spawn", Vector3(0.5, 40, 0.5))
		tod = float(save_data.get("tod", 0.2))
		var pd: Dictionary = save_data.get("player", {})
		player.from_dict(pd)
		start = player.position
	else:
		spawn_point = world.find_spawn()
		var ns := NetSession.inst
		if ns != null and not ns.pending.is_empty():
			world.load_edits(ns.pending["edits"])
			tod = float(ns.pending["tod"])
			var hp: Vector3 = ns.pending["pos"]
			spawn_point = Vector3(hp.x + 1.5, hp.y + 1.0, hp.z)
		start = spawn_point
		player.position = start
		if G.mode == "creative":
			player.health = 20.0
	last_ao = G.ao
	if G.auto_tune:
		G.auto_tune_apply()
		_log("auto tune: %s" % G.tier_name)
	last_leaf = G.leaf_depth
	G.settings_changed.connect(_apply_settings)
	_apply_settings()

	world.radius = 3
	world.force_refresh()
	world.update_center(start)
	player.refresh_hand()
	player.inv_changed.emit()
	_log("ready done")
	if NetSession.inst != null and NetSession.inst.active and not NetSession.inst.is_host:
		NetSession.inst.pending = {}
		NetSession.inst.attach_game(self)


# ---------------- окружение ----------------
func _make_environment() -> void:
	var sky := Sky.new()
	sky.sky_material = G.sky_mat
	sky.process_mode = Sky.PROCESS_MODE_REALTIME
	sky.radiance_size = Sky.RADIANCE_SIZE_32
	env = Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.fog_enabled = false
	env.glow_enabled = G.glow
	env.glow_intensity = 0.7
	env.glow_bloom = 0.08
	env.glow_hdr_threshold = 1.0
	sh_img = Image.create(128, 128, false, Image.FORMAT_R8)
	sh_tex = ImageTexture.create_from_image(sh_img)
	G.set_shadow_map(sh_tex, Vector2.ZERO)
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.shadow_enabled = false
	add_child(sun)

	var pm := PlaneMesh.new()
	pm.size = Vector2(2400, 2400)
	clouds = MeshInstance3D.new()
	clouds.mesh = pm
	clouds.material_override = G.cloud_mat
	clouds.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	clouds.extra_cull_margin = 4000.0
	add_child(clouds)

	_update_sky()


func _make_helpers() -> void:
	# рамка выбранного блока
	var mesh := ArrayMesh.new()
	var verts := PackedVector3Array()
	var s := 0.504
	for i in 8:
		verts.push_back(Vector3(-s if (i & 1) == 0 else s, -s if (i & 2) == 0 else s, -s if (i & 4) == 0 else s))
	var idx := PackedInt32Array([0, 1, 2, 3, 4, 5, 6, 7, 0, 2, 1, 3, 4, 6, 5, 7, 0, 4, 1, 5, 2, 6, 3, 7])
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_INDEX] = idx
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_LINES, arr)
	var lm := StandardMaterial3D.new()
	lm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	lm.albedo_color = Color(0, 0, 0, 1)
	mesh.surface_set_material(0, lm)
	highlight = MeshInstance3D.new()
	highlight.mesh = mesh
	highlight.visible = false
	highlight.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(highlight)

	# трещины при разрушении
	var cm := StandardMaterial3D.new()
	cm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	cm.albedo_texture = G.crack_tex
	cm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	cm.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	for st in 10:
		var m := World.overlay_cube(st, 1.006)
		m.surface_set_material(0, cm)
		crack_meshes.append(m)
	crack = MeshInstance3D.new()
	crack.mesh = crack_meshes[0]
	crack.visible = false
	crack.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(crack)

	# осколки при ломании
	break_fx = CPUParticles3D.new()
	break_fx.amount = 14
	break_fx.lifetime = 0.7
	break_fx.one_shot = true
	break_fx.explosiveness = 1.0
	break_fx.emitting = false
	break_fx.direction = Vector3(0, 1, 0)
	break_fx.spread = 80.0
	break_fx.initial_velocity_min = 1.5
	break_fx.initial_velocity_max = 3.5
	break_fx.gravity = Vector3(0, -12, 0)
	break_fx.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	break_fx.emission_box_extents = Vector3(0.4, 0.4, 0.4)
	break_fx.local_coords = false
	add_child(break_fx)


func _apply_settings() -> void:
	world.radius = G.render_distance if state != "loading" else 3
	world.ao_enabled = G.ao
	if G.ao != last_ao or G.leaf_depth != last_leaf:
		last_ao = G.ao
		last_leaf = G.leaf_depth
		for k in world.meshed.keys():
			world.dirty[k] = true
	world.force_refresh()
	if clouds:
		clouds.visible = G.clouds
	if env:
		env.glow_enabled = G.glow
	if player and player.cam:
		player.cam.far = 520.0


# ---------------- карта высот для теней ----------------
func _update_shadow_map(force: bool) -> void:
	var cx := floori(player.position.x) - 64
	var cz := floori(player.position.z) - 64
	cx = (cx >> 3) << 3
	cz = (cz >> 3) << 3
	if not force and absi(cx - sh_origin.x) < 8 and absi(cz - sh_origin.y) < 8 and not world.hm_changed:
		return
	world.hm_changed = false
	sh_origin = Vector2i(cx, cz)
	sh_img.fill(Color.BLACK)
	for kz in range(cz >> 4, ((cz + 127) >> 4) + 1):
		for kx in range(cx >> 4, ((cx + 127) >> 4) + 1):
			var key := Vector2i(kx, kz)
			if not world.hmaps.has(key):
				continue
			var ci := Image.create_from_data(16, 16, false, Image.FORMAT_R8, world.hmaps[key])
			sh_img.blit_rect(ci, Rect2i(0, 0, 16, 16), Vector2i(kx * 16 - cx, kz * 16 - cz))
	sh_tex.update(sh_img)
	G.set_shadow_map(sh_tex, Vector2(cx, cz))


# ---------------- день и ночь, шейдеры ----------------
func _update_sky() -> void:
	var a := tod * TAU
	var s := sin(a)
	var day := clampf(s * 2.2 + 0.45, 0.0, 1.0)
	G.day = day
	var sd := Vector3(cos(a) * 0.9, s, 0.35).normalized()
	sun.global_transform = Transform3D(Basis.looking_at(-sd, Vector3.UP), Vector3.ZERO)
	var dusk := clampf(1.0 - absf(s) * 3.0, 0.0, 1.0)
	var sun_col := Color(1.0, 0.89, 0.68).lerp(Color(1.0, 0.58, 0.32), dusk * 0.75)
	sun.light_color = sun_col
	sun.light_energy = lerpf(0.0, 1.1, day)
	var top := Color(0.02, 0.03, 0.09).lerp(Color(0.28, 0.52, 0.95), day)
	var hor := Color(0.06, 0.08, 0.16).lerp(Color(0.72, 0.84, 0.97), day)
	hor = hor.lerp(Color(0.95, 0.55, 0.35), dusk * 0.45 * (1.0 if day > 0.05 else 0.3))
	var amb_d := Color(0.52, 0.56, 0.66).lerp(Color(0.62, 0.52, 0.48), dusk * 0.5)
	var amb_n := Color(0.10, 0.12, 0.24)
	var ov := 0.0
	var fl := 0.0
	if weather != null:
		ov = weather.overcast
		fl = weather.flash
	var grey := Color(0.46, 0.48, 0.53)
	sun_col = sun_col.lerp(Color(0.7, 0.72, 0.78), ov * 0.6) * (1.0 - 0.45 * ov)
	top = top.lerp(grey * lerpf(0.25, 1.0, day), ov * 0.85).lerp(Color(0.9, 0.93, 1.0), fl * 0.7)
	hor = hor.lerp(grey * lerpf(0.3, 1.1, day), ov * 0.85).lerp(Color(1, 1, 1), fl * 0.8)
	amb_d = amb_d.lerp(Color(0.5, 0.53, 0.6), ov * 0.6) + Color(0.7, 0.75, 1.0) * fl * 0.6
	sun.light_energy *= 1.0 - 0.6 * ov
	G.set_light(day, sd, sun_col, amb_d, amb_n, top, hor, clampf(1.0 - day * 2.0, 0.0, 1.0) * (1.0 - ov))
	env.ambient_light_color = amb_n.lerp(amb_d, day)
	env.ambient_light_energy = lerpf(0.9, 0.7, day)


# ---------------- ввод от HUD ----------------
func on_look(rel: Vector2) -> void:
	if state != "play" or player.dead:
		return
	var k := 0.0042 * G.sens
	player.yaw -= rel.x * k
	player.pitch = clampf(player.pitch - rel.y * k, -1.5, 1.5)


func set_breaking(b: bool) -> void:
	breaking = b
	if not b:
		break_prog = 0.0
		if crack:
			crack.visible = false


func _unhandled_input(e: InputEvent) -> void:
	if state != "play":
		return
	if e is InputEventMouseButton and e.pressed:
		if e.button_index == MOUSE_BUTTON_WHEEL_UP:
			player.sel = (player.sel + 8) % 9
			player.refresh_hand()
		elif e.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			player.sel = (player.sel + 1) % 9
			player.refresh_hand()
	elif e is InputEventKey and e.pressed and not e.echo:
		if e.keycode >= KEY_1 and e.keycode <= KEY_9:
			player.sel = e.keycode - KEY_1
			player.refresh_hand()
		elif e.keycode == KEY_E:
			hud.open_inventory(0)


func on_tap() -> void:
	if state != "play" or player.dead:
		return
	if mob_target != null:
		_attack(mob_target)
		return
	if has_target:
		var p: Vector3i = target["pos"]
		var id := world.get_block(p.x, p.y, p.z)
		if id == G.TABLE:
			hud.open_inventory(1)
			return
		if id == G.FURNACE:
			hud.open_inventory(2)
			return
		if id == G.BED or id == G.BED_HEAD:
			_use_bed(p)
			return
		if id == G.CHEST and not player.sneak:
			hud.open_chest(p)
			return
		if id >= G.DOOR_BASE and id < G.DOOR_BASE + 8 and not player.sneak:
			_toggle_door(p)
			return
		if player.held_id() == G.SEEDS and _plant_seed():
			return
		if _place_block():
			return
	_try_use_item()


func _use_bed(p: Vector3i) -> void:
	spawn_point = Vector3(p.x + 0.5, p.y + 1.0, p.z + 0.5)
	if G.day < 0.5:
		sleeping = 8.0
		hud.toast("Спим… точка возрождения сохранена")
	else:
		hud.toast("Точка возрождения сохранена (спать можно ночью)")


func _attack(m: Mob) -> void:
	if atk_cd > 0.0 or not is_instance_valid(m):
		return
	atk_cd = 0.45
	player.swing = 1.0
	player.wear_held(1)
	Sfx.play(self, "hit", m.position, -2.0, Sfx.rnd_pitch(0.9, 1.1))
	m.hurt(G.item_damage(player.held_id()), player.position)


func _try_use_item() -> void:
	var id := player.held_id()
	if id == 0:
		return
	if G.armor_slot(id) >= 0:
		if player.equip_from(player.sel):
			hud.toast("Надето: " + G.item_name(id))
		return
	var info := G.held_info(id)
	if info.has("food") and G.mode == "survival" and player.food < 20.0:
		player.food = minf(20.0, player.food + float(info["food"]))
		Sfx.play(self, "eat", null, -3.0)
		player.consume_held()
		player.swing = 1.0
		hud.toast("Вкусно!")


func _overlaps_player(p: Vector3i) -> bool:
	var pp := player.position
	return pp.x - 0.3 < p.x + 1 and pp.x + 0.3 > p.x and pp.z - 0.3 < p.z + 1 and pp.z + 0.3 > p.z and pp.y < p.y + 1 and pp.y + 1.8 > p.y


func _place_block() -> bool:
	var id := player.held_id()
	if not G.is_block(id):
		return false
	var n: Vector3i = target["normal"]
	var tp: Vector3i = target["pos"]
	var p := tp + n
	var tid := world.get_block(tp.x, tp.y, tp.z)
	if G.is_plant(tid):
		p = tp
	if p.y < 0 or p.y >= World.CH:
		return false
	var look := -player.cam.global_transform.basis.z
	# плиты: слияние в полный блок
	if id >= G.SLAB_BASE and id < G.SLAB_BASE + 5:
		var sm := id - G.SLAB_BASE
		var full: int = BlocksExt.MATS[sm]["full"]
		if (tid == G.SLAB_BASE + sm and n.y == 1) or (tid == G.SLAB_BASE + 5 + sm and n.y == -1):
			world.set_block(tp.x, tp.y, tp.z, full)
			player.consume_held()
			player.swing = 1.0
			return true
	var cur := world.get_block(p.x, p.y, p.z)
	if cur != 0 and cur != G.WATER and not G.is_plant(cur):
		return false
	if G.is_solid_id(id) and _overlaps_player(p):
		return false
	if id >= G.SLAB_BASE and id < G.SLAB_BASE + 5:
		var tophalf := n.y == -1
		if n.y == 0:
			var hitp: Vector3 = player.cam.global_position + look * float(target.get("dist", 2.0))
			tophalf = hitp.y - float(tp.y) > 0.5
		world.set_block(p.x, p.y, p.z, id + (5 if tophalf else 0))
		player.consume_held()
		player.swing = 1.0
		return true
	if id >= G.STAIR_BASE and id < G.STAIR_BASE + 16 and (id - G.STAIR_BASE) % 4 == 0:
		var fc := 0
		if absf(look.x) > absf(look.z):
			fc = 3 if look.x > 0.0 else 2
		else:
			fc = 1 if look.z > 0.0 else 0
		world.set_block(p.x, p.y, p.z, id + fc)
		player.consume_held()
		player.swing = 1.0
		return true
	if id == G.DOOR:
		var up := Vector3i(p.x, p.y + 1, p.z)
		var ucur := world.get_block(up.x, up.y, up.z)
		if (ucur != 0 and ucur != G.WATER and not G.is_plant(ucur)) or not G.is_solid_id(world.get_block(p.x, p.y - 1, p.z)):
			return false
		var ax := 0 if absf(look.z) >= absf(look.x) else 1
		world.set_block(p.x, p.y, p.z, G.DOOR_BASE + ax)
		world.set_block(up.x, up.y, up.z, G.DOOR_BASE + 4 + ax)
		player.consume_held()
		player.swing = 1.0
		return true
	if id == G.TORCH:
		if not G.is_solid_id(world.get_block(p.x, p.y - 1, p.z)):
			return false
	elif G.is_plant(id):
		var below := world.get_block(p.x, p.y - 1, p.z)
		if below != G.GRASS and below != G.DIRT and below != G.SNOW and below != G.SAND and below != G.GRAVEL:
			return false
	if id == G.BED:
		var foot := p
		var head := Vector3i(p.x, p.y, p.z - 1)
		if not _bed_free(head):
			head = p
			foot = Vector3i(p.x, p.y, p.z + 1)
			if not _bed_free(foot):
				return false
		if _overlaps_player(foot) or _overlaps_player(head):
			return false
		world.set_block(head.x, head.y, head.z, G.BED_HEAD)
		world.set_block(foot.x, foot.y, foot.z, G.BED)
		player.consume_held()
		player.swing = 1.0
		return true
	world.set_block(p.x, p.y, p.z, id)
	Sfx.play(self, "place", Vector3(p) + Vector3(0.5, 0.5, 0.5), -2.0, Sfx.rnd_pitch(0.9, 1.1))
	player.consume_held()
	player.swing = 1.0
	return true


func _crop_tick(dt: float) -> void:
	crop_t += dt
	if crop_t < 1.5:
		return
	crop_t = 0.0
	for i in 50:
		var rx := floori(player.position.x) + randi_range(-24, 24)
		var rz := floori(player.position.z) + randi_range(-24, 24)
		var ry := world.column_top(rx, rz)
		if ry < 0:
			continue
		var id := world.get_block(rx, ry, rz)
		if id >= G.WHEAT0 and id < G.WHEAT0 + 3 and randf() < 0.16:
			world.set_block(rx, ry, rz, id + 1)


func _toggle_door(p: Vector3i) -> void:
	var id := world.get_block(p.x, p.y, p.z)
	var k := id - G.DOOR_BASE
	var is_top := k / 4 == 1
	var other := Vector3i(p.x, p.y + (-1 if is_top else 1), p.z)
	var oid := world.get_block(other.x, other.y, other.z)
	var nk := k ^ 2
	world.set_block(p.x, p.y, p.z, G.DOOR_BASE + nk)
	if oid >= G.DOOR_BASE and oid < G.DOOR_BASE + 8:
		world.set_block(other.x, other.y, other.z, G.DOOR_BASE + ((oid - G.DOOR_BASE) ^ 2))
	player.swing = 1.0


func _plant_seed() -> bool:
	var tp: Vector3i = target["pos"]
	var n: Vector3i = target["normal"]
	if n.y != 1:
		return false
	var below := world.get_block(tp.x, tp.y, tp.z)
	if below != G.GRASS and below != G.DIRT and below != G.FARMLAND:
		return false
	if world.get_block(tp.x, tp.y + 1, tp.z) != 0:
		return false
	if below != G.FARMLAND:
		world.set_block(tp.x, tp.y, tp.z, G.FARMLAND)
	world.set_block(tp.x, tp.y + 1, tp.z, G.WHEAT0)
	player.consume_held()
	player.swing = 1.0
	return true


func _bed_free(q: Vector3i) -> bool:
	var cur := world.get_block(q.x, q.y, q.z)
	if cur != 0 and cur != G.WATER and not G.is_plant(cur):
		return false
	return G.is_solid_id(world.get_block(q.x, q.y - 1, q.z))


func _spawn_drop(id: int, n: int, pos: Vector3, vel: Vector3) -> void:
	if drops.get_child_count() > 150:
		return
	var d := ItemDrop.make(world, player, id, n, pos, vel)
	drops.add_child(d)


func _break_block(p: Vector3i) -> void:
	var id := world.get_block(p.x, p.y, p.z)
	if id <= 0:
		return
	if G.mode == "survival":
		var d := G.drop_for(id, player.held_id())
		var c := Vector3(p) + Vector3(0.5, 0.5, 0.5)
		if d > 0:
			_spawn_drop(d, int(G.BLOCK_INFO[id].get("n", 1)), c, Vector3(randf_range(-1.5, 1.5), 3.0, randf_range(-1.5, 1.5)))
		elif (id == G.LEAVES or id == G.BIRCH_LEAVES) and randf() < 0.07:
			_spawn_drop(G.APPLE, 1, c, Vector3(randf_range(-1.5, 1.5), 3.0, randf_range(-1.5, 1.5)))
	if id >= G.DOOR_BASE and id < G.DOOR_BASE + 8:
		var dk := id - G.DOOR_BASE
		var dother := Vector3i(p.x, p.y + (-1 if dk / 4 == 1 else 1), p.z)
		var did := world.get_block(dother.x, dother.y, dother.z)
		if did >= G.DOOR_BASE and did < G.DOOR_BASE + 8:
			world.set_block(dother.x, dother.y, dother.z, 0)
	if id == G.CHEST and world.containers.has(p):
		var cl: Array = world.containers[p]
		for slot in cl:
			if int(slot[0]) != 0:
				_spawn_drop(int(slot[0]), int(slot[1]), Vector3(p) + Vector3(0.5, 0.6, 0.5), Vector3(randf_range(-1.5, 1.5), 3.0, randf_range(-1.5, 1.5)))
		world.containers.erase(p)
	if id == G.WHEAT0 + 3 and G.mode == "survival":
		_spawn_drop(G.SEEDS, 1 + randi() % 2, Vector3(p) + Vector3(0.5, 0.5, 0.5), Vector3(randf_range(-1.5, 1.5), 3.0, randf_range(-1.5, 1.5)))
	if id == G.TALL_GRASS and G.mode == "survival" and randf() < 0.12:
		_spawn_drop(G.SEEDS, 1, Vector3(p) + Vector3(0.5, 0.5, 0.5), Vector3(randf_range(-1.5, 1.5), 3.0, randf_range(-1.5, 1.5)))
	if id == G.BED and world.get_block(p.x, p.y, p.z - 1) == G.BED_HEAD:
		world.set_block(p.x, p.y, p.z - 1, 0)
	elif id == G.BED_HEAD and world.get_block(p.x, p.y, p.z + 1) == G.BED:
		world.set_block(p.x, p.y, p.z + 1, 0)
	var bk := Sfx.kind_of(id)
	if bk == "snow":
		bk = "grass"
	Sfx.play(self, "break_" + bk, Vector3(p) + Vector3(0.5, 0.5, 0.5), 0.0, Sfx.rnd_pitch(0.9, 1.1))
	if G.mode == "survival" and G.BLOCK_INFO[id]["hard"] > 0.0:
		player.wear_held(1)
	# осколки
	break_fx.mesh = World.item_quad(G.item_tile(id), 0.14, G.drop_mat)
	break_fx.global_position = Vector3(p) + Vector3(0.5, 0.5, 0.5)
	break_fx.restart()
	break_fx.emitting = true
	# если рядом вода — она затекает
	var repl := 0
	for dv in [Vector3i(0, 1, 0), Vector3i(1, 0, 0), Vector3i(-1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1)]:
		if world.get_block(p.x + dv.x, p.y + dv.y, p.z + dv.z) == G.WATER:
			repl = G.WATER
			break
	world.set_block(p.x, p.y, p.z, repl)
	# растение сверху не должно висеть
	var above := world.get_block(p.x, p.y + 1, p.z)
	if G.is_plant(above):
		world.set_block(p.x, p.y + 1, p.z, 0)
	break_prog = 0.0
	crack.visible = false


func _on_player_drop(id: int, n: int) -> void:
	var f := -player.cam.global_transform.basis.z
	_spawn_drop(id, n, player.cam.global_position + f * 0.6, f * 5.0 + Vector3(0, 2.0, 0))


# ---------------- цель, разрушение ----------------
func _update_target() -> void:
	var origin := player.cam.global_position
	var dir := -player.cam.global_transform.basis.z
	target = world.raycast(origin, dir, 5.0)
	has_target = target.has("pos")
	mob_target = null
	mob_dist = 999.0
	for c in mobs.get_children():
		var m: Mob = c
		if m == null or m.is_queued_for_deletion():
			continue
		var t := m.ray_hit(origin, dir, 4.2)
		if t >= 0.0 and t < mob_dist:
			mob_dist = t
			mob_target = m
	if mob_target != null and has_target and float(target["dist"]) < mob_dist:
		mob_target = null
	highlight.visible = has_target and mob_target == null
	if highlight.visible:
		highlight.position = Vector3(target["pos"]) + Vector3(0.5, 0.5, 0.5)


func _update_breaking(dt: float) -> void:
	atk_cd = maxf(0.0, atk_cd - dt)
	if not breaking or player.dead:
		crack.visible = false
		return
	if mob_target != null:
		break_prog = 0.0
		crack.visible = false
		_attack(mob_target)
		return
	if not has_target:
		break_prog = 0.0
		crack.visible = false
		return
	var p: Vector3i = target["pos"]
	if p != break_pos:
		break_pos = p
		break_prog = 0.0
	var id := world.get_block(p.x, p.y, p.z)
	var t := G.break_time(id, player.held_id())
	if t < 0.0:
		crack.visible = false
		return
	break_prog += dt / maxf(t, 0.01)
	if player.swing <= 0.05:
		player.swing = 1.0
	crack_t -= dt
	if crack_t <= 0.0:
		crack_t = 0.27
		var ck := Sfx.kind_of(id)
		Sfx.play(self, "step_" + ck, Vector3(p) + Vector3(0.5, 0.5, 0.5), -2.0, Sfx.rnd_pitch(0.8, 1.0))
	crack.visible = true
	crack.position = Vector3(p) + Vector3(0.5, 0.5, 0.5)
	crack.mesh = crack_meshes[clampi(int(break_prog * 10.0), 0, 9)]
	if break_prog >= 1.0:
		_break_block(p)


# ---------------- мобы ----------------
func _on_animal_spawn(kind: String, pos: Vector3) -> void:
	if mobs.get_child_count() > 60:
		return
	if NetSession.inst != null and NetSession.inst.active and not NetSession.inst.is_host:
		return
	_spawn_mob(kind, pos)


func _spawn_mob(kind: String, pos: Vector3) -> void:
	var m := Mob.new()
	m.kind = kind
	m.world = world
	m.player = player
	m.position = pos
	m.died.connect(_on_mob_died)
	m.exploded.connect(_on_explode)
	if kind == "villager" or kind == "golem":
		m.home = pos
		m.has_home = true
	mobs.add_child(m)


func _on_mob_died(kind: String, pos: Vector3) -> void:
	if G.mode != "survival":
		return
	var c := pos + Vector3(0, 0.5, 0)
	var v := Vector3(randf_range(-1.5, 1.5), 3.0, randf_range(-1.5, 1.5))
	match kind:
		"pig":
			_spawn_drop(G.MEAT, 1 + randi() % 2, c, v)
		"cow":
			_spawn_drop(G.MEAT, 1 + randi() % 3, c, v)
			if randf() < 0.6:
				_spawn_drop(G.LEATHER, 1 + randi() % 2, c, -v)
		"sheep":
			_spawn_drop(G.WOOL, 1, c, v)
			_spawn_drop(G.MEAT, 1, c, -v)
		"chicken":
			_spawn_drop(G.MEAT, 1, c, v)
		"fish0", "fish1", "fish2":
			_spawn_drop(G.RAW_FISH, 1, c, v)
		"dolphin":
			_spawn_drop(G.RAW_FISH, 1 + randi() % 2, c, v)
		"golem":
			_spawn_drop(G.IRON_INGOT, 3 + randi() % 3, c, v)
		"zombie":
			if randf() < 0.25:
				_spawn_drop(G.IRON_INGOT, 1, c, v)


func _hostile_counts() -> Array:
	var counts := {}
	var total := 0
	var bats := 0
	for c in mobs.get_children():
		var m: Mob = c
		counts[m.kind] = int(counts.get(m.kind, 0)) + 1
		if m.hostile:
			total += 1
		if m.kind == "bat":
			bats += 1
	return [counts, total, bats]


func _pick_hostile() -> String:
	var r := randf()
	if r < 0.35:
		return "zombie"
	if r < 0.6:
		return "skeleton"
	if r < 0.85:
		return "creeper"
	return "spider"


## Ночью на поверхности: зомби, скелеты, криперы, пауки; изредка летучая мышь
func _spawn_zombie() -> void:
	var hc := _hostile_counts()
	var counts: Dictionary = hc[0]
	if int(hc[1]) >= 9:
		return
	var k := _pick_hostile()
	if int(counts.get(k, 0)) >= 3:
		return
	var a := randf() * TAU
	var r := randf_range(16.0, 30.0)
	var x := player.position.x + cos(a) * r
	var z := player.position.z + sin(a) * r
	var top := world.column_top(floori(x), floori(z))
	if top <= World.SEA:
		return
	if randf() < 0.05 and int(hc[2]) < 2:
		_spawn_mob("bat", Vector3(x, top + 5.0, z))
		return
	_spawn_mob(k, Vector3(x, top + 1.1, z))


## Свободная точка в пещере рядом с игроком (воздух над твёрдым полом)
func _cave_spot() -> Variant:
	for i in 14:
		var x := floori(player.position.x) + randi_range(-14, 14)
		var z := floori(player.position.z) + randi_range(-14, 14)
		var y0 := floori(player.position.y) + randi_range(-4, 4)
		if absi(x - floori(player.position.x)) < 6 and absi(z - floori(player.position.z)) < 6:
			continue
		if world.get_block(x, y0, z) == 0 and world.get_block(x, y0 + 1, z) == 0 and world.is_solid_at(x, y0 - 1, z):
			return Vector3(x + 0.5, y0 + 0.05, z + 0.5)
	return null


func _spawn_cave() -> void:
	var hc := _hostile_counts()
	var counts: Dictionary = hc[0]
	var sp: Variant = _cave_spot()
	if sp == null:
		return
	if randf() < 0.28 and int(hc[2]) < 3:
		_spawn_mob("bat", sp + Vector3(0, 1.0, 0))
		return
	if int(hc[1]) >= 7:
		return
	var k := _pick_hostile()
	if int(counts.get(k, 0)) >= 3:
		return
	_spawn_mob(k, sp)


func _on_explode(pos: Vector3) -> void:
	Sfx.play(self, "explode", pos, 2.0, Sfx.rnd_pitch(0.9, 1.05))
	var r := 3
	var cx := floori(pos.x)
	var cy := floori(pos.y)
	var cz := floori(pos.z)
	for dx in range(-r, r + 1):
		for dy in range(-r, r + 1):
			for dz in range(-r, r + 1):
				if dx * dx + dy * dy + dz * dz > r * r + 1:
					continue
				var id := world.get_block(cx + dx, cy + dy, cz + dz)
				if id <= 0 or id == G.BEDROCK or id == G.WATER:
					continue
				world.set_block(cx + dx, cy + dy, cz + dz, 0)
				if G.mode == "survival" and randf() < 0.22:
					var dr := G.drop_for(id, 0)
					if dr > 0:
						_spawn_drop(dr, 1, Vector3(cx + dx + 0.5, cy + dy + 0.5, cz + dz + 0.5), Vector3(randf_range(-3, 3), randf_range(2, 5), randf_range(-3, 3)))
	break_fx.mesh = World.item_quad(G.item_tile(G.STONE), 0.2, G.drop_mat)
	break_fx.amount = 40
	break_fx.global_position = pos
	break_fx.restart()
	break_fx.emitting = true
	var d := player.position.distance_to(pos)
	if d < 7.0 and not player.dead:
		player.hurt(clampf((7.0 - d) * 2.6, 1.0, 20.0))
		var away := (player.position - pos).normalized()
		player.vel += Vector3(away.x * 9.0, 6.0, away.z * 9.0)


# ---------------- респавн / сохранение ----------------
## Ищет безопасную точку на поверхности около (x, z)
func _settle_pos(x: float, z: float) -> Vector3:
	for off in range(0, 12):
		for k in 4:
			var ox := 0
			var oz := 0
			match k:
				0:
					ox = off
				1:
					ox = -off
				2:
					oz = off
				_:
					oz = -off
			var ix := floori(x) + ox
			var iz := floori(z) + oz
			var top := world.column_top(ix, iz)
			if top < 0:
				continue
			var tid := world.get_block(ix, top, iz)
			if tid == G.LEAVES or tid == G.BIRCH_LEAVES or tid == G.SPRUCE_LEAVES or tid == G.LOG or tid == G.BIRCH_LOG or tid == G.SPRUCE_LOG or tid == G.CACTUS:
				continue
			return Vector3(ix + 0.5, top + 1.01, iz + 0.5)
	var t0 := maxi(world.column_top(floori(x), floori(z)), 0)
	return Vector3(x, t0 + 2.0, z)


func respawn() -> void:
	player.dead = false
	player.health = 20.0
	player.food = 20.0
	player.air = Player.MAX_AIR
	player.vel = Vector3.ZERO
	player.flying = false
	player.active = false
	player.position = Vector3(spawn_point.x, spawn_point.y + 1.0, spawn_point.z)
	player.fall_peak = player.position.y
	respawn_wait = 0.01
	world.update_center(player.position)
	world.force_refresh()


## Ждём прогрузки чанков вокруг точки возрождения, чтобы не провалиться под землю
func _respawn_check(dt: float) -> void:
	if respawn_wait > 0.0:
		respawn_wait += dt
		world.process_queues(25000)
		if world.area_ready(player.position, 1) or respawn_wait > 12.0:
			respawn_wait = 0.0
			player.position = _settle_pos(spawn_point.x, spawn_point.z)
			player.vel = Vector3.ZERO
			player.fall_peak = player.position.y
			player.active = true
	elif player.position.y < -12.0 and not player.dead:
		player.position = _settle_pos(spawn_point.x, spawn_point.z)
		player.vel = Vector3.ZERO
		player.fall_peak = player.position.y


func set_game_mode(m: String) -> void:
	G.mode = m
	if m == "survival":
		player.flying = false
	else:
		player.health = 20.0
	var meta := G.get_world_meta(G.current_world)
	if not meta.is_empty():
		meta["mode"] = m
		G._write_meta(meta)
	hud.layout()
	player.inv_changed.emit()


func save() -> void:
	if state == "loading" or G.current_world == "":
		return
	var d := {
		"seed": G.seed_value,
		"mode": G.mode,
		"player": player.to_dict(),
		"tod": tod,
		"spawn": spawn_point,
		"edits": world.edits_flat(),
		"chests": world.containers,
	}
	G.save_game(d)


func exit_to_menu(do_save: bool) -> void:
	_clear_flag()
	if NetSession.inst != null:
		NetSession.inst.close()
	if do_save:
		save()
	get_tree().paused = false
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if hud:
			hud.on_back()
	elif what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		if what == NOTIFICATION_WM_CLOSE_REQUEST:
			_clear_flag()
		save()


# ---------------- главный цикл ----------------
## Адаптивная оптимизация: если FPS проседает — постепенно снижаем нагрузку
func _adapt(dt: float) -> void:
	if not G.auto_tune or adapt_steps >= 6:
		return
	fps_acc += dt
	fps_n += 1
	adapt_t += dt
	if adapt_t < 5.0:
		return
	var fps := float(fps_n) / maxf(fps_acc, 0.001)
	adapt_t = 0.0
	fps_acc = 0.0
	fps_n = 0
	var target := float(G.max_fps) if G.max_fps > 0 else 60.0
	if fps > target * 0.78 or run_t < 8.0:
		return
	adapt_steps += 1
	if G.shadows > 0:
		G.shadows -= 1
	elif G.leaf_depth:
		G.leaf_depth = false
	elif G.res_scale > 0.62:
		G.res_scale = maxf(0.6, G.res_scale - 0.1)
	elif G.render_distance > 3:
		G.render_distance -= 1
	elif G.ao:
		G.ao = false
	else:
		adapt_steps = 6
	G.apply_shader_settings()
	G.apply_runtime()
	_apply_settings()
	hud.toast("Авто-оптимизация: снижаю нагрузку")
	_log("adapt fps=%d step=%d" % [int(fps), adapt_steps])


func _finish_loading() -> void:
	if not loaded_from_save:
		player.position = _settle_pos(player.position.x, player.position.z)
	player.fall_peak = player.position.y
	_log("loading finished")
	state = "play"
	player.active = true
	world.radius = G.render_distance
	world.force_refresh()
	hud.hide_loading()
	_update_shadow_map(true)
	hud.layout()
	if G.mode == "creative":
		hud.toast("Творческий режим: двойной тап по «прыжку» — полёт")
	else:
		hud.toast("Выживание: удерживай палец на блоке, чтобы ломать")
	if G.auto_tune:
		hud.toast("Авто-настройка: устройство %s" % G.tier_name)


func _process(dt: float) -> void:
	if state == "loading":
		world.process_queues(30000)
		var frac := world.chunk_progress(player.position, 1)
		hud.set_loading(frac)
		load_t += dt
		hud.loading_label.text = "Создаём мир… %d%%" % int(frac * 100.0)
		if load_t > 4.0 and world.threaded and world.meshed.is_empty():
			world.threaded = false
			print("Кубомир: потоки не отдали результат, переключаюсь на однопоточный режим")
		if world.area_ready(player.position, 1):
			_finish_loading()
		return

	if sleeping > 0.0:
		sleeping -= dt
		tod = fposmod(tod + dt * 0.16, 1.0)
		if sleeping <= 0.0 or (tod > 0.0 and tod < 0.1):
			sleeping = 0.0
			hud.toast("Доброе утро!")
	elif G.opts.get("always_day", false):
		tod = 0.25
	else:
		tod = fposmod(tod + dt / 1800.0, 1.0)
	_update_sky()
	sh_t += dt
	if sh_t > 1.5:
		sh_t = 0.0
		_update_shadow_map(false)
	world.update_center(player.position)
	world.process_queues(5000)
	_update_target()
	_update_breaking(dt)

	# облака и фонарь под землёй
	wind += dt * 0.006
	G.cloud_mat.set_shader_parameter("wind", Vector2(wind, wind * 0.4))
	clouds.position = Vector3(player.position.x, 96.0, player.position.z)
	G.set_player_light(player.position, 0.0)
	if not safe_mode:
		weather.update(dt)
	run_t += dt
	_crop_tick(dt)
	_adapt(dt)
	if run_t > 25.0 and not ok_logged:
		ok_logged = true
		_log("played 25s ok")
		_clear_flag()
	env.fog_enabled = player.head_under
	if player.head_under:
		env.fog_light_color = Color(0.08, 0.28, 0.42).lerp(Color(0.3, 0.55, 0.7), G.day * 0.6)
		env.fog_density = 0.09
	_respawn_check(dt)

	if G.mode == "survival" and player.underground and not player.dead:
		cave_t += dt
		if cave_t > 9.0:
			cave_t = 0.0
			_spawn_cave()
	# зомби ночью (только выживание)
	if G.mode == "survival" and G.day < 0.25 and not player.dead:
		zombie_t += dt
		if zombie_t > 6.0:
			zombie_t = 0.0
			_spawn_zombie()

	autosave_t += dt
	if autosave_t > 45.0:
		autosave_t = 0.0
		save()
