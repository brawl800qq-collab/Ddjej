class_name HudW
extends RefCounted
## Виджеты интерфейса: джойстик, круглые кнопки, панель обзора, хотбар, полоски состояния, слоты.


# ============================================================ Джойстик
class Joystick extends Control:
	var radius := 80.0
	var finger := -1
	var vec := Vector2.ZERO
	var sprint := false
	var floating := true
	var active := false
	var base := Vector2.ZERO
	var fixed_center := Vector2(160, 400)
	var alpha := 0.85

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP

	func reset() -> void:
		finger = -1
		active = false
		vec = Vector2.ZERO
		sprint = false
		queue_redraw()

	func _gui_input(e: InputEvent) -> void:
		if e is InputEventScreenTouch:
			if e.pressed and finger == -1:
				if not floating and e.position.distance_to(fixed_center) > radius * 2.4:
					return
				finger = e.index
				active = true
				base = e.position if floating else fixed_center
				_update(e.position)
			elif not e.pressed and e.index == finger:
				reset()
		elif e is InputEventScreenDrag and e.index == finger:
			_update(e.position)

	func _update(p: Vector2) -> void:
		var d := p - base
		var l := d.length()
		vec = d / radius
		if vec.length() > 1.0:
			vec = vec.normalized()
		sprint = l > radius * 1.5
		queue_redraw()

	func _draw() -> void:
		var c := base if active else fixed_center
		var a := alpha * (1.0 if active else 0.6)
		draw_circle(c, radius * 1.15, Color(0.05, 0.06, 0.09, 0.32 * a))
		draw_circle(c, radius * 1.15, Color(1, 1, 1, 0.07 * a))
		draw_arc(c, radius * 1.15, 0.0, TAU, 64, Color(1, 1, 1, 0.7 * a), 4.0, true)
		draw_arc(c, radius * 0.62, 0.0, TAU, 48, Color(1, 1, 1, 0.18 * a), 2.0, true)
		for k in 4:
			var ang := k * PI * 0.5
			var dir := Vector2(cos(ang), sin(ang))
			var perp := Vector2(-dir.y, dir.x)
			var tip := c + dir * (radius * 0.92)
			var pts := PackedVector2Array([tip, tip - dir * 12.0 + perp * 9.0, tip - dir * 12.0 - perp * 9.0])
			draw_colored_polygon(pts, Color(1, 1, 1, 0.55 * a))
		var kc := c + vec * radius
		var col := Color(0.55, 1.0, 0.55) if sprint else Color(1, 1, 1)
		draw_circle(kc, 40.0, Color(0, 0, 0, 0.3 * a))
		draw_circle(kc, 36.0, Color(col.r, col.g, col.b, 0.5 * a))
		draw_arc(kc, 36.0, 0.0, TAU, 40, Color(1, 1, 1, 0.9 * a), 3.0, true)
		draw_circle(kc, 18.0, Color(col.r, col.g, col.b, 0.85 * a))
		if sprint:
			draw_arc(c, radius * 1.55, 0.0, TAU, 56, Color(0.55, 1.0, 0.55, 0.5 * a), 3.0, true)


# ============================================================ Круглая кнопка
class RoundButton extends Control:
	signal pressed
	signal released
	var kind := "jump"
	var finger := -1
	var holding := false
	var toggled_on := false
	var alpha := 0.85

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP

	func reset() -> void:
		if holding:
			released.emit()
		finger = -1
		holding = false
		queue_redraw()

	func _gui_input(e: InputEvent) -> void:
		if e is InputEventScreenTouch:
			if e.pressed and finger == -1:
				finger = e.index
				holding = true
				pressed.emit()
				queue_redraw()
			elif not e.pressed and e.index == finger:
				finger = -1
				holding = false
				released.emit()
				queue_redraw()

	func _draw() -> void:
		var c := size * 0.5
		var rad := minf(size.x, size.y) * 0.5 - 2.0
		var lit := holding or toggled_on
		var a := alpha
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(1, 1, 1, 0.36 * a) if lit else Color(0.08, 0.09, 0.13, 0.5 * a)
		sb.border_color = Color(1, 1, 1, 0.95 * a) if lit else Color(1, 1, 1, 0.55 * a)
		sb.set_border_width_all(3)
		sb.border_width_bottom = 5 if not lit else 3
		sb.set_corner_radius_all(int(rad * 0.4))
		draw_style_box(sb, Rect2(c - Vector2(rad, rad), Vector2(rad, rad) * 2.0))
		var w := Color(1, 1, 1, 0.95 * a)
		var u := rad * 0.5
		match kind:
			"jump":
				draw_polyline(PackedVector2Array([c + Vector2(-u, u * 0.45), c + Vector2(0, -u * 0.55), c + Vector2(u, u * 0.45)]), w, 5.0, true)
				draw_polyline(PackedVector2Array([c + Vector2(-u, u * 1.0), c + Vector2(0, u * 0.0), c + Vector2(u, u * 1.0)]), Color(w.r, w.g, w.b, 0.5), 4.0, true)
			"down":
				draw_polyline(PackedVector2Array([c + Vector2(-u, -u * 0.45), c + Vector2(0, u * 0.55), c + Vector2(u, -u * 0.45)]), w, 5.0, true)
			"fly":
				draw_polyline(PackedVector2Array([c + Vector2(-u, -u * 0.1), c + Vector2(0, -u * 0.95), c + Vector2(u, -u * 0.1)]), w, 4.0, true)
				draw_polyline(PackedVector2Array([c + Vector2(-u, u * 0.55), c + Vector2(0, -u * 0.3), c + Vector2(u, u * 0.55)]), w, 4.0, true)
			"break":
				draw_line(c + Vector2(-u * 0.9, u * 0.9), c + Vector2(u * 0.55, -u * 0.55), w, 5.0, true)
				draw_arc(c + Vector2(u * 0.2, -u * 0.2), u * 0.95, -PI * 0.95, -PI * 0.05, 14, w, 5.0, true)
			"place":
				var hx := u * 0.95
				var hy := u * 0.55
				draw_polyline(PackedVector2Array([c + Vector2(0, -hx), c + Vector2(hx, -hy), c + Vector2(hx, hy), c + Vector2(0, hx), c + Vector2(-hx, hy), c + Vector2(-hx, -hy), c + Vector2(0, -hx)]), w, 3.5, true)
				draw_polyline(PackedVector2Array([c + Vector2(-hx, -hy), c, c + Vector2(hx, -hy)]), w, 3.0, true)
				draw_line(c, c + Vector2(0, hx), w, 3.0, true)
			"inv":
				for ix in 2:
					for iy in 2:
						draw_rect(Rect2(c + Vector2(-u * 0.9 + ix * u * 1.0, -u * 0.9 + iy * u * 1.0), Vector2(u * 0.8, u * 0.8)), w)
			"chat":
				draw_rect(Rect2(c + Vector2(-u * 1.0, -u * 0.8), Vector2(u * 2.0, u * 1.3)), w, false, 3.5)
				draw_colored_polygon(PackedVector2Array([c + Vector2(-u * 0.5, u * 0.5), c + Vector2(-u * 0.5, u * 1.1), c + Vector2(u * 0.1, u * 0.5)]), w)
				for k in 3:
					draw_rect(Rect2(c + Vector2(-u * 0.6 + k * u * 0.55, -u * 0.25), Vector2(u * 0.3, u * 0.3)), w)
			"mic":
				draw_rect(Rect2(c + Vector2(-u * 0.32, -u * 0.95), Vector2(u * 0.64, u * 1.2)), w)
				draw_arc(c + Vector2(0, -u * 0.1), u * 0.7, 0.1, PI - 0.1, 14, w, 3.5, true)
				draw_line(c + Vector2(0, u * 0.6), c + Vector2(0, u * 0.95), w, 3.5)
				draw_line(c + Vector2(-u * 0.4, u * 0.95), c + Vector2(u * 0.4, u * 0.95), w, 3.5)
				if not toggled_on:
					draw_line(c + Vector2(-u * 0.9, -u * 0.9), c + Vector2(u * 0.9, u * 0.9), Color(1, 0.3, 0.3, a), 5.0)
			"more":
				for k in 3:
					draw_rect(Rect2(c + Vector2(-u * 1.0 + k * u * 0.75, -u * 0.15), Vector2(u * 0.5, u * 0.5)), w)
			"pause":
				draw_rect(Rect2(c + Vector2(-u * 0.65, -u * 0.75), Vector2(u * 0.5, u * 1.5)), w)
				draw_rect(Rect2(c + Vector2(u * 0.15, -u * 0.75), Vector2(u * 0.5, u * 1.5)), w)


# ============================================================ Панель обзора и жестов
class LookPad extends Control:
	signal look(rel: Vector2)
	signal tap
	signal hold_start
	signal hold_end
	var finger := -1
	var start := Vector2.ZERO
	var t0 := 0
	var moved := false
	var breaking := false
	var gestures := true

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP

	func reset() -> void:
		if breaking:
			hold_end.emit()
		finger = -1
		breaking = false
		moved = false

	func _gui_input(e: InputEvent) -> void:
		if e is InputEventScreenTouch:
			if e.pressed and finger == -1:
				finger = e.index
				start = e.position
				t0 = Time.get_ticks_msec()
				moved = false
				breaking = false
			elif not e.pressed and e.index == finger:
				if breaking:
					hold_end.emit()
				elif gestures and not moved and Time.get_ticks_msec() - t0 < 300:
					tap.emit()
				finger = -1
				breaking = false
		elif e is InputEventScreenDrag and e.index == finger:
			if not moved and (e.position - start).length() > 14.0:
				moved = true
			if moved:
				look.emit(e.relative)

	func _process(_dt: float) -> void:
		if gestures and finger != -1 and not breaking and not moved and Time.get_ticks_msec() - t0 >= 300:
			breaking = true
			hold_start.emit()


# ============================================================ Хотбар
class Hotbar extends Control:
	signal selected
	var ss := 58.0
	const GAP := 4.0
	var player: Player
	var alpha := 0.85

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_STOP

	func _gui_input(e: InputEvent) -> void:
		if e is InputEventScreenTouch and e.pressed:
			var i := int(e.position.x / (ss + GAP))
			if i >= 0 and i < 9:
				player.sel = i
				player.refresh_hand()
				queue_redraw()
				selected.emit()

	func _draw() -> void:
		var font := ThemeDB.fallback_font
		# общая панель
		var panel := StyleBoxFlat.new()
		panel.bg_color = Color(0.04, 0.04, 0.06, 0.5 * alpha)
		panel.border_color = Color(0, 0, 0, 0.8 * alpha)
		panel.set_border_width_all(2)
		panel.set_corner_radius_all(4)
		draw_style_box(panel, Rect2(Vector2(-4, -4), size + Vector2(8, 8)))
		for i in 9:
			var r := Rect2(i * (ss + GAP), 0, ss, ss)
			draw_rect(r, Color(0.2, 0.2, 0.24, 0.8 * alpha))
			draw_rect(Rect2(r.position + Vector2(2, 2), r.size - Vector2(4, 4)), Color(0.08, 0.08, 0.1, 0.85 * alpha))
			draw_line(r.position + Vector2(1, ss - 1), r.position + Vector2(1, 1), Color(0.55, 0.55, 0.6, 0.55 * alpha), 2.0)
			draw_line(r.position + Vector2(1, 1), r.position + Vector2(ss - 1, 1), Color(0.55, 0.55, 0.6, 0.55 * alpha), 2.0)
			draw_line(r.position + Vector2(1, ss - 1), r.position + Vector2(ss - 1, ss - 1), Color(0, 0, 0, 0.7 * alpha), 2.0)
			draw_line(r.position + Vector2(ss - 1, 1), r.position + Vector2(ss - 1, ss - 1), Color(0, 0, 0, 0.7 * alpha), 2.0)
			if i == player.sel:
				draw_rect(r.grow(3), Color(0, 0, 0, 0.9), false, 7.0)
				draw_rect(r.grow(2), Color(1, 1, 1, 0.98), false, 4.0)
				draw_rect(r.grow(-1), Color(1, 1, 1, 0.12))
			var s: Array = player.inv[i]
			if s[0] != 0:
				draw_texture_rect(G.icon(s[0]), Rect2(r.position + Vector2(ss * 0.13, ss * 0.13), Vector2(ss * 0.74, ss * 0.74)), false)
				if s.size() > 2 and int(s[2]) > 0:
					var md := G.max_dur(int(s[0]))
					if md > 0:
						var fr := clampf(1.0 - float(s[2]) / float(md), 0.0, 1.0)
						draw_rect(Rect2(r.position.x + ss * 0.14, r.position.y + ss - 8.0, ss * 0.72, 4.0), Color(0, 0, 0, 0.9))
						draw_rect(Rect2(r.position.x + ss * 0.14, r.position.y + ss - 8.0, ss * 0.72 * fr, 3.0), Color(1.0 - fr, 0.3 + fr * 0.65, 0.15))
				if s[1] > 1:
					var txt := str(s[1])
					draw_string(font, r.position + Vector2(ss - 25, ss - 5), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color(0, 0, 0, 0.9))
					draw_string(font, r.position + Vector2(ss - 26, ss - 6), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color.WHITE)


# ============================================================ Сердца, еда, броня, воздух
class StatBars extends Control:
	var player: Player
	var ic := 24.0

	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		if player == null:
			return
		var survival := G.mode == "survival"
		var row1 := ic + 3.0
		if not survival:
			return
		for i in 10:
			var hv := player.health - i * 2.0
			var hs := 2 if hv >= 2.0 else (1 if hv >= 1.0 else 0)
			draw_texture_rect(G.heart_tex(hs), Rect2(i * (ic + 2.0), row1, ic, ic), false)
			var fv := player.food - i * 2.0
			var fs := 2 if fv >= 2.0 else (1 if fv >= 1.0 else 0)
			draw_texture_rect(G.food_tex(fs), Rect2(size.x - (i + 1) * (ic + 2.0) + 2.0, row1, ic, ic), false)
		var ar := player.armor_total()
		if ar > 0:
			for i in 10:
				var av := ar - i * 2
				var st := 2 if av >= 2 else (1 if av >= 1 else 0)
				draw_texture_rect(G.shield_tex(st), Rect2(i * (ic + 2.0), 0, ic, ic), false)
		if player.air < 9.99 or player.head_under:
			var n := int(ceil(player.air))
			for i in n:
				draw_texture_rect(G.bubble_tex(), Rect2(size.x - (i + 1) * (ic + 2.0) + 2.0, 0, ic, ic), false)


class Crosshair extends Control:
	func _init() -> void:
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _draw() -> void:
		var c := size * 0.5
		for col in [[Color(0, 0, 0, 0.6), 4.0], [Color(1, 1, 1, 0.9), 2.0]]:
			draw_line(c + Vector2(-11, 0), c + Vector2(11, 0), col[0], col[1])
			draw_line(c + Vector2(0, -11), c + Vector2(0, 11), col[0], col[1])


# ============================================================ Слот инвентаря
class SlotView extends Control:
	signal tapped(index: int)
	var index := 0
	var getter: Callable
	var highlight := false
	var marked := false
	var placeholder: Texture2D = null

	func _init() -> void:
		custom_minimum_size = Vector2(56, 56)
		mouse_filter = Control.MOUSE_FILTER_STOP

	func _gui_input(e: InputEvent) -> void:
		if e is InputEventMouseButton and e.pressed and e.button_index == MOUSE_BUTTON_LEFT:
			tapped.emit(index)

	func _draw() -> void:
		var r := Rect2(Vector2.ZERO, size)
		draw_rect(r, Color(0.04, 0.04, 0.06, 0.95))
		draw_rect(Rect2(Vector2(2, 2), size - Vector2(4, 4)), Color(0.2, 0.2, 0.25, 0.9))
		draw_rect(Rect2(Vector2(3, 3), size - Vector2(6, 6)), Color(0.1, 0.1, 0.13, 0.95))
		draw_line(Vector2(2, size.y - 2), Vector2(2, 2), Color(0.1, 0.1, 0.12, 1), 2.0)
		draw_line(Vector2(2, 2), Vector2(size.x - 2, 2), Color(0.1, 0.1, 0.12, 1), 2.0)
		draw_line(Vector2(size.x - 2, 2), Vector2(size.x - 2, size.y - 2), Color(0.34, 0.34, 0.4, 1), 2.0)
		draw_line(Vector2(2, size.y - 2), Vector2(size.x - 2, size.y - 2), Color(0.34, 0.34, 0.4, 1), 2.0)
		var border := Color(1, 1, 1, 0.22)
		var bw := 2.0
		if marked:
			border = Color(1, 0.85, 0.2)
			bw = 4.0
		elif highlight:
			border = Color(1, 1, 1, 0.85)
			bw = 3.0
		draw_rect(r, border, false, bw)
		var s: Array = getter.call(index) if getter.is_valid() else [0, 0]
		if s[0] != 0:
			draw_texture_rect(G.icon(s[0]), Rect2(Vector2(size.x * 0.14, size.y * 0.14), size * 0.72), false)
			if s.size() > 2 and int(s[2]) > 0:
				var md := G.max_dur(int(s[0]))
				if md > 0:
					var fr := clampf(1.0 - float(s[2]) / float(md), 0.0, 1.0)
					var bw2 := size.x * 0.72
					draw_rect(Rect2(size.x * 0.14, size.y - 9.0, bw2, 5.0), Color(0, 0, 0, 0.85))
					draw_rect(Rect2(size.x * 0.14, size.y - 9.0, bw2 * fr, 5.0), Color(1.0 - fr, 0.25 + fr * 0.7, 0.15))
			if s[1] > 1:
				var font := ThemeDB.fallback_font
				var txt := str(s[1])
				draw_string(font, Vector2(size.x - 24, size.y - 5), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color(0, 0, 0, 0.9))
				draw_string(font, Vector2(size.x - 25, size.y - 6), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
		elif placeholder != null:
			draw_texture_rect(placeholder, Rect2(Vector2(size.x * 0.2, size.y * 0.2), size * 0.6), false, Color(1, 1, 1, 0.25))
