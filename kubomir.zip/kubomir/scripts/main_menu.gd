extends Control
## Главное меню: фон из реальных кадров игры, кнопки, персонаж со сменой скина, окна «Миры» и «Создать мир».

var pages := {}


## Анимированный фон: небо, солнце, облака и слои блочных холмов с деревьями
class MenuBG:
	extends Control
	var t := 0.0

	func _process(dt: float) -> void:
		t += dt
		queue_redraw()

	func _draw() -> void:
		var sz := size
		var top := Color(0.22, 0.46, 0.92)
		var hor := Color(0.78, 0.9, 1.0)
		draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(sz.x, 0), Vector2(sz.x, sz.y), Vector2(0, sz.y)]), PackedColorArray([top, top, hor, hor]))
		var sx := sz.x * 0.74 + sin(t * 0.05) * sz.x * 0.04
		var sy := sz.y * 0.2
		for r in [4, 3, 2, 1]:
			draw_rect(Rect2(sx - 44 - r * 16, sy - 44 - r * 16, 88 + r * 32, 88 + r * 32), Color(1, 0.95, 0.6, 0.07))
		draw_rect(Rect2(sx - 44, sy - 44, 88, 88), Color(1.0, 0.96, 0.6))
		draw_rect(Rect2(sx - 34, sy - 34, 68, 68), Color(1.0, 1.0, 0.85))
		for i in 8:
			var cw := 150.0 + float((i * 53) % 110)
			var x := fposmod(float(i) * 290.0 + t * (10.0 + float(i) * 2.5), sz.x + 500.0) - 250.0
			var y := 50.0 + float((i * 97) % 230)
			draw_rect(Rect2(x, y, cw, 30), Color(1, 1, 1, 0.88))
			draw_rect(Rect2(x + 28, y - 22, cw - 70, 26), Color(1, 1, 1, 0.9))
			draw_rect(Rect2(x + 10, y + 30, cw - 40, 10), Color(0.86, 0.9, 0.96, 0.8))
		var cols := [Color(0.40, 0.62, 0.62), Color(0.30, 0.55, 0.38), Color(0.22, 0.46, 0.22)]
		var tops := [Color(0.5, 0.74, 0.7), Color(0.4, 0.68, 0.45), Color(0.32, 0.6, 0.28)]
		for L in 3:
			var base := sz.y * (0.6 + float(L) * 0.1)
			var amp := 44.0 + float(L) * 20.0
			var off := t * float(L + 1) * 7.0
			var step := 24.0
			var n0 := int(floor(off / step))
			for cx in range(0, int(ceil(sz.x / step)) + 2):
				var wxp := float(cx + n0)
				var h := base - (sin(wxp * 0.11 + float(L) * 3.0) * amp * 0.45 + sin(wxp * 0.043 + float(L)) * amp * 0.7)
				h = floor(h / step) * step
				var px := float(cx) * step - fposmod(off, step)
				draw_rect(Rect2(px, h, step + 1.0, sz.y - h), cols[L])
				draw_rect(Rect2(px, h, step + 1.0, 9), tops[L])
				if L == 2 and (cx + n0) % 7 == 3:
					draw_rect(Rect2(px + 8, h - 60, 8, 60), Color(0.4, 0.27, 0.14))
					draw_rect(Rect2(px - 16, h - 108, 56, 52), Color(0.18, 0.42, 0.16))
					draw_rect(Rect2(px - 4, h - 132, 32, 30), Color(0.22, 0.5, 0.2))
				elif L == 1 and (cx + n0) % 11 == 5:
					draw_rect(Rect2(px + 6, h - 34, 6, 34), Color(0.3, 0.22, 0.12))
					draw_rect(Rect2(px - 8, h - 62, 34, 32), Color(0.2, 0.46, 0.24))
		var g := sz.y - 40.0
		draw_rect(Rect2(0, g, sz.x, 40), Color(0.45, 0.3, 0.18))
		draw_rect(Rect2(0, g, sz.x, 12), Color(0.36, 0.64, 0.24))
		for i in int(sz.x / 40.0) + 1:
			draw_rect(Rect2(i * 40.0, g + 12.0 + float((i * 7) % 3) * 8.0, 8, 8), Color(0.4, 0.26, 0.15))
		draw_rect(Rect2(0, 0, sz.x, sz.y), Color(0, 0, 0, 0.12))


var bg1: TextureRect
var bg2: TextureRect
var bg_t := 0.0
var preview: SkinModel
var preview_vp: SubViewport
var skin_msg: Label
var drag_rot := 0.0
var dialog: FileDialog


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_build_bg()
	_build_main()
	_build_worlds()
	_build_create()
	_build_net()
	_build_settings()
	_show("main")


func _build_bg() -> void:
	var t1 = load("res://assets/menu_bg1.jpg") if ResourceLoader.exists("res://assets/menu_bg1.jpg") else null
	var t2 = load("res://assets/menu_bg2.jpg") if ResourceLoader.exists("res://assets/menu_bg2.jpg") else null
	if t1 == null:
		var bg := MenuBG.new()
		bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(bg)
		return
	for i in 2:
		var tr := TextureRect.new()
		tr.texture = t1 if i == 0 else (t2 if t2 != null else t1)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		tr.pivot_offset = Vector2(640, 360)
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tr.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
		add_child(tr)
		if i == 0:
			bg1 = tr
		else:
			bg2 = tr
			tr.modulate.a = 0.0
	# затемнение слева и виньетка
	var grad := Gradient.new()
	grad.colors = PackedColorArray([Color(0, 0, 0, 0.78), Color(0, 0, 0, 0.35), Color(0, 0, 0, 0.0)])
	grad.offsets = PackedFloat32Array([0.0, 0.5, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0.5)
	gt.fill_to = Vector2(1, 0.5)
	var sh := TextureRect.new()
	sh.texture = gt
	sh.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	sh.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	sh.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(sh)


func _process(dt: float) -> void:
	bg_t += dt
	if bg1 != null:
		var z := 1.04 + 0.04 * sin(bg_t * 0.12)
		bg1.scale = Vector2(z, z)
		if bg2 != null:
			bg2.scale = Vector2(z, z)
			bg2.modulate.a = clampf(sin(bg_t * 0.1) * 1.6 + 0.5, 0.0, 1.0)
	if preview != null:
		preview.rotation.y = 0.55 + drag_rot + sin(bg_t * 0.7) * 0.12
		preview.pose(bg_t * 1.2, 0.08)


func _page() -> Control:
	var c := Control.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(c)
	return c


func _show(name: String) -> void:
	for k in pages:
		pages[k].visible = (k == name)


func _build_main() -> void:
	var p := _page()
	pages["main"] = p
	var left := VBoxContainer.new()
	left.position = Vector2(80, 70)
	left.add_theme_constant_override("separation", 14)
	p.add_child(left)
	var title := G.make_label("КУБОМИР", 120, Color(0.82, 1.0, 0.5))
	title.add_theme_constant_override("outline_size", 22)
	title.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.6))
	title.add_theme_constant_override("shadow_offset_x", 6)
	title.add_theme_constant_override("shadow_offset_y", 8)
	left.add_child(title)
	var sub := G.make_label("Строй. Добывай. Выживай.", 30, Color(0.95, 0.95, 0.9))
	left.add_child(sub)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 26)
	left.add_child(gap)
	var b1 := G.make_button("Играть", Vector2(470, 88), 38, "green")
	b1.pressed.connect(func():
		wl.refresh()
		_show("worlds"))
	left.add_child(b1)
	var bn := G.make_button("Играть по сети", Vector2(470, 72), 28, "blue")
	bn.pressed.connect(func(): _show("net"))
	left.add_child(bn)
	var b2 := G.make_button("Настройки", Vector2(470, 72), 28)
	b2.pressed.connect(func(): _show("settings"))
	left.add_child(b2)
	if OS.get_name() != "Android" and OS.get_name() != "iOS" and OS.get_name() != "Web":
		var b3 := G.make_button("Выход", Vector2(470, 64), 26, "red")
		b3.pressed.connect(func(): get_tree().quit())
		left.add_child(b3)
	var ver := G.make_label("Кубомир v6", 18, Color(1, 1, 1, 0.7))
	ver.position = Vector2(16, 690)
	p.add_child(ver)

	# персонаж справа
	var box := VBoxContainer.new()
	box.position = Vector2(800, 40)
	box.custom_minimum_size = Vector2(400, 640)
	box.add_theme_constant_override("separation", 8)
	p.add_child(box)
	var svc := SubViewportContainer.new()
	svc.custom_minimum_size = Vector2(400, 470)
	svc.stretch = true
	svc.gui_input.connect(func(e: InputEvent):
		if e is InputEventScreenDrag or (e is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)):
			drag_rot += e.relative.x * 0.012)
	box.add_child(svc)
	preview_vp = SubViewport.new()
	preview_vp.size = Vector2i(400, 470)
	preview_vp.transparent_bg = true
	preview_vp.own_world_3d = true
	preview_vp.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	svc.add_child(preview_vp)
	preview = SkinModel.new()
	preview_vp.add_child(preview)
	preview.build(PlayerSkin.current())
	# постамент
	var pad := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.75
	cm.bottom_radius = 0.8
	cm.height = 0.12
	pad.mesh = cm
	var pm := StandardMaterial3D.new()
	pm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	pm.albedo_color = Color(0.1, 0.1, 0.13, 0.75)
	pm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	pad.material_override = pm
	pad.position = Vector3(0, -0.06, 0)
	preview_vp.add_child(pad)
	var cam := Camera3D.new()
	cam.fov = 32
	preview_vp.add_child(cam)
	cam.look_at_from_position(Vector3(0, 1.1, -4.4), Vector3(0, 0.98, 0))
	var nm := G.make_label("Игрок", 30, Color(1, 1, 1))
	nm.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	box.add_child(nm)
	var sk := G.make_button("Сменить скин", Vector2(400, 64), 26, "blue")
	sk.pressed.connect(_pick_skin)
	box.add_child(sk)
	var rs := G.make_button("Сбросить скин", Vector2(400, 46), 19)
	rs.pressed.connect(func():
		PlayerSkin.reset()
		_apply_skin("Скин сброшен"))
	box.add_child(rs)
	skin_msg = G.make_label("", 20, Color(1.0, 0.95, 0.6))
	skin_msg.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	skin_msg.custom_minimum_size = Vector2(400, 0)
	skin_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(skin_msg)


var wl: WorldList


func _apply_skin(msg: String) -> void:
	preview.build(PlayerSkin.current())
	skin_msg.text = msg


func _pick_skin() -> void:
	if DisplayServer.has_feature(DisplayServer.FEATURE_NATIVE_DIALOG_FILE):
		var err := DisplayServer.file_dialog_show("Выбери скин (PNG 64x64)", "", "", false, DisplayServer.FILE_DIALOG_MODE_OPEN_FILE, PackedStringArray(["*.png ; PNG"]), _on_native_skin)
		if err == OK:
			return
	_open_fallback_dialog()


func _on_native_skin(ok: bool, paths: PackedStringArray, _flt: int) -> void:
	if not ok or paths.is_empty():
		return
	_load_skin(paths[0])


func _open_fallback_dialog() -> void:
	if dialog == null:
		dialog = FileDialog.new()
		dialog.access = FileDialog.ACCESS_FILESYSTEM
		dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
		dialog.filters = PackedStringArray(["*.png ; Скин PNG"])
		dialog.title = "Выбери скин (PNG)"
		dialog.use_native_dialog = false
		dialog.size = Vector2i(1000, 600)
		dialog.file_selected.connect(_load_skin)
		add_child(dialog)
	for d in ["/storage/emulated/0/Download", "/storage/emulated/0/Pictures", OS.get_system_dir(OS.SYSTEM_DIR_DOWNLOADS)]:
		if d != "" and DirAccess.dir_exists_absolute(d):
			dialog.current_dir = d
			break
	dialog.popup_centered()


func _load_skin(path: String) -> void:
	if PlayerSkin.set_from_file(path):
		_apply_skin("Скин установлен! Он будет и в игре.")
	else:
		skin_msg.text = "Не удалось открыть файл. Нужен PNG (64x64 или 64x32)."
		if dialog == null or not dialog.visible:
			_open_fallback_dialog()


func _framed(name: String, title: String, back_to := "main") -> VBoxContainer:
	var p := _page()
	pages[name] = p
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.5)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	p.add_child(dim)
	var m := MarginContainer.new()
	m.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	m.add_theme_constant_override("margin_left", 90)
	m.add_theme_constant_override("margin_right", 90)
	m.add_theme_constant_override("margin_top", 26)
	m.add_theme_constant_override("margin_bottom", 26)
	p.add_child(m)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	m.add_child(v)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 20)
	v.add_child(top)
	var back := G.make_button("← Назад", Vector2(200, 58), 24)
	back.pressed.connect(func(): _show(back_to))
	top.add_child(back)
	var t := G.make_label(title, 42, Color(0.85, 1.0, 0.7))
	t.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	top.add_child(t)
	return v


func _build_worlds() -> void:
	var v := _framed("worlds", "Мои миры")
	wl = WorldList.new()
	wl.size_flags_vertical = Control.SIZE_EXPAND_FILL
	wl.play_world.connect(_play)
	wl.create_requested.connect(func(): _show("create"))
	v.add_child(wl)


func _build_create() -> void:
	var v := _framed("create", "Создание мира", "worlds")
	var cp := CreateWorldPage.new()
	cp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	cp.create_world.connect(_play)
	cp.cancel.connect(func(): _show("worlds"))
	v.add_child(cp)


var net_status: Label
var ip_edit: LineEdit


func _build_net() -> void:
	var v := _framed("net", "Игра по сети (2 игрока)")
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", G.panel_style(Color(0.08, 0.09, 0.12, 0.9), Color(0.5, 0.55, 0.62, 0.9)))
	v.add_child(panel)
	var pv := VBoxContainer.new()
	pv.add_theme_constant_override("separation", 12)
	panel.add_child(pv)
	var how := G.make_label("1. Друг запускает свой мир, в паузе жмёт «Открыть для друга» и называет свой IP.\n2. Ты вводишь этот IP ниже и жмёшь «Подключиться».\nГолосовой чат включается автоматически (кнопка микрофона вверху). Один Wi-Fi — без настроек; через интернет нужен проброс UDP-порта 24565 или VPN (Tailscale / ZeroTier).", 20, Color(0.9, 0.95, 0.85))
	how.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	how.custom_minimum_size = Vector2(1000, 0)
	pv.add_child(how)
	ip_edit = LineEdit.new()
	ip_edit.placeholder_text = "IP друга, например 192.168.1.5"
	ip_edit.custom_minimum_size = Vector2(0, 56)
	ip_edit.add_theme_font_size_override("font_size", 26)
	if FileAccess.file_exists("user://last_ip.txt"):
		ip_edit.text = FileAccess.get_file_as_string("user://last_ip.txt").strip_edges()
	pv.add_child(ip_edit)
	var go := G.make_button("Подключиться", Vector2(0, 72), 30, "green")
	go.pressed.connect(func():
		var ip := ip_edit.text.strip_edges()
		if ip == "":
			net_status.text = "Введи IP друга"
			return
		var f := FileAccess.open("user://last_ip.txt", FileAccess.WRITE)
		if f:
			f.store_string(ip)
			f.close()
		var ns := NetSession.get_inst(get_tree())
		if not ns.status.is_connected(_on_net_status):
			ns.status.connect(_on_net_status)
		ns.join(ip))
	pv.add_child(go)
	net_status = G.make_label("", 22, Color(1.0, 0.95, 0.6))
	net_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	net_status.custom_minimum_size = Vector2(1000, 0)
	pv.add_child(net_status)


func _on_net_status(msg: String) -> void:
	if net_status != null:
		net_status.text = msg


func _build_settings() -> void:
	var v := _framed("settings", "Настройки")
	var ss := SettingsScreen.new()
	ss.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(ss)


func _play(id: String) -> void:
	var meta := G.get_world_meta(id)
	if meta.is_empty():
		return
	G.current_world = id
	G.load_opts(meta)
	G.mode = meta.get("mode", "survival")
	G.seed_value = int(meta.get("seed", 1))
	get_tree().change_scene_to_file("res://scenes/game.tscn")
