class_name Player
extends Node3D
## Игрок: движение, плавание, воздух (пузырьки), голод/здоровье, инвентарь, броня, рука.

signal inv_changed
signal damaged
signal died
signal want_drop(id: int, n: int)
signal tool_broke

const WALK := 4.3
const SPRINT := 5.9
const HAND_POS := Vector3(0.42, -0.4, -0.68)
const INV_SIZE := 36
const MAX_AIR := 10.0

var world: World
var cam: Camera3D
var hand: Node3D
var arm: MeshInstance3D
var arm_mat: StandardMaterial3D
var sleeve_mat: StandardMaterial3D
var hand_mat: StandardMaterial3D
var dark_mat: StandardMaterial3D
var cuff_mat: StandardMaterial3D
var item_node: Node3D
var bubbles: CPUParticles3D
var splash_fx: CPUParticles3D

var active := true
var vel := Vector3.ZERO
var yaw := 0.0
var pitch := 0.0
var move_input := Vector2.ZERO   # x вправо, y вперёд
var sprint_input := false
var jump_held := false
var sneak := false
var flying := false
var on_ground := false
var in_water := false
var head_under := false
var sprinting := false
var underground := false
var health := 20.0
var food := 20.0
var air := MAX_AIR
var dead := false
var inv: Array = []
var armor: Array = [0, 0, 0, 0]   # шлем, нагрудник, поножи, ботинки
var armor_wear: Array = [0, 0, 0, 0]
var step_dist := 0.0
var sel := 0
var swing := 0.0
var bob := 0.0
var fall_peak := 0.0
var food_t := 0.0
var regen_t := 0.0
var drown_t := 0.0
var cam_y := 1.62


func _ready() -> void:
	if inv.is_empty():
		for i in INV_SIZE:
			inv.append([0, 0, 0])
	cam = Camera3D.new()
	cam.position = Vector3(0, 1.62, 0)
	cam.fov = 75.0
	cam.near = 0.05
	cam.far = 260.0
	add_child(cam)
	cam.current = true

	hand = Node3D.new()
	hand.position = HAND_POS
	cam.add_child(hand)

	arm_mat = _arm_material(Color(0.86, 0.66, 0.52), 5)
	sleeve_mat = _arm_material(Color(0.1, 0.6, 0.66), 6)
	arm = MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.17, 0.17, 0.62)
	arm.mesh = bm
	arm.material_override = arm_mat
	arm.position = Vector3(0.06, -0.12, 0.08)
	arm.rotation_degrees = Vector3(-8, 14, 0)
	hand.add_child(arm)
	_arm_details()
	refresh_arm()

	item_node = Node3D.new()
	item_node.position = Vector3(-0.06, 0.16, -0.3)
	hand.add_child(item_node)

	# пузырьки под водой
	var bmat := StandardMaterial3D.new()
	bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bmat.albedo_texture = G.bubble_tex()
	bmat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	bmat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	var qm := QuadMesh.new()
	qm.size = Vector2(0.1, 0.1)
	qm.material = bmat

	bubbles = CPUParticles3D.new()
	bubbles.mesh = qm
	bubbles.amount = 12
	bubbles.lifetime = 1.4
	bubbles.emitting = false
	bubbles.direction = Vector3(0, 1, 0)
	bubbles.spread = 25.0
	bubbles.initial_velocity_min = 0.4
	bubbles.initial_velocity_max = 0.9
	bubbles.gravity = Vector3(0, 0.6, 0)
	bubbles.scale_amount_min = 0.5
	bubbles.scale_amount_max = 1.3
	bubbles.emission_shape = CPUParticles3D.EMISSION_SHAPE_SPHERE
	bubbles.emission_sphere_radius = 0.45
	bubbles.local_coords = false
	bubbles.position = Vector3(0, 1.3, 0)
	add_child(bubbles)

	splash_fx = CPUParticles3D.new()
	splash_fx.mesh = qm
	splash_fx.amount = 22
	splash_fx.lifetime = 0.9
	splash_fx.one_shot = true
	splash_fx.explosiveness = 1.0
	splash_fx.emitting = false
	splash_fx.direction = Vector3(0, 1, 0)
	splash_fx.spread = 70.0
	splash_fx.initial_velocity_min = 1.5
	splash_fx.initial_velocity_max = 3.2
	splash_fx.gravity = Vector3(0, -7.0, 0)
	splash_fx.local_coords = false
	splash_fx.position = Vector3(0, 0.4, 0)
	add_child(splash_fx)

	refresh_hand()
	refresh_arm()


# ---------------- инвентарь ----------------
static func max_stack(id: int) -> int:
	if G.ITEM_INFO.has(id):
		var inf: Dictionary = G.ITEM_INFO[id]
		if inf.has("tool") or inf.has("armor"):
			return 1
	return 64


func _norm_inv() -> void:
	for s in inv:
		while s.size() < 3:
			s.append(0)


func held_id() -> int:
	return int(inv[sel][0])


func count_item(id: int) -> int:
	var n := 0
	for s in inv:
		if s[0] == id:
			n += int(s[1])
	return n


func add_item(id: int, n: int = 1, wear: int = 0) -> int:
	var left := n
	var ms := max_stack(id)
	for i in INV_SIZE:
		if left <= 0:
			break
		var s: Array = inv[i]
		if s[0] == id and s[1] < ms:
			var m := mini(ms - int(s[1]), left)
			s[1] += m
			left -= m
	for i in INV_SIZE:
		if left <= 0:
			break
		var s2: Array = inv[i]
		if s2[0] == 0:
			var m2 := mini(ms, left)
			s2[0] = id
			s2[1] = m2
			s2[2] = wear
			left -= m2
	inv_changed.emit()
	refresh_hand()
	return left


func remove_item(id: int, n: int) -> void:
	var left := n
	for i in range(INV_SIZE - 1, -1, -1):
		if left <= 0:
			break
		var s: Array = inv[i]
		if s[0] == id:
			var m := mini(int(s[1]), left)
			s[1] -= m
			left -= m
			if s[1] <= 0:
				s[0] = 0
				s[1] = 0
	inv_changed.emit()
	refresh_hand()


func consume_held() -> void:
	if G.mode == "creative":
		return
	var s: Array = inv[sel]
	s[1] -= 1
	if s[1] <= 0:
		s[0] = 0
		s[1] = 0
	inv_changed.emit()
	if s[0] == 0:
		refresh_hand()


func drop_slot(i: int, all: bool) -> void:
	var s: Array = inv[i]
	if s[0] == 0:
		return
	var n := int(s[1]) if all else 1
	var id := int(s[0])
	s[1] -= n
	if s[1] <= 0:
		s[0] = 0
		s[1] = 0
	inv_changed.emit()
	refresh_hand()
	want_drop.emit(id, n)


func can_craft(r: Dictionary) -> bool:
	var need: Dictionary = r["in"]
	for id in need:
		if count_item(id) < int(need[id]):
			return false
	return true


func craft(r: Dictionary) -> bool:
	if not can_craft(r):
		return false
	var need: Dictionary = r["in"]
	for id in need:
		remove_item(id, int(need[id]))
	var left := add_item(int(r["out"]), int(r["n"]))
	if left > 0:
		want_drop.emit(int(r["out"]), left)
	return true


# ---------------- броня ----------------
func equip_from(i: int) -> bool:
	var id := int(inv[i][0])
	var a := G.armor_slot(id)
	if a < 0:
		return false
	var old: int = armor[a]
	var old_wear: int = int(armor_wear[a])
	armor[a] = id
	armor_wear[a] = int(inv[i][2])
	var s: Array = inv[i]
	s[1] -= 1
	if s[1] <= 0:
		s[0] = 0
		s[1] = 0
	if old != 0:
		var left := add_item(old, 1, old_wear)
		if left > 0:
			want_drop.emit(old, left)
	inv_changed.emit()
	refresh_arm()
	return true


func unequip(a: int) -> void:
	var id: int = armor[a]
	if id == 0:
		return
	var left := add_item(id, 1, int(armor_wear[a]))
	if left > 0:
		want_drop.emit(id, left)
	armor[a] = 0
	armor_wear[a] = 0
	inv_changed.emit()
	refresh_arm()


func armor_total() -> int:
	var t := 0
	for a in armor:
		t += G.armor_points(a)
	return t


func _arm_material(c: Color, prio: int) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_texture = G.noise_tex(Color(0.92, 0.92, 0.92))
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.albedo_color = c
	m.no_depth_test = true
	m.render_priority = prio
	return m


func _arm_part(size: Vector3, pos: Vector3, mat: Material, rot := Vector3.ZERO) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot
	arm.add_child(mi)


## Детали руки: рукав с манжетой, кисть, пальцы, большой палец, костяшки
func _arm_details() -> void:
	dark_mat = _arm_material(Color(0.62, 0.43, 0.32), 7)
	cuff_mat = _arm_material(Color(0.07, 0.42, 0.48), 7)
	hand_mat = _arm_material(Color(0.9, 0.7, 0.56), 6)
	var dark := dark_mat
	var cuff := cuff_mat
	var hand_m := hand_mat
	_arm_part(Vector3(0.19, 0.19, 0.3), Vector3(0, 0, 0.17), sleeve_mat)
	_arm_part(Vector3(0.2, 0.2, 0.04), Vector3(0, 0, 0.02), cuff)
	_arm_part(Vector3(0.175, 0.15, 0.13), Vector3(0, 0, -0.26), hand_m)
	for fx in [-0.03, 0.0, 0.03]:
		_arm_part(Vector3(0.012, 0.152, 0.1), Vector3(fx, 0, -0.29), dark)
	for kx in [-0.06, -0.02, 0.02, 0.06]:
		_arm_part(Vector3(0.03, 0.02, 0.03), Vector3(kx, 0.078, -0.22), dark)
	_arm_part(Vector3(0.05, 0.06, 0.11), Vector3(-0.1, 0.0, -0.22), hand_m, Vector3(0, 18, 0))
	_arm_part(Vector3(0.16, 0.01, 0.02), Vector3(0, 0.0, -0.19), dark)


func _avg(img: Image, x: int, y: int, w: int, h: int) -> Color:
	var r := 0.0
	var g := 0.0
	var b := 0.0
	var n := 0.0
	for yy in range(y, y + h):
		for xx in range(x, x + w):
			var c := img.get_pixel(xx, yy)
			if c.a > 0.5:
				r += c.r
				g += c.g
				b += c.b
				n += 1.0
	if n < 1.0:
		return Color(0.86, 0.66, 0.52)
	return Color(r / n, g / n, b / n)


func refresh_arm() -> void:
	if arm_mat == null:
		return
	var img := PlayerSkin.current()
	var skin_c := _avg(img, 44, 26, 4, 6)
	var sleeve_c := _avg(img, 44, 20, 4, 3)
	arm_mat.albedo_color = skin_c
	hand_mat.albedo_color = skin_c.lightened(0.04)
	dark_mat.albedo_color = skin_c.darkened(0.25)
	cuff_mat.albedo_color = sleeve_c.darkened(0.2)
	var chest: int = armor[1]
	if chest != 0:
		sleeve_mat.albedo_color = G.held_info(chest).get("col", sleeve_c)
	else:
		sleeve_mat.albedo_color = sleeve_c


func refresh_hand() -> void:
	if item_node == null:
		return
	item_node.rotation_degrees = Vector3.ZERO
	for c in item_node.get_children():
		c.queue_free()
	var id := held_id()
	if id == 0:
		return
	var mi := MeshInstance3D.new()
	var is_blk: bool = G.is_block(id) and not G.is_plant(id)
	mi.mesh = World.held_mesh(id, 0.32 if is_blk else 0.44)
	if is_blk:
		mi.rotation_degrees = Vector3(12, -38, 0)
		item_node.position = Vector3(-0.02, 0.0, -0.3)
	else:
		# ручка (низ-лево картинки) в кулаке, лезвие вверх-вперёд
		mi.scale = Vector3(-1, 1, 1)
		mi.position = Vector3(-0.22, 0.22, 0.0)
		item_node.position = Vector3(0.0, -0.1, -0.2)
		item_node.rotation_degrees = Vector3(0, -18, 8)
	item_node.add_child(mi)


func wear_held(n := 1) -> void:
	if G.mode == "creative":
		return
	var s: Array = inv[sel]
	var id := int(s[0])
	var md := G.max_dur(id)
	if md <= 0 or not G.held_info(id).has("tool"):
		return
	s[2] = int(s[2]) + n
	if int(s[2]) >= md:
		s[0] = 0
		s[1] = 0
		s[2] = 0
		Sfx.play(self, "break_wood", null, -2.0, 0.7)
		tool_broke.emit()
		refresh_hand()
	inv_changed.emit()


func _wear_armor() -> void:
	var changed := false
	for a in 4:
		var id := int(armor[a])
		if id == 0:
			continue
		armor_wear[a] = int(armor_wear[a]) + 1
		changed = true
		if int(armor_wear[a]) >= G.max_dur(id):
			armor[a] = 0
			armor_wear[a] = 0
			tool_broke.emit()
			refresh_arm()
	if changed:
		inv_changed.emit()


# ---------------- здоровье ----------------
func hurt(n: float, ignore_armor := false) -> void:
	if G.mode == "creative" or dead:
		return
	var dmg := n
	if not ignore_armor:
		dmg *= 1.0 - minf(0.8, float(armor_total()) * 0.04)
	health -= dmg
	if not ignore_armor and dmg > 0.0:
		_wear_armor()
	damaged.emit()
	Sfx.play(self, "hurt", null, -3.0, Sfx.rnd_pitch())
	if health <= 0.0:
		health = 0.0
		dead = true
		Sfx.play(self, "death")
		died.emit()


func toggle_fly() -> void:
	flying = not flying
	vel.y = 0.0


# ---------------- сохранение ----------------
func to_dict() -> Dictionary:
	return {"pos": position, "yaw": yaw, "pitch": pitch, "health": health, "food": food, "air": air, "inv": inv, "armor": armor, "armor_wear": armor_wear, "sel": sel, "flying": flying}


func from_dict(d: Dictionary) -> void:
	position = d.get("pos", position)
	yaw = d.get("yaw", 0.0)
	pitch = d.get("pitch", 0.0)
	health = d.get("health", 20.0)
	food = d.get("food", 20.0)
	air = d.get("air", MAX_AIR)
	var li: Array = d.get("inv", [])
	if li.size() == INV_SIZE:
		inv = li
	armor = d.get("armor", [0, 0, 0, 0])
	armor_wear = d.get("armor_wear", [0, 0, 0, 0])
	_norm_inv()
	sel = d.get("sel", 0)
	flying = d.get("flying", false)
	if item_node:
		refresh_hand()
		refresh_arm()
	inv_changed.emit()


# ---------------- физика (в _process: плавно при любом FPS) ----------------
func _simulate(dt: float) -> void:
	var kb := Vector2(
		(1 if Input.is_key_pressed(KEY_D) else 0) - (1 if Input.is_key_pressed(KEY_A) else 0),
		(1 if Input.is_key_pressed(KEY_W) else 0) - (1 if Input.is_key_pressed(KEY_S) else 0))
	var mv := move_input + kb
	if mv.length() > 1.0:
		mv = mv.normalized()
	var jump := jump_held or Input.is_key_pressed(KEY_SPACE)
	var sneaking := sneak or Input.is_key_pressed(KEY_SHIFT)

	var fwd := Vector3(-sin(yaw), 0, -cos(yaw))
	var right := Vector3(cos(yaw), 0, -sin(yaw))
	var wish := fwd * mv.y + right * mv.x

	var was_in := in_water
	var frac := world.water_level_at(position, 1.8)
	var feet_w := world.get_block(floori(position.x), floori(position.y + 0.2), floori(position.z)) in [G.WATER, G.SEAWEED]
	in_water = feet_w or frac > 0.3
	head_under = world.get_block(floori(position.x), floori(position.y + cam_y), floori(position.z)) in [G.WATER, G.SEAWEED]
	if in_water and not was_in and vel.y < -4.0 and not flying:
		splash_fx.restart()
		splash_fx.emitting = true
		Sfx.play(self, "splash", null, -2.0, Sfx.rnd_pitch())

	sprinting = (sprint_input or Input.is_key_pressed(KEY_CTRL)) and mv.y > 0.3 and not sneaking
	var speed := WALK
	if sprinting:
		speed = SPRINT
	if sneaking and not flying:
		speed = 1.7
	if in_water and not flying:
		speed *= 0.5
	if flying:
		speed = 14.0 if sprinting else 9.0

	var target := wish * speed
	var acc := 14.0 if on_ground else 6.0
	if in_water and not flying:
		acc = 4.0
	if flying:
		acc = 8.0
	var k := minf(1.0, acc * dt)
	vel.x = lerpf(vel.x, target.x, k)
	vel.z = lerpf(vel.z, target.z, k)

	if flying:
		var vy := 0.0
		if jump:
			vy += 7.5
		if sneaking:
			vy -= 7.5
		vel.y = lerpf(vel.y, vy, minf(1.0, 10.0 * dt))
	elif in_water:
		# плавание: плавучесть у поверхности, управление взглядом под водой
		# без движения медленно тонем; плывя вперёд держимся у поверхности,
		# взгляд вниз/вверх — ныряем/всплываем; прыжок — грести вверх
		var vt := -0.85
		if mv.length() > 0.2:
			vt = 0.0 if not head_under else -0.3
			if mv.y > 0.3 and not sneaking and (head_under or pitch < -0.35):
				vt = sin(pitch) * speed * mv.y * 1.2
		if jump:
			vt = 3.2
		if sneaking:
			vt = -3.0
		vel.y = lerpf(vel.y, vt, minf(1.0, 3.5 * dt))
	else:
		vel.y = maxf(vel.y - 30.0 * dt, -55.0)
		if jump and on_ground:
			vel.y = 9.0

	var old := position
	var was_ground := on_ground
	var r := world.move_body(position, vel, 0.3, 1.8, dt)
	position = r["pos"]
	vel = r["vel"]
	on_ground = r["on_ground"]

	if sneaking and was_ground and not flying and not on_ground and vel.y <= 0.0:
		if not world.body_collides(Vector3(position.x, position.y - 0.05, position.z), 0.3, 1.8):
			position.x = old.x
			position.z = old.z
			vel.x = 0.0
			vel.z = 0.0
			on_ground = true

	# авто-прыжок / выход из воды на берег (по щупу перед игроком, работает и на бегу)
	if wish.length() > 0.2 and not flying and not sneaking:
		var wn := wish.normalized()
		var reach := 0.62 if sprinting else 0.52
		var ax := floori(position.x + wn.x * reach)
		var az := floori(position.z + wn.z * reach)
		var fy := floori(position.y + 0.1)
		if world.solid_top(ax, fy, az) > 0.62 and not world.is_solid_at(ax, fy + 1, az) and not world.is_solid_at(ax, fy + 2, az):
			var here_ok := not world.is_solid_at(floori(position.x), fy + 2, floori(position.z))
			if on_ground and G.autojump and here_ok:
				vel.y = 9.2
				vel.x = wn.x * speed
				vel.z = wn.z * speed
			elif in_water and (r["hit_x"] or r["hit_z"]):
				vel.y = maxf(vel.y, 6.5)

	# шаги
	if on_ground and not flying and Vector2(vel.x, vel.z).length() > 1.0:
		step_dist += Vector2(vel.x, vel.z).length() * dt
		if step_dist > (2.6 if sprinting else 2.0):
			step_dist = 0.0
			var below := world.get_block(floori(position.x), floori(position.y - 0.15), floori(position.z))
			var sk := Sfx.kind_of(below) if below > 0 else "grass"
			if in_water:
				sk = "water"
			Sfx.play(self, "step_" + sk, null, -9.0, Sfx.rnd_pitch(0.9, 1.1))
	elif in_water and not flying and Vector2(vel.x, vel.z).length() > 1.0:
		step_dist += Vector2(vel.x, vel.z).length() * dt
		if step_dist > 2.4:
			step_dist = 0.0
			Sfx.play(self, "step_water", null, -12.0, Sfx.rnd_pitch(0.8, 1.0))

	if flying and on_ground and not jump:
		flying = false

	# урон от падения
	if flying or in_water:
		fall_peak = position.y
	elif on_ground:
		var fall := fall_peak - position.y
		if fall > 3.3:
			hurt(floorf(fall - 3.0))
		fall_peak = position.y
	else:
		fall_peak = maxf(fall_peak, position.y)

	# воздух
	if head_under and not flying:
		if G.mode == "survival":
			air = maxf(0.0, air - dt * (MAX_AIR / 15.0))
			if air <= 0.0:
				drown_t += dt
				if drown_t >= 1.0:
					drown_t = 0.0
					hurt(2.0, true)
	else:
		air = minf(MAX_AIR, air + dt * 6.0)
		drown_t = 0.0
	bubbles.emitting = head_under
	bubbles.global_position = Vector3(position.x, position.y + cam_y - 0.2, position.z)

	# голод и регенерация
	if G.mode == "survival" and not dead:
		food_t += dt * (2.5 if (sprinting and mv.length() > 0.3) else 1.0)
		if food_t > 45.0:
			food_t = 0.0
			food = maxf(0.0, food - 1.0)
		regen_t += dt
		if regen_t > 4.0:
			regen_t = 0.0
			if food >= 15.0 and health < 20.0:
				health = minf(20.0, health + 1.0)
			elif food <= 0.0 and health > 1.0:
				hurt(1.0, true)

	var top := world.column_top(floori(position.x), floori(position.z))
	underground = top >= 0 and position.y + 1.5 < top - 1


func _process(dt: float) -> void:
	if world != null and not dead and active:
		_simulate(minf(dt, 0.05))

	rotation.y = yaw
	cam.rotation.x = pitch
	var target_y := 1.62
	if sneak or Input.is_key_pressed(KEY_SHIFT):
		target_y = 1.4
	cam_y = lerpf(cam_y, target_y, minf(1.0, 12.0 * dt))
	cam.position.y = cam_y
	cam.fov = lerpf(cam.fov, 83.0 if sprinting else 75.0, minf(1.0, 8.0 * dt))

	swing = maxf(0.0, swing - dt * 3.6)
	var moving := Vector2(vel.x, vel.z).length() > 0.5 and (on_ground or in_water)
	if moving:
		bob += dt * (9.0 if not in_water else 5.0)
	var s := sin((1.0 - swing) * PI) if swing > 0.0 else 0.0
	hand.position = HAND_POS + Vector3(sin(bob * 0.5) * 0.012, absf(sin(bob)) * 0.012 + s * 0.08, -s * 0.22)
	hand.rotation = Vector3(-s * 0.9, s * 0.25, 0.0)

	var v := lerpf(0.45, 1.0, G.day)
	G.hand_mat.albedo_color = Color(v, v, v, 1.0)
	if World._ext_mat != null:
		World._ext_mat.albedo_color = Color(v, v, v, 1.0)
	if World._model_mat != null:
		World._model_mat.set_shader_parameter("tint", Vector3(v, v, v))
	var base := arm_mat.albedo_color
	arm_mat.albedo_color = Color(base.r, base.g, base.b, 1.0)
