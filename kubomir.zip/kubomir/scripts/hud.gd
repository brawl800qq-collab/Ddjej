class_name Hud
extends CanvasLayer
## Интерфейс игры: управление (жесты/кнопки), хотбар, состояние, инвентарь, пауза, смерть, загрузка.

var game
var player: Player
var root: Control
var controls: Control
var joy: HudW.Joystick
var look: HudW.LookPad
var hotbar: HudW.Hotbar
var stats: HudW.StatBars
var cross: HudW.Crosshair
var btn_jump: HudW.RoundButton
var btn_down: HudW.RoundButton
var btn_fly: HudW.RoundButton
var btn_break: HudW.RoundButton
var btn_place: HudW.RoundButton
var btn_inv: HudW.RoundButton
var btn_pause: HudW.RoundButton
var btn_chat: HudW.RoundButton
var btn_mic: HudW.RoundButton
var net_label: Label
var net_btn: Button
var coords_label: Label
var chat_log: Label
var chat_panel: Control
var chat_edit: LineEdit
var chat_lines: Array = []
var chat_t := 0.0
var opt_btns := {}
var toast_label: Label
var fps_label: Label
var dmg_rect: ColorRect
var water_rect: ColorRect
var loading_panel: Control
var loading_label: Label
var loading_bar: ProgressBar
var death_panel: Control
var pause_panel: Control
var settings_panel: Control
var inv_ui: InventoryUI

var last_jump := 0
var toast_t := 0.0
var dmg_t := 0.0


func _init() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 10


func _full(c: Control) -> void:
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func setup(g, p: Player) -> void:
	game = g
	player = p
	root = Control.new()
	_full(root)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(root)
	_build_controls()
	_build_overlays()
	_build_inventory()
	_build_chat()
	_build_pause()
	_build_death()
	_build_loading()
	player.damaged.connect(func(): dmg_t = 0.45)
	player.died.connect(show_death)
	root.resized.connect(layout)
	G.settings_changed.connect(layout)
	layout()


# ====================================================================
func _build_controls() -> void:
	controls = Control.new()
	_full(controls)
	controls.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(controls)

	look = HudW.LookPad.new()
	_full(look)
	look.look.connect(func(rel: Vector2): game.on_look(rel))
	look.tap.connect(func(): game.on_tap())
	look.hold_start.connect(func(): game.set_breaking(true))
	look.hold_end.connect(func(): game.set_breaking(false))
	controls.add_child(look)

	cross = HudW.Crosshair.new()
	_full(cross)
	controls.add_child(cross)

	joy = HudW.Joystick.new()
	controls.add_child(joy)

	btn_jump = _btn("jump")
	btn_jump.pressed.connect(_on_jump_down)
	btn_jump.released.connect(func(): player.jump_held = false)
	btn_down = _btn("down")
	btn_down.pressed.connect(func(): player.sneak = true)
	btn_down.released.connect(func(): player.sneak = false)
	btn_fly = _btn("fly")
	btn_fly.pressed.connect(func():
		player.toggle_fly()
		btn_fly.toggled_on = player.flying)
	btn_break = _btn("break")
	btn_break.pressed.connect(func(): game.set_breaking(true))
	btn_break.released.connect(func(): game.set_breaking(false))
	btn_place = _btn("place")
	btn_place.pressed.connect(func(): game.on_tap())
	btn_inv = _btn("inv")
	btn_inv.pressed.connect(func(): open_inventory(0))
	btn_inv.kind = "more"
	btn_pause = _btn("pause")
	btn_pause.pressed.connect(open_pause)
	btn_chat = _btn("chat")
	btn_chat.pressed.connect(open_chat)
	btn_mic = _btn("mic")
	btn_mic.pressed.connect(func():
		var ns := NetSession.inst
		if ns != null:
			ns.mic_on = not ns.mic_on
			var online := ns.active
			var msg := "Микрофон включён" if ns.mic_on else "Микрофон выключен"
			if not online:
				msg += " (слышат друзья в сетевой игре)"
			toast(msg, 1.8)
		else:
			toast("Микрофон доступен в сетевой игре", 1.8))

	hotbar = HudW.Hotbar.new()
	hotbar.player = player
	hotbar.selected.connect(func():
		var id := player.held_id()
		if id != 0:
			toast(G.item_name(id), 1.2))
	controls.add_child(hotbar)

	stats = HudW.StatBars.new()
	stats.player = player
	controls.add_child(stats)


func _btn(kind: String) -> HudW.RoundButton:
	var b := HudW.RoundButton.new()
	b.kind = kind
	controls.add_child(b)
	return b


func _place_btn(b: HudW.RoundButton, cx: float, cy: float, d: float) -> void:
	b.size = Vector2(d, d)
	b.position = Vector2(cx - d * 0.5, cy - d * 0.5)
	b.alpha = G.hud_alpha
	b.queue_redraw()


func layout() -> void:
	if root == null:
		return
	var W := root.size.x
	var H := root.size.y
	if W < 10.0 or H < 10.0:
		return
	var sc := G.btn_scale
	var lefty := G.lefty
	var al := G.hud_alpha

	look.gestures = G.scheme == 0
	cross.visible = true

	# джойстик: зона на стороне движения
	var zw := W * 0.45
	joy.size = Vector2(zw, H * 0.7)
	joy.position = Vector2(W - zw if lefty else 0.0, H * 0.3)
	joy.radius = 80.0 * sc
	joy.floating = G.floating_joy
	joy.alpha = al
	var fc_x := joy.radius * 1.8
	if lefty:
		fc_x = zw - joy.radius * 1.8
	joy.fixed_center = Vector2(fc_x, joy.size.y - joy.radius * 1.8)
	joy.queue_redraw()

	# кнопки действий на противоположной стороне
	var m := -1.0 if lefty else 1.0
	var rx := 0.0 if lefty else W
	var by := H
	_place_btn(btn_jump, rx - m * 115.0 * sc, by - 125.0 * sc, 108.0 * sc)
	_place_btn(btn_down, rx - m * 255.0 * sc, by - 82.0 * sc, 74.0 * sc)
	btn_fly.visible = G.mode == "creative"
	btn_fly.toggled_on = player.flying
	_place_btn(btn_fly, rx - m * 115.0 * sc, by - 255.0 * sc, 66.0 * sc)
	var buttons_mode := G.scheme == 1
	btn_break.visible = buttons_mode
	btn_place.visible = buttons_mode
	_place_btn(btn_break, rx - m * 270.0 * sc, by - 195.0 * sc, 88.0 * sc)
	_place_btn(btn_place, rx - m * 150.0 * sc, by - 300.0 * sc if G.mode == "creative" else by - 262.0 * sc, 88.0 * sc)
	if buttons_mode and G.mode == "creative":
		_place_btn(btn_fly, rx - m * 385.0 * sc, by - 125.0 * sc, 62.0 * sc)
	_place_btn(btn_chat, W * 0.5 - 44.0 * sc, 44.0, 56.0 * sc)
	_place_btn(btn_pause, W * 0.5 + 44.0 * sc, 44.0, 56.0 * sc)
	_place_btn(btn_mic, W * 0.5 + 132.0 * sc, 44.0, 56.0 * sc)

	# хотбар и состояние
	var ss := clampf(58.0 * sc, 44.0, 72.0)
	var hw := 9.0 * (ss + 4.0) - 4.0
	hotbar.ss = ss
	hotbar.alpha = al
	hotbar.size = Vector2(hw, ss)
	hotbar.position = Vector2((W - hw) * 0.5, H - ss - 10.0)
	hotbar.queue_redraw()
	_place_btn(btn_inv, hotbar.position.x + hw + ss * 0.55, hotbar.position.y + ss * 0.5, ss * 0.95)
	stats.ic = clampf(24.0 * sc, 18.0, 30.0)
	stats.size = Vector2(hw, stats.ic * 2.0 + 4.0)
	stats.position = Vector2(hotbar.position.x, hotbar.position.y - stats.size.y - 4.0)

	toast_label.position = Vector2(0, H * 0.62)
	toast_label.size = Vector2(W, 40)
	fps_label.visible = G.show_fps
	chat_log.position = Vector2(14, 70)
	chat_log.size = Vector2(W * 0.5, 200)
	coords_label.position = Vector2(14, 38)


func _build_overlays() -> void:
	water_rect = ColorRect.new()
	water_rect.color = Color(0.1, 0.3, 0.65, 0.38)
	_full(water_rect)
	water_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	water_rect.visible = false
	root.add_child(water_rect)
	root.move_child(water_rect, 0)

	dmg_rect = ColorRect.new()
	dmg_rect.color = Color(0.9, 0.05, 0.05, 0.0)
	_full(dmg_rect)
	dmg_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(dmg_rect)

	toast_label = G.make_label("", 26)
	toast_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	toast_label.modulate.a = 0.0
	root.add_child(toast_label)

	fps_label = G.make_label("", 20, Color(1, 1, 0.6))
	fps_label.position = Vector2(14, 8)
	fps_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(fps_label)


func _build_chat() -> void:
	coords_label = G.make_label("", 20, Color(1, 1, 1))
	coords_label.add_theme_constant_override("outline_size", 6)
	coords_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	coords_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(coords_label)
	chat_log = G.make_label("", 20, Color(1, 1, 1))
	chat_log.add_theme_constant_override("outline_size", 6)
	chat_log.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	chat_log.mouse_filter = Control.MOUSE_FILTER_IGNORE
	chat_log.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	root.add_child(chat_log)

	chat_panel = Control.new()
	_full(chat_panel)
	chat_panel.visible = false
	root.add_child(chat_panel)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.35)
	_full(dim)
	chat_panel.add_child(dim)
	var box := PanelContainer.new()
	box.add_theme_stylebox_override("panel", G.panel_style(Color(0.1, 0.11, 0.14, 0.95), Color(0.02, 0.02, 0.03)))
	box.position = Vector2(40, 16)
	box.custom_minimum_size = Vector2(1200, 0)
	chat_panel.add_child(box)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	box.add_child(v)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	v.add_child(row)
	chat_edit = LineEdit.new()
	chat_edit.placeholder_text = "Сообщение или команда (/help)"
	chat_edit.custom_minimum_size = Vector2(0, 52)
	chat_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	chat_edit.add_theme_font_size_override("font_size", 22)
	chat_edit.text_submitted.connect(func(_t): _send_chat())
	row.add_child(chat_edit)
	var send := G.make_button("Отправить", Vector2(170, 52), 22)
	send.pressed.connect(_send_chat)
	row.add_child(send)
	var cl := G.make_button("✕", Vector2(60, 52), 22)
	cl.pressed.connect(close_chat)
	row.add_child(cl)
	var chips := HFlowContainer.new()
	chips.add_theme_constant_override("h_separation", 8)
	chips.add_theme_constant_override("v_separation", 6)
	v.add_child(chips)
	for c in ["/святое 1", "/святое 0", "/time set день", "/time set ночь", "/weather ясно", "/weather дождь", "/weather гроза", "/help"]:
		var b := G.make_button(c, Vector2(0, 40), 18)
		b.pressed.connect(func():
			chat_edit.text = c
			chat_edit.caret_column = c.length()
			if c in ["/help", "/святое 1", "/святое 0"] or c.begins_with("/time") or c.begins_with("/weather"):
				_send_chat())
		chips.add_child(b)


func say(text: String) -> void:
	chat_lines.append([text, 9.0])
	while chat_lines.size() > 7:
		chat_lines.pop_front()
	_refresh_chat()


func _refresh_chat() -> void:
	var t := ""
	for l in chat_lines:
		t += l[0] + "\n"
	chat_log.text = t


func open_chat() -> void:
	if game.state != "play" or player.dead:
		return
	_release_inputs()
	game.state = "ui"
	chat_panel.visible = true
	chat_edit.text = ""
	chat_edit.grab_focus()
	for l in chat_lines:
		l[1] = maxf(l[1], 9.0)


func close_chat() -> void:
	chat_panel.visible = false
	chat_edit.release_focus()
	if game.state == "ui":
		game.state = "play"


func _send_chat() -> void:
	var t := chat_edit.text.strip_edges()
	chat_edit.text = ""
	if t == "":
		close_chat()
		return
	if t.begins_with("/"):
		say("> " + t)
		for r in Commands.run(game, t):
			say(r)
	else:
		say("<Я> " + t)
		if NetSession.inst != null:
			NetSession.inst.send_chat(t)
	chat_edit.grab_focus()


func toast(text: String, t := 2.6) -> void:
	toast_label.text = text
	toast_label.modulate.a = 1.0
	toast_t = t


# ====================================================================
func _build_inventory() -> void:
	inv_ui = InventoryUI.new()
	root.add_child(inv_ui)
	inv_ui.setup(player)
	inv_ui.closed.connect(func(): game.state = "play")


func open_inventory(station: int) -> void:
	if game.state != "play" or player.dead:
		return
	_release_inputs()
	game.state = "ui"
	inv_ui.open(station)


func open_chest(p: Vector3i) -> void:
	if game.state != "play" or player.dead:
		return
	if not game.world.containers.has(p):
		var sl := []
		for i in 27:
			sl.append([0, 0, 0])
		game.world.containers[p] = sl
	_release_inputs()
	game.state = "ui"
	inv_ui.open_chest(game.world.containers[p])


func close_inventory() -> void:
	inv_ui.close()


# ====================================================================
func _build_pause() -> void:
	pause_panel = Control.new()
	_full(pause_panel)
	pause_panel.visible = false
	root.add_child(pause_panel)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	_full(dim)
	pause_panel.add_child(dim)
	var cc := CenterContainer.new()
	_full(cc)
	pause_panel.add_child(cc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 8)
	cc.add_child(v)
	var t := G.make_label("Пауза", 44)
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	var b1 := G.make_button("Продолжить", Vector2(420, 68), 28)
	b1.pressed.connect(close_pause)
	v.add_child(b1)
	var b2 := G.make_button("Настройки", Vector2(420, 62), 26)
	b2.pressed.connect(open_settings)
	v.add_child(b2)
	for o in [["coords", "Координаты"], ["always_day", "Всегда день"], ["cheats", "Читы (команды)"]]:
		var ob := G.make_button("", Vector2(420, 56), 22)
		var key: String = o[0]
		var nm: String = o[1]
		ob.pressed.connect(func():
			G.set_opt(key, not G.opts.get(key, false))
			_refresh_opts())
		v.add_child(ob)
		opt_btns[key] = [ob, nm]
	net_btn = G.make_button("Открыть для друга (онлайн)", Vector2(420, 56), 22, "blue")
	net_btn.pressed.connect(func():
		var ns := NetSession.get_inst(get_tree())
		if not ns.active:
			ns.host(game)
		_refresh_opts())
	v.add_child(net_btn)
	net_label = G.make_label("", 16, Color(0.85, 1.0, 0.8))
	net_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	net_label.custom_minimum_size = Vector2(420, 0)
	net_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(net_label)
	var b3 := G.make_button("Сохранить и выйти в меню", Vector2(420, 62), 24)
	b3.pressed.connect(func():
		get_tree().paused = false
		game.exit_to_menu(true))
	v.add_child(b3)

	# настройки поверх паузы
	settings_panel = Control.new()
	_full(settings_panel)
	settings_panel.visible = false
	root.add_child(settings_panel)
	var bg := ColorRect.new()
	bg.color = Color(0.1, 0.11, 0.14, 0.97)
	_full(bg)
	settings_panel.add_child(bg)
	var mg := MarginContainer.new()
	_full(mg)
	mg.add_theme_constant_override("margin_left", 50)
	mg.add_theme_constant_override("margin_right", 50)
	mg.add_theme_constant_override("margin_top", 24)
	mg.add_theme_constant_override("margin_bottom", 24)
	settings_panel.add_child(mg)
	var sv := VBoxContainer.new()
	sv.add_theme_constant_override("separation", 12)
	mg.add_child(sv)
	var top := HBoxContainer.new()
	top.add_theme_constant_override("separation", 20)
	sv.add_child(top)
	var back := G.make_button("← Назад", Vector2(180, 54), 22)
	back.pressed.connect(func(): settings_panel.visible = false)
	top.add_child(back)
	top.add_child(G.make_label("Настройки", 36, Color(0.85, 1.0, 0.7)))
	var ss := SettingsScreen.new()
	ss.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sv.add_child(ss)


func _refresh_opts() -> void:
	var nss := NetSession.inst
	if nss != null and nss.active and nss.is_host:
		net_btn.visible = false
		var ips := nss.local_ips()
		var t := "Сервер открыт. Порт UDP %d\nIP в Wi-Fi: %s" % [NetSession.PORT, ", ".join(ips) if not ips.is_empty() else "—"]
		if nss.public_ip != "":
			t += "\nIP в интернете: " + nss.public_ip
		if nss.upnp_msg != "":
			t += "\n" + nss.upnp_msg
		net_label.text = t
	elif nss != null and nss.active:
		net_btn.visible = false
		net_label.text = "Вы играете на сервере друга"
	else:
		net_btn.visible = true
		net_label.text = ""
	for k in opt_btns:
		var on: bool = G.opts.get(k, false)
		opt_btns[k][0].text = "%s: %s" % [opt_btns[k][1], "ВКЛ" if on else "выкл"]


func open_settings() -> void:
	settings_panel.visible = true


func open_pause() -> void:
	if game.state != "play" or player.dead:
		return
	_release_inputs()
	_refresh_opts()
	pause_panel.visible = true
	get_tree().paused = true


func close_pause() -> void:
	pause_panel.visible = false
	settings_panel.visible = false
	get_tree().paused = false


func on_back() -> void:
	if chat_panel.visible:
		close_chat()
	elif settings_panel.visible:
		settings_panel.visible = false
	elif pause_panel.visible:
		close_pause()
	elif inv_ui.visible:
		close_inventory()
	elif game.state == "play":
		open_pause()


# ====================================================================
func _build_death() -> void:
	death_panel = Control.new()
	_full(death_panel)
	death_panel.visible = false
	root.add_child(death_panel)
	var dim := ColorRect.new()
	dim.color = Color(0.45, 0.02, 0.02, 0.6)
	_full(dim)
	death_panel.add_child(dim)
	var cc := CenterContainer.new()
	_full(cc)
	death_panel.add_child(cc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 14)
	cc.add_child(v)
	var t := G.make_label("Вы погибли!", 64, Color(1, 0.85, 0.85))
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(t)
	var b1 := G.make_button("Возродиться", Vector2(400, 68), 28)
	b1.pressed.connect(func():
		death_panel.visible = false
		game.respawn())
	v.add_child(b1)
	var b2 := G.make_button("В главное меню", Vector2(400, 60), 24)
	b2.pressed.connect(func(): game.exit_to_menu(true))
	v.add_child(b2)


func show_death() -> void:
	_release_inputs()
	death_panel.visible = true


func _build_loading() -> void:
	loading_panel = ColorRect.new()
	(loading_panel as ColorRect).color = Color(0.08, 0.09, 0.12, 1.0)
	_full(loading_panel)
	root.add_child(loading_panel)
	var cc := CenterContainer.new()
	_full(cc)
	loading_panel.add_child(cc)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 16)
	cc.add_child(v)
	loading_label = G.make_label("Создаём мир…", 36)
	loading_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	v.add_child(loading_label)
	loading_bar = ProgressBar.new()
	loading_bar.custom_minimum_size = Vector2(520, 30)
	loading_bar.max_value = 1.0
	loading_bar.show_percentage = false
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.45, 0.8, 0.35)
	fill.set_corner_radius_all(6)
	var bgs := StyleBoxFlat.new()
	bgs.bg_color = Color(0.2, 0.2, 0.25)
	bgs.set_corner_radius_all(6)
	loading_bar.add_theme_stylebox_override("fill", fill)
	loading_bar.add_theme_stylebox_override("background", bgs)
	v.add_child(loading_bar)


func set_loading(frac: float) -> void:
	loading_bar.value = clampf(frac, 0.0, 1.0)


func hide_loading() -> void:
	loading_panel.visible = false


# ====================================================================
func _release_inputs() -> void:
	joy.reset()
	look.reset()
	btn_jump.reset()
	btn_down.reset()
	btn_break.reset()
	player.move_input = Vector2.ZERO
	player.sprint_input = false
	player.jump_held = false
	player.sneak = false
	game.set_breaking(false)


func _on_jump_down() -> void:
	player.jump_held = true
	var now := Time.get_ticks_msec()
	if G.mode == "creative" and now - last_jump < 320:
		player.toggle_fly()
		btn_fly.toggled_on = player.flying
	last_jump = now


func _process(dt: float) -> void:
	if player == null:
		return
	if game.state == "play" and not player.dead:
		player.move_input = Vector2(joy.vec.x, -joy.vec.y)
		player.sprint_input = joy.sprint
	stats.queue_redraw()
	hotbar.queue_redraw()
	water_rect.visible = player.head_under
	if toast_t > 0.0:
		toast_t -= dt
		toast_label.modulate.a = clampf(toast_t / 0.6, 0.0, 1.0)
	if dmg_t > 0.0:
		dmg_t -= dt
		dmg_rect.color.a = clampf(dmg_t / 0.45, 0.0, 1.0) * 0.35
	elif dmg_rect.color.a != 0.0:
		dmg_rect.color.a = 0.0
	if chat_lines.size() > 0 and not chat_panel.visible:
		var ch := false
		for l in chat_lines:
			l[1] -= dt
		while chat_lines.size() > 0 and chat_lines[0][1] <= 0.0:
			chat_lines.pop_front()
			ch = true
		if ch:
			_refresh_chat()
	chat_log.modulate.a = 1.0
	var nsx := NetSession.inst
	var net_on := nsx != null and nsx.active and not nsx.multiplayer.get_peers().is_empty()
	btn_mic.visible = true
	if nsx != null:
		btn_mic.toggled_on = nsx.mic_on
	coords_label.visible = G.opts.get("coords", false)
	if coords_label.visible:
		var pp := player.position
		coords_label.text = "XYZ: %.1f / %.1f / %.1f" % [pp.x, pp.y, pp.z]
	if G.show_fps:
		fps_label.text = "FPS: %d" % Engine.get_frames_per_second()
	btn_fly.toggled_on = player.flying
	if Input.is_action_just_pressed("ui_cancel"):
		on_back()
