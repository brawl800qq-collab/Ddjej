class_name WorldGen
extends RefCounted
## Генератор чанков. Чистая функция от сида: безопасно вызывается из потока.

const CS := 16
const CH := 64
const SEA := 24

const B_PLAINS := 0
const B_FOREST := 1
const B_DESERT := 2
const B_SNOW := 3
const B_MOUNT := 4
const B_OCEAN := 5
const B_BIRCH := 6
const B_BEACH := 7
const B_SWAMP := 8
const B_MEADOW := 9

var seed_value := 0
var cont: FastNoiseLite
var hn: FastNoiseLite
var mn: FastNoiseLite
var tn: FastNoiseLite
var wn: FastNoiseLite
var fn: FastNoiseLite
var cn: FastNoiseLite
var vn: FastNoiseLite
var ln: FastNoiseLite
var kn: FastNoiseLite
var sn: FastNoiseLite

const SC := 192
var cache: StreamCache = null


func _mk(sd: int, freq: float, oct: int) -> FastNoiseLite:
	var n := FastNoiseLite.new()
	n.seed = sd
	n.frequency = freq
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.fractal_type = FastNoiseLite.FRACTAL_FBM
	n.fractal_octaves = oct
	return n


func setup(s: int) -> void:
	seed_value = s
	cont = _mk(s, 0.0016, 3)
	hn = _mk(s + 1, 0.012, 4)
	mn = _mk(s + 2, 0.0035, 3)
	tn = _mk(s + 3, 0.0011, 2)
	wn = _mk(s + 4, 0.0013, 2)
	fn = _mk(s + 5, 0.03, 2)
	cn = _mk(s + 6, 0.045, 2)
	vn = _mk(s + 7, 0.006, 2)
	ln = _mk(s + 8, 0.008, 2)
	kn = _mk(s + 9, 0.022, 2)
	sn = _mk(s + 10, 0.018, 2)


## «спагетти»-пещеры: длинные извилистые туннели; у поверхности иногда открываются входами
func _spag(wx: int, y: int, wz: int, h: int) -> bool:
	var v := kn.get_noise_3d(wx * 0.7, y * 1.2, wz * 0.7)
	if absf(v) > 0.07:
		return false
	if y > h - 6 and h > SEA + 2:
		if _f01(wx >> 3, wz >> 3, 41) > 0.12:
			return false
	return absf(sn.get_noise_3d(wx * 0.7, y * 1.2, wz * 0.7)) < 0.09


func _ih(a: int, b: int, salt: int) -> int:
	var h: int = (a * 73856093) ^ (b * 19349663) ^ (seed_value * 83492791) ^ (salt * 2654435761)
	h = (h ^ (h >> 13)) * 1274126177
	h = h ^ (h >> 16)
	return h & 0x7fffffff


func _f01(a: int, b: int, salt: int) -> float:
	return float(_ih(a, b, salt) % 100000) / 100000.0


## x = высота поверхности, y = биом
func col_info(wx: int, wz: int) -> Vector2i:
	var c := cont.get_noise_2d(wx, wz) + 0.3
	var n := hn.get_noise_2d(wx, wz)
	var h: float
	var mm := 0.0
	if c < -0.12:
		var dd := clampf((-0.12 - c) / 0.28, 0.0, 1.0)
		var depth := 3.0 + 17.0 * smoothstep(0.0, 1.0, dd)
		h = SEA - depth + n * 1.5
	else:
		var land := clampf((c + 0.12) * 6.0, 0.0, 1.0)
		h = SEA - 2.0 + minf((c + 0.12) * 40.0, 5.0) + n * 5.0 * land
		if c > 0.04:
			h = maxf(h, SEA + 2.0)
		var mt := mn.get_noise_2d(wx, wz)
		mm = maxf(0.0, mt - 0.2) * 70.0 * clampf(c * 5.0, 0.0, 1.0)
		mm *= 1.0 + 0.3 * (1.0 - absf(fn.get_noise_2d(wx, wz) * 1.7))
		h += mm
		# настоящие озёра (плавные впадины)
		if c > 0.08 and mm < 3.0:
			var lk := ln.get_noise_2d(wx, wz)
			var f := smoothstep(0.42, 0.62, lk)
			if f > 0.0:
				h = lerpf(h, SEA - 2.0 - (lk - 0.42) * 12.0, f)
	var hi := clampi(int(h), 2, CH - 12)
	var b := B_PLAINS
	if c < -0.12:
		b = B_OCEAN
	elif hi <= SEA + 1 and c < 0.08:
		b = B_BEACH
	elif mm > 9.0:
		b = B_MOUNT
	else:
		var t := tn.get_noise_2d(wx, wz)
		var w := wn.get_noise_2d(wx, wz)
		t += (fn.get_noise_2d(wx * 0.3, wz * 0.3)) * 0.06
		if t > 0.27 and w < 0.02:
			b = B_DESERT
		elif t < -0.34:
			b = B_SNOW
		elif w > 0.42 and t > -0.05 and t < 0.4:
			b = B_SWAMP
			if fn.get_noise_2d(wx, wz) > 0.2:
				hi = SEA - 1
		elif w > 0.1:
			b = B_BIRCH if vn.get_noise_2d(wx, wz) > 0.25 else B_FOREST
		elif vn.get_noise_2d(wx, wz) > 0.4:
			b = B_MEADOW
	return Vector2i(hi, b)


func _setl(d: PackedByteArray, lx: int, y: int, lz: int, id: int, only_air: bool) -> void:
	if lx < 0 or lx >= CS or lz < 0 or lz >= CS or y < 0 or y >= CH:
		return
	var idx := lx + lz * CS + y * 256
	if only_air and d[idx] != 0:
		return
	d[idx] = id


func _getl(d: PackedByteArray, lx: int, y: int, lz: int) -> int:
	if lx < 0 or lx >= CS or lz < 0 or lz >= CS or y < 0 or y >= CH:
		return -1
	return d[lx + lz * CS + y * 256]


func _rand_flower(rng: RandomNumberGenerator) -> int:
	var k := rng.randi() % 5
	match k:
		0:
			return G.RED_FLOWER
		1:
			return G.YELLOW_FLOWER
		2:
			return G.FLOWER_BLUE
		3:
			return G.FLOWER_WHITE
		_:
			return G.FLOWER_PINK


# ------------------------------------------------------------------
func generate(key: Vector2i, edit: Dictionary) -> Dictionary:
	var d := PackedByteArray()
	d.resize(CS * CS * CH)
	var tops := PackedInt32Array()
	tops.resize(CS * CS)
	var bio := PackedByteArray()
	bio.resize(CS * CS)
	var rng := RandomNumberGenerator.new()
	rng.seed = _ih(key.x, key.y, 5)
	var wx0 := key.x * CS
	var wz0 := key.y * CS
	var spawns := []
	var mount_cols := 0
	var cave_air := PackedInt32Array()
	var chests := []

	# 1. рельеф
	for lz in CS:
		for lx in CS:
			var wx := wx0 + lx
			var wz := wz0 + lz
			var col := lx + lz * CS
			var info := col_info(wx, wz)
			var h := info.x
			var b := info.y
			tops[col] = h
			bio[col] = b
			var f := fn.get_noise_2d(wx, wz)
			var top_id := G.GRASS
			var sub_id := G.DIRT
			if b == B_DESERT or b == B_BEACH:
				top_id = G.SAND
				sub_id = G.SAND
			elif b == B_SNOW:
				top_id = G.SNOW
			elif b == B_MOUNT:
				mount_cols += 1
				var snowline := SEA + 20.0 + f * 8.0
				if h > snowline or (h > SEA + 12 and vn.get_noise_2d(wx, wz) > 0.62):
					top_id = G.SNOW
					sub_id = G.STONE
				elif h > SEA + 14:
					if f > 0.32:
						top_id = G.ANDESITE
					elif f > -0.2:
						top_id = G.STONE
					elif f > -0.34:
						top_id = G.MOSSY
					else:
						top_id = G.GRAVEL
					sub_id = G.STONE
			elif b == B_OCEAN:
				if h < SEA - 12:
					top_id = G.GRAVEL
					sub_id = G.GRAVEL
				elif h < SEA - 6 and f < 0.0:
					top_id = G.GRAVEL
					sub_id = G.SAND
				else:
					top_id = G.SAND
					sub_id = G.SAND
			if h < SEA - 1 and b != B_OCEAN and b != B_BEACH and b != B_DESERT:
				top_id = G.DIRT
				sub_id = G.DIRT
			var wet_cave := h < SEA - 1
			var sea_mask := -1.0
			if h < SEA - 3:
				sea_mask = ln.get_noise_2d(wx * 0.5, wz * 0.5)
			for y in range(0, h + 1):
				var id := G.STONE
				if y == 0:
					id = G.BEDROCK
				elif y == h:
					id = top_id
				elif y >= h - 3:
					id = sub_id
				elif b == B_DESERT and y >= h - 6:
					id = G.SANDSTONE
				elif y > 4 and y < h - 1 and (cn.get_noise_3d(wx, y * 1.6, wz) > 0.56 or _spag(wx, y, wz, h)):
					if wet_cave:
						d[col + y * 256] = G.WATER
					else:
						cave_air.append(col + y * 256)
					continue
				elif sea_mask > 0.32 and y > 5 and y <= h:
					var kv := absf(kn.get_noise_3d(wx, y * 1.4, wz))
					if kv < (0.05 if sea_mask < 0.5 else 0.1):
						d[col + y * 256] = G.WATER
						continue
				if id == G.STONE and (y < 8 or (y < 11 and (wx * 73 + wz * 151 + y * 31) % 5 < 2)):
					id = G.DEEPSLATE
				d[col + y * 256] = id
			for y in range(h + 1, SEA + 1):
				d[col + y * 256] = G.WATER
			if h < SEA and tn.get_noise_2d(wx, wz) < -0.3:
				d[col + SEA * 256] = G.ICE

	# 2. руды и пятна
	_veins(d, rng, G.COAL_ORE, 24, 8, 5, CH - 8, G.D_COAL)
	_veins(d, rng, G.IRON_ORE, 8, 7, 2, 40, G.D_IRON)
	_veins(d, rng, G.IRON_ORE, 3, 7, 8, 24, G.D_IRON)
	_veins(d, rng, G.COPPER_ORE, 5, 8, 8, 40, G.D_COPPER)
	_veins(d, rng, G.GOLD_ORE, 2, 5, 1, 16, G.D_GOLD)
	_veins(d, rng, G.REDSTONE_ORE, 3, 5, 1, 9, G.D_REDSTONE)
	if rng.randf() < 0.4:
		_veins(d, rng, G.REDSTONE_ORE, 1, 6, 1, 5, G.D_REDSTONE)
	if rng.randf() < 0.8:
		_veins(d, rng, G.DIAMOND_ORE, 1, 4, 1, 10, G.D_DIAMOND)
	if rng.randf() < 0.3:
		_veins(d, rng, G.DIAMOND_ORE, 1, 3, 1, 10, G.D_DIAMOND)
	if bio[8 + 8 * CS] == B_MOUNT:
		_veins(d, rng, G.EMERALD_ORE, 3, 1, 8, 50)
	_cave_ores(d, rng, cave_air)
	_veins(d, rng, G.DIRT, 4, 14, 8, 50)
	_veins(d, rng, G.GRAVEL, 3, 12, 6, 40)

	# 3. структуры, заданные заранее (деревня, корабль)
	var vil := Structures.village_for_cell(self, floori(float(key.x) / Structures.VCELL), floori(float(key.y) / Structures.VCELL))

	# 4. деревья, кактусы
	_trees(d, wx0, wz0, vil)

	# 5. трава, цветы, водоросли
	for lz in CS:
		for lx in CS:
			var col := lx + lz * CS
			var h := tops[col]
			var b: int = bio[col]
			if h < SEA - 1 and h > 2:
				# подводные растения
				var top_blk := d[col + h * 256]
				if (top_blk == G.SAND or top_blk == G.GRAVEL or top_blk == G.DIRT) and h <= SEA - 2:
					var fw := fn.get_noise_2d(wx0 + lx, wz0 + lz)
					var p := 0.16 if fw > 0.1 else 0.012
					if rng.randf() < p:
						var hgt := 1 + rng.randi() % 3
						for y in range(h + 1, mini(h + 1 + hgt, SEA - 1)):
							d[col + y * 256] = G.SEAWEED
				continue
			if h <= SEA or h + 2 >= CH:
				continue
			if d[col + h * 256] != G.GRASS or d[col + (h + 1) * 256] != 0:
				continue
			var pg := 0.0
			var pf := 0.01
			match b:
				B_PLAINS:
					pg = 0.30
					pf = 0.035
				B_MEADOW:
					pg = 0.22
					pf = 0.24
				B_FOREST:
					pg = 0.18
					pf = 0.012
				B_BIRCH:
					pg = 0.20
					pf = 0.02
				B_SWAMP:
					pg = 0.28
					pf = 0.02
				B_MOUNT:
					pg = 0.2
					pf = 0.07
			var r := rng.randf()
			if r < pg:
				d[col + (h + 1) * 256] = G.TALL_GRASS
			elif r < pg + pf:
				d[col + (h + 1) * 256] = _rand_flower(rng)

	# 6. ручьи и водопады
	_streams(d, wx0, wz0, tops, rng)

	# 7. шахты (в том числе затопленные)
	_mines(d, key, tops)

	# 8. деревня и затонувший корабль
	if not vil.is_empty():
		Structures.apply_village(self, d, vil, wx0, wz0, tops, spawns, chests)
	Structures.apply_ship(self, d, key, wx0, wz0)

	# 9. карта высот
	var hm := PackedByteArray()
	hm.resize(CS * CS)
	var maxy := SEA + 1
	for c2 in CS * CS:
		var top := 0
		for y in range(CH - 1, -1, -1):
			var id := d[c2 + y * 256]
			if id != 0 and id != G.WATER:
				top = y
				break
		hm[c2] = top
		maxy = maxi(maxy, top)

	# 10. правки игрока
	var had_edits := not edit.is_empty()
	if had_edits:
		for pv in edit:
			var p: Vector3i = pv
			var ix := p.x - wx0
			var iz := p.z - wz0
			if ix >= 0 and ix < CS and iz >= 0 and iz < CS and p.y >= 0 and p.y < CH:
				d[ix + iz * CS + p.y * 256] = edit[pv]
				maxy = maxi(maxy, p.y)
		for c3 in CS * CS:
			var top2 := 0
			for y in range(CH - 1, -1, -1):
				var id2 := d[c3 + y * 256]
				if id2 != 0 and id2 != G.WATER:
					top2 = y
					break
			hm[c3] = top2

	# 11. животные и рыбы
	if not had_edits:
		_spawn_life(spawns, rng, tops, bio, wx0, wz0, vil.is_empty())

	return {"key": key, "d": d, "hm": hm, "bio": bio, "maxy": mini(maxy + 2, CH - 1), "spawns": spawns, "chests": chests}


func _spawn_life(spawns: Array, rng: RandomNumberGenerator, tops: PackedInt32Array, bio: PackedByteArray, wx0: int, wz0: int, no_village: bool) -> void:
	if no_village and rng.randf() < 0.3:
		var lx2 := 3 + rng.randi() % 10
		var lz2 := 3 + rng.randi() % 10
		var c4 := lx2 + lz2 * CS
		var bb: int = bio[c4]
		if tops[c4] > SEA + 1 and bb != B_DESERT and bb != B_OCEAN and bb != B_BEACH:
			var kinds := ["pig", "cow", "sheep", "chicken"]
			if bb == B_SNOW or bb == B_MOUNT:
				kinds = ["sheep", "sheep", "cow"]
			var kind: String = kinds[rng.randi() % kinds.size()]
			var cnt := 1 + rng.randi() % 3
			for k in cnt:
				spawns.append([kind, Vector3(wx0 + lx2 + 0.5 + rng.randf() * 2.0, tops[c4] + 1.5, wz0 + lz2 + 0.5 + rng.randf() * 2.0)])
	# рыбы
	var lx3 := 2 + rng.randi() % 12
	var lz3 := 2 + rng.randi() % 12
	var c5 := lx3 + lz3 * CS
	var h5 := tops[c5]
	if h5 < SEA - 3 and rng.randf() < 0.55:
		var cnt2 := 3 + rng.randi() % 4
		var fk := rng.randi() % 3
		for k in cnt2:
			var y5 := h5 + 2.0 + rng.randf() * maxf(1.0, float(SEA - 3 - h5 - 1))
			spawns.append(["fish%d" % fk, Vector3(wx0 + lx3 + rng.randf() * 3.0, minf(y5, SEA - 2.0), wz0 + lz3 + rng.randf() * 3.0)])
	# дельфины в глубоком океане
	if h5 < SEA - 11 and bio[c5] == B_OCEAN and rng.randf() < 0.07:
		var cnt3 := 1 + rng.randi() % 3
		for k in cnt3:
			spawns.append(["dolphin", Vector3(wx0 + lx3 + rng.randf() * 4.0, SEA - 3.0, wz0 + lz3 + rng.randf() * 4.0)])


# ------------------------------------------------------------------
func _veins(d: PackedByteArray, rng: RandomNumberGenerator, id: int, attempts: int, size: int, ymin: int, ymax: int, deep_id := 0) -> void:
	for a in attempts:
		var x := rng.randi() % CS
		var z := rng.randi() % CS
		var y := ymin + rng.randi() % maxi(1, ymax - ymin)
		for s in size:
			if x >= 0 and x < CS and z >= 0 and z < CS and y > 0 and y < CH:
				var idx := x + z * CS + y * 256
				var cur := d[idx]
				if cur == G.STONE:
					d[idx] = id
				elif deep_id > 0 and cur == G.DEEPSLATE:
					d[idx] = deep_id
			x += rng.randi() % 3 - 1
			y += rng.randi() % 3 - 1
			z += rng.randi() % 3 - 1


## Руды на стенах пещер (как в майнкрафте: чем глубже — тем ценнее)
func _cave_ores(d: PackedByteArray, rng: RandomNumberGenerator, cave_air: PackedInt32Array) -> void:
	var dirs := [Vector3i(1, 0, 0), Vector3i(-1, 0, 0), Vector3i(0, 1, 0), Vector3i(0, -1, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1)]
	for i in cave_air:
		if rng.randf() > 0.014:
			continue
		var col := i % 256
		var y := i / 256
		var lx := col % CS
		var lz := col / CS
		var dv: Vector3i = dirs[rng.randi() % 6]
		var nx := lx + dv.x
		var ny := y + dv.y
		var nz := lz + dv.z
		if nx < 0 or nx >= CS or nz < 0 or nz >= CS or ny < 1 or ny >= CH:
			continue
		var ni := nx + nz * CS + ny * 256
		var cur := d[ni]
		var deep := cur == G.DEEPSLATE
		if cur != G.STONE and not deep:
			continue
		var r := rng.randf()
		var ore := 0
		var dore := 0
		if ny <= 9:
			if r < 0.12:
				ore = G.DIAMOND_ORE
				dore = G.D_DIAMOND
			elif r < 0.40:
				ore = G.REDSTONE_ORE
				dore = G.D_REDSTONE
			elif r < 0.52:
				ore = G.GOLD_ORE
				dore = G.D_GOLD
			elif r < 0.70:
				ore = G.IRON_ORE
				dore = G.D_IRON
			elif r < 0.80:
				ore = G.COPPER_ORE
				dore = G.D_COPPER
			else:
				ore = G.COAL_ORE
				dore = G.D_COAL
		elif ny <= 22:
			if r < 0.02 and ny <= 12:
				ore = G.DIAMOND_ORE
				dore = G.D_DIAMOND
			elif r < 0.08:
				ore = G.GOLD_ORE
				dore = G.D_GOLD
			elif r < 0.14 and ny <= 16:
				ore = G.REDSTONE_ORE
				dore = G.D_REDSTONE
			elif r < 0.50:
				ore = G.IRON_ORE
				dore = G.D_IRON
			elif r < 0.70:
				ore = G.COPPER_ORE
				dore = G.D_COPPER
			else:
				ore = G.COAL_ORE
				dore = G.D_COAL
		else:
			if r < 0.5:
				ore = G.COAL_ORE
				dore = G.D_COAL
			elif r < 0.78:
				ore = G.IRON_ORE
				dore = G.D_IRON
			else:
				ore = G.COPPER_ORE
				dore = G.D_COPPER
		d[ni] = dore if deep else ore


func _stream_path(cx: int, cz: int) -> Array:
	if cache == null:
		return _compute_path(cx, cz)
	var key := "%d:%d" % [cx, cz]
	cache.mtx.lock()
	if cache.data.has(key):
		var r: Array = cache.data[key]
		cache.mtx.unlock()
		return r
	cache.mtx.unlock()
	var pts := _compute_path(cx, cz)
	cache.mtx.lock()
	cache.data[key] = pts
	cache.mtx.unlock()
	return pts


func _compute_path(cx: int, cz: int) -> Array:
	var pts := []
	if _ih(cx, cz, 91) % 100 >= 38:
		return pts
	var bx := 0
	var bz := 0
	var bh := -1
	for k in 14:
		var px := cx * SC + _ih(cx, cz, 100 + k) % SC
		var pz := cz * SC + _ih(cx, cz, 130 + k) % SC
		var ci := col_info(px, pz)
		if ci.y == B_MOUNT and ci.x > bh:
			bh = ci.x
			bx = px
			bz = pz
	if bh < SEA + 18:
		return pts
	var x := bx
	var z := bz
	var visited := {}
	var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	var last := Vector2i(0, 0)
	for step in 110:
		var h := col_info(x, z).x
		pts.append(Vector3i(x, h, z))
		visited[Vector2i(x, z)] = true
		if h <= SEA:
			break
		var best := Vector2i(x, z)
		var bs := 9999.0
		var bnh := 9999
		for dv in dirs:
			var nx: int = x + dv.x
			var nz: int = z + dv.y
			if visited.has(Vector2i(nx, nz)):
				continue
			var nh := col_info(nx, nz).x
			var sc := float(nh) + (0.0 if dv == last else 0.5) + _f01(nx, nz, 7) * 0.3
			if sc < bs:
				bs = sc
				best = Vector2i(nx, nz)
				bnh = nh
				last = dv
		if bnh > h + 1 or best == Vector2i(x, z):
			break
		x = best.x
		z = best.y
	return pts


func _streams(d: PackedByteArray, wx0: int, wz0: int, tops: PackedInt32Array, rng: RandomNumberGenerator) -> void:
	var c0x := floori(float(wx0) / SC)
	var c0z := floori(float(wz0) / SC)
	for cx in range(c0x - 1, c0x + 2):
		for cz in range(c0z - 1, c0z + 2):
			if _ih(cx, cz, 91) % 100 >= 38:
				continue
			var pts := _stream_path(cx, cz)
			if pts.is_empty():
				continue
			var path_set := {}
			for pv in pts:
				var p: Vector3i = pv
				path_set[Vector2i(p.x, p.z)] = p.y
			for i in pts.size():
				var p: Vector3i = pts[i]
				if p.x < wx0 - 2 or p.x > wx0 + CS + 1 or p.z < wz0 - 2 or p.z > wz0 + CS + 1:
					continue
				# русло
				var lx := p.x - wx0
				var lz := p.z - wz0
				if lx >= 0 and lx < CS and lz >= 0 and lz < CS and p.y > SEA:
					var top_y: int = p.y
					if i + 1 < pts.size():
						var nx: Vector3i = pts[i + 1]
						if p.y - nx.y >= 2:
							# водопад: столб воды по стене вниз
							var nlx := nx.x - wx0
							var nlz := nx.z - wz0
							if nlx >= 0 and nlx < CS and nlz >= 0 and nlz < CS:
								for y in range(nx.y, p.y + 1):
									d[nlx + nlz * CS + y * 256] = G.WATER
					d[lx + lz * CS + top_y * 256] = G.WATER
					for y in range(top_y + 1, mini(top_y + 3, CH)):
						var cur := d[lx + lz * CS + y * 256]
						if cur == G.TALL_GRASS or cur == G.LEAVES or cur == G.SPRUCE_LEAVES or cur == G.LOG or cur == G.SPRUCE_LOG or cur == G.RED_FLOWER or cur == G.YELLOW_FLOWER or cur == G.FLOWER_BLUE or cur == G.FLOWER_WHITE or cur == G.FLOWER_PINK:
							d[lx + lz * CS + y * 256] = 0
				# берега с травой
				for ox in range(-1, 2):
					for oz in range(-1, 2):
						if ox == 0 and oz == 0:
							continue
						var qx := p.x + ox
						var qz := p.z + oz
						var qlx := qx - wx0
						var qlz := qz - wz0
						if qlx < 0 or qlx >= CS or qlz < 0 or qlz >= CS or path_set.has(Vector2i(qx, qz)):
							continue
						var qh := tops[qlx + qlz * CS]
						if qh <= SEA or qh < p.y - 1 or qh > p.y + 3:
							continue
						var tid := d[qlx + qlz * CS + qh * 256]
						if tid == G.STONE or tid == G.GRAVEL or tid == G.SNOW or tid == G.ANDESITE or tid == G.MOSSY or tid == G.DIRT:
							d[qlx + qlz * CS + qh * 256] = G.GRASS
							if d[qlx + qlz * CS + (qh + 1) * 256] == 0 and rng.randf() < 0.45:
								d[qlx + qlz * CS + (qh + 1) * 256] = G.TALL_GRASS if rng.randf() < 0.7 else _rand_flower(rng)


func _trees(d: PackedByteArray, wx0: int, wz0: int, vil: Dictionary) -> void:
	for lz in range(-4, CS + 4):
		for lx in range(-4, CS + 4):
			var wx := wx0 + lx
			var wz := wz0 + lz
			var r := _f01(wx, wz, 1)
			if r > 0.06:
				continue
			var info := col_info(wx, wz)
			var h := info.x
			var b := info.y
			if h <= SEA + 1 or h + 16 >= CH:
				continue
			if not vil.is_empty() and Structures.in_village(vil, wx, wz, 4):
				continue
			var rng := RandomNumberGenerator.new()
			rng.seed = _ih(wx, wz, 2)
			var kind := rng.randf()
			match b:
				B_FOREST:
					if r < 0.021 * (0.35 + 1.1 * smoothstep(-0.2, 0.5, vn.get_noise_2d(wx, wz))):
						if kind < 0.45:
							_oak(d, lx, h, lz, rng)
						elif kind < 0.75:
							_oak_big(d, lx, h, lz, rng)
						elif kind < 0.9:
							_bush(d, lx, h, lz, G.LOG, G.LEAVES)
						else:
							_spruce(d, lx, h, lz, rng)
				B_BIRCH:
					if r < 0.018:
						if kind < 0.7:
							_birch(d, lx, h, lz, rng)
						else:
							_oak(d, lx, h, lz, rng)
				B_PLAINS:
					if r < 0.0022:
						if kind < 0.7:
							_oak(d, lx, h, lz, rng)
						else:
							_oak_big(d, lx, h, lz, rng)
					elif r < 0.0045 and kind < 0.5:
						_bush(d, lx, h, lz, G.LOG, G.LEAVES)
				B_MEADOW:
					if r < 0.0015:
						_birch(d, lx, h, lz, rng)
				B_SWAMP:
					if r < 0.011:
						_swamp_oak(d, lx, h, lz, rng)
				B_SNOW:
					var dens := 0.014 if fn.get_noise_2d(wx, wz) > 0.0 else 0.002
					if r < dens:
						_spruce(d, lx, h, lz, rng)
				B_MOUNT:
					if h < SEA + 22 and r < 0.012:
						if kind < 0.45:
							_pine(d, lx, h, lz, rng)
						elif kind < 0.8:
							_spruce(d, lx, h, lz, rng)
						else:
							_bush(d, lx, h, lz, G.BLOOM_LEAVES, G.BLOOM_LEAVES)
				B_DESERT:
					if r < 0.006:
						var ch := 1 + rng.randi() % 3
						for y in range(1, ch + 1):
							_setl(d, lx, h + y, lz, G.CACTUS, false)
					elif r < 0.008:
						_dead_tree(d, lx, h, lz, rng)


func _blob(d: PackedByteArray, cx: int, cy: int, cz: int, rx: float, ry: float, rz: float, leaf: int, rng: RandomNumberGenerator) -> void:
	for dx in range(-ceili(rx), ceili(rx) + 1):
		for dy in range(-ceili(ry), ceili(ry) + 1):
			for dz in range(-ceili(rz), ceili(rz) + 1):
				var q := float(dx * dx) / (rx * rx) + float(dy * dy) / (ry * ry) + float(dz * dz) / (rz * rz)
				if q <= 1.0 and (q < 0.75 or rng.randf() < 0.55):
					_setl(d, cx + dx, cy + dy, cz + dz, leaf, true)


func _oak(d: PackedByteArray, lx: int, h: int, lz: int, rng: RandomNumberGenerator) -> void:
	var th := 4 + rng.randi() % 3
	for y in range(1, th + 1):
		_setl(d, lx, h + y, lz, G.LOG, false)
	for dy in range(th - 2, th + 2):
		var r := 2 if dy < th else 1
		for dx in range(-r, r + 1):
			for dz in range(-r, r + 1):
				if absi(dx) == r and absi(dz) == r and (r == 1 or rng.randf() < 0.5):
					continue
				_setl(d, lx + dx, h + dy, lz + dz, G.LEAVES, true)


func _oak_big(d: PackedByteArray, lx: int, h: int, lz: int, rng: RandomNumberGenerator) -> void:
	var th := 6 + rng.randi() % 3
	for y in range(1, th + 1):
		_setl(d, lx, h + y, lz, G.LOG, false)
	# ветки
	var branches := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
	for bv in branches:
		if rng.randf() < 0.7:
			var by := h + th - 2 - rng.randi() % 2
			_setl(d, lx + bv.x, by, lz + bv.y, G.LOG, false)
			_setl(d, lx + bv.x * 2, by + 1, lz + bv.y * 2, G.LOG, false)
			_blob(d, lx + bv.x * 2, by + 2, lz + bv.y * 2, 2.2, 1.8, 2.2, G.LEAVES, rng)
	_blob(d, lx, h + th + 1, lz, 3.4, 2.6, 3.4, G.LEAVES, rng)


func _bush(d: PackedByteArray, lx: int, h: int, lz: int, logid: int, leaf: int) -> void:
	_setl(d, lx, h + 1, lz, logid, false)
	for dv in [Vector3i(0, 1, 0), Vector3i(1, 1, 0), Vector3i(-1, 1, 0), Vector3i(0, 1, 1), Vector3i(0, 1, -1), Vector3i(0, 2, 0)]:
		_setl(d, lx + dv.x, h + dv.y, lz + dv.z, leaf, true)


func _swamp_oak(d: PackedByteArray, lx: int, h: int, lz: int, rng: RandomNumberGenerator) -> void:
	var th := 4 + rng.randi() % 2
	for y in range(1, th + 1):
		_setl(d, lx, h + y, lz, G.LOG, false)
	_blob(d, lx, h + th, lz, 3.2, 1.6, 3.2, G.LEAVES, rng)


func _dead_tree(d: PackedByteArray, lx: int, h: int, lz: int, rng: RandomNumberGenerator) -> void:
	var th := 3 + rng.randi() % 3
	for y in range(1, th + 1):
		_setl(d, lx, h + y, lz, G.LOG, false)
	for dv in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		if rng.randf() < 0.5:
			_setl(d, lx + dv.x, h + th - 1, lz + dv.y, G.LOG, false)
			_setl(d, lx + dv.x, h + th, lz + dv.y, G.LOG, false)


func _birch(d: PackedByteArray, lx: int, h: int, lz: int, rng: RandomNumberGenerator) -> void:
	var th := 5 + rng.randi() % 3
	for y in range(1, th + 1):
		_setl(d, lx, h + y, lz, G.BIRCH_LOG, false)
	for dy in range(th - 2, th + 2):
		var r := 2 if dy < th else 1
		for dx in range(-r, r + 1):
			for dz in range(-r, r + 1):
				if absi(dx) == r and absi(dz) == r and (r == 1 or rng.randf() < 0.5):
					continue
				_setl(d, lx + dx, h + dy, lz + dz, G.BIRCH_LEAVES, true)


func _pine(d: PackedByteArray, lx: int, h: int, lz: int, rng: RandomNumberGenerator) -> void:
	var th := 8 + rng.randi() % 5
	for y in range(1, th + 1):
		_setl(d, lx, h + y, lz, G.SPRUCE_LOG, false)
	for k in 3:
		var cy := h + th - k * 2
		var ox := rng.randi() % 3 - 1
		var oz := rng.randi() % 3 - 1
		_blob(d, lx + ox, cy, lz + oz, 2.6 - k * 0.2, 1.3, 2.6 - k * 0.2, G.SPRUCE_LEAVES, rng)
		if k > 0:
			_setl(d, lx + (1 if ox >= 0 else -1), cy - 1, lz, G.SPRUCE_LOG, false)
	_blob(d, lx, h + th + 1, lz, 1.4, 1.6, 1.4, G.SPRUCE_LEAVES, rng)


func _spruce(d: PackedByteArray, lx: int, h: int, lz: int, rng: RandomNumberGenerator) -> void:
	var th := 6 + rng.randi() % 5
	for y in range(1, th + 1):
		_setl(d, lx, h + y, lz, G.SPRUCE_LOG, false)
	_setl(d, lx, h + th + 1, lz, G.SPRUCE_LEAVES, true)
	var maxr := 2 + rng.randi() % 2
	for k in range(0, th - 1):
		var y := h + th - k
		var r := mini(maxr, (k + 2) / 2)
		for dx in range(-r, r + 1):
			for dz in range(-r, r + 1):
				if absi(dx) == r and absi(dz) == r and r > 1:
					continue
				if dx == 0 and dz == 0:
					continue
				_setl(d, lx + dx, y, lz + dz, G.SPRUCE_LEAVES, true)


# ------------------------------------------------------------------
#  Шахты: прямые туннели с креплениями и факелами; под водой — затопленные
# ------------------------------------------------------------------
func _mines(d: PackedByteArray, key: Vector2i, tops: PackedInt32Array) -> void:
	var zone := Vector2i(key.x >> 2, key.y >> 2)
	if _ih(zone.x, zone.y, 31) % 100 >= 24:
		return
	if _ih(key.y, 0, 11) % 2 == 0:
		var hr := _ih(key.y, 1, 12)
		var tz := 4 + hr % 8
		var y0 := 8 + (hr / 11) % 10
		_tunnel(d, tops, true, tz, y0)
	if _ih(key.x, 0, 21) % 2 == 0:
		var hc := _ih(key.x, 1, 22)
		var tx := 4 + hc % 8
		var y1 := 8 + (hc / 11) % 10
		_tunnel(d, tops, false, tx, y1)


func _tunnel(d: PackedByteArray, tops: PackedInt32Array, along_x: bool, t: int, y0: int) -> void:
	for i in CS:
		var cx := i if along_x else t
		var cz := t if along_x else i
		var top := tops[cx + cz * CS]
		var flooded := top <= SEA
		if top < y0 + (4 if flooded else 6):
			continue
		var fill := G.WATER if (flooded and y0 + 2 <= SEA) else G.AIR
		for w in range(-1, 2):
			var px := cx + (0 if along_x else w)
			var pz := cz + (w if along_x else 0)
			for y in range(y0, y0 + 3):
				_setl(d, px, y, pz, fill, false)
			if _getl(d, px, y0 - 1, pz) == 0:
				_setl(d, px, y0 - 1, pz, G.PLANKS, false)
		if i % 4 == 0:
			for w2 in [-2, 2]:
				var qx: int = cx + (0 if along_x else w2)
				var qz: int = cz + (w2 if along_x else 0)
				for y in range(y0, y0 + 2):
					_setl(d, qx, y, qz, G.PLANKS, false)
			for w in range(-1, 2):
				_setl(d, cx + (0 if along_x else w), y0 + 2, cz + (w if along_x else 0), G.LOG, false)
		elif i % 8 == 6 and fill == G.AIR:
			_setl(d, cx + (0 if along_x else 1), y0, cz + (1 if along_x else 0), G.TORCH, false)
