class_name SkinModel
extends Node3D
## 3D-модель игрока в стиле майнкрафта: части с текстурой скина (64x64), второй слой одежды, анимация ходьбы.

var tex: ImageTexture
var parts := {}          # head, body, arm_r, arm_l, leg_r, leg_l — опорные узлы
var slim := false
var mat: StandardMaterial3D
var mat_over: StandardMaterial3D


static func _quad(st: SurfaceTool, c: Array, r: Rect2i, shade: float) -> void:
	var x0 := float(r.position.x) / 64.0
	var y0 := float(r.position.y) / 64.0
	var x1 := float(r.end.x) / 64.0
	var y1 := float(r.end.y) / 64.0
	var uv := [Vector2(x0, y0), Vector2(x1, y0), Vector2(x1, y1), Vector2(x0, y1)]
	var col := Color(shade, shade, shade, 1.0)
	for i in [0, 1, 2, 0, 2, 3]:
		st.set_color(col)
		st.set_uv(uv[i])
		st.add_vertex(c[i])


## Бокс размером (w,h,d) пикселей с началом раскладки (u,v). Центр — в нуле. g — раздутие в пикселях.
static func box_mesh(w: float, h: float, d: float, u: int, v: int, g: float) -> ArrayMesh:
	var hx := (w + g * 2.0) * 0.5 / 16.0
	var hy := (h + g * 2.0) * 0.5 / 16.0
	var hz := (d + g * 2.0) * 0.5 / 16.0
	var f := PlayerSkin.faces(u, v, int(w), int(h), int(d))
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	_quad(st, [Vector3(hx, hy, -hz), Vector3(-hx, hy, -hz), Vector3(-hx, -hy, -hz), Vector3(hx, -hy, -hz)], f["front"], 0.92)
	_quad(st, [Vector3(-hx, hy, hz), Vector3(hx, hy, hz), Vector3(hx, -hy, hz), Vector3(-hx, -hy, hz)], f["back"], 0.82)
	_quad(st, [Vector3(hx, hy, hz), Vector3(hx, hy, -hz), Vector3(hx, -hy, -hz), Vector3(hx, -hy, hz)], f["right"], 0.78)
	_quad(st, [Vector3(-hx, hy, -hz), Vector3(-hx, hy, hz), Vector3(-hx, -hy, hz), Vector3(-hx, -hy, -hz)], f["left"], 0.78)
	_quad(st, [Vector3(hx, hy, hz), Vector3(-hx, hy, hz), Vector3(-hx, hy, -hz), Vector3(hx, hy, -hz)], f["top"], 1.0)
	_quad(st, [Vector3(hx, -hy, -hz), Vector3(-hx, -hy, -hz), Vector3(-hx, -hy, hz), Vector3(hx, -hy, hz)], f["bottom"], 0.6)
	return st.commit()


func _mk_mat(over: bool) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.vertex_color_use_as_albedo = true
	m.albedo_texture = tex
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	if over:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
		m.alpha_scissor_threshold = 0.5
	return m


func _part(name: String, pivot: Vector3, w: float, h: float, d: float, u: int, v: int, ou: int, ov: int, center_off: Vector3) -> void:
	var piv := Node3D.new()
	piv.position = pivot / 16.0
	add_child(piv)
	var mi := MeshInstance3D.new()
	mi.mesh = box_mesh(w, h, d, u, v, 0.0)
	mi.material_override = mat
	mi.position = center_off / 16.0
	piv.add_child(mi)
	var mo := MeshInstance3D.new()
	mo.mesh = box_mesh(w, h, d, ou, ov, 0.45)
	mo.material_override = mat_over
	mo.position = center_off / 16.0
	piv.add_child(mo)
	parts[name] = piv


func build(img: Image) -> void:
	for c in get_children():
		c.queue_free()
	parts.clear()
	tex = ImageTexture.create_from_image(img)
	slim = PlayerSkin.is_slim(img)
	mat = _mk_mat(false)
	mat_over = _mk_mat(true)
	var aw := 3.0 if slim else 4.0
	var ax := 4.0 + aw * 0.5
	_part("head", Vector3(0, 24, 0), 8, 8, 8, 0, 0, 32, 0, Vector3(0, 4, 0))
	_part("body", Vector3(0, 12, 0), 8, 12, 4, 16, 16, 16, 32, Vector3(0, 6, 0))
	_part("arm_r", Vector3(ax, 22, 0), aw, 12, 4, 40, 16, 40, 32, Vector3(0, -4, 0))
	_part("arm_l", Vector3(-ax, 22, 0), aw, 12, 4, 32, 48, 48, 48, Vector3(0, -4, 0))
	_part("leg_r", Vector3(2, 12, 0), 4, 12, 4, 0, 16, 0, 32, Vector3(0, -6, 0))
	_part("leg_l", Vector3(-2, 12, 0), 4, 12, 4, 16, 48, 0, 48, Vector3(0, -6, 0))


func pose(t: float, walk: float) -> void:
	var s := sin(t) * 0.7 * walk
	parts["arm_r"].rotation.x = -s
	parts["arm_l"].rotation.x = s
	parts["leg_r"].rotation.x = s
	parts["leg_l"].rotation.x = -s
