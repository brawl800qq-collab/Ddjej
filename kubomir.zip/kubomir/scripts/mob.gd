class_name Mob
extends Node3D
## Животные, монстры, рыбы, дельфины, летучие мыши. Модели собираются из кубиков.

signal died(kind: String, pos: Vector3)
signal exploded(pos: Vector3)

var kind := "pig"
var world: World
var player: Player
var health := 10.0
var vel := Vector3.ZERO
var hw := 0.35
var height := 0.85
var hostile := false
var provoked := false
var speed := 1.5
var walking := false
var timer := 1.0
var heading := 0.0
var flee_t := 0.0
var flee_from := Vector3.ZERO
var atk_cd := 0.0
var hurt_t := 0.0
var burn_t := 0.0
var anim := 0.0
var legs: Array = []
var arms: Array = []
var wings: Array = []
var mats: Array = []
var aquatic := false
var flying := false
var tail: Node3D
var pitch := 0.0
var swim_y := 0.0
var fuse := 0.0
var shoot_cd := 2.0
var snd_t := 8.0
var strafe := 1.0
var sun_burn := false
var on_floor := false
var prof := -1
var home := Vector3.ZERO
var has_home := false


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = G.noise_tex(c)
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.roughness = 1.0
	m.metallic_specular = 0.0
	mats.append(m)
	return m


func _box(size: Vector3, pos: Vector3, c: Color, parent: Node3D = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(c)
	mi.position = pos
	(parent if parent != null else self).add_child(mi)
	return mi


func _leg(x: float, z: float, length: float, th: float, c: Color, foot: Color = Color(0, 0, 0, 0)) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = Vector3(x, length, z)
	add_child(pivot)
	_box(Vector3(th, length, th), Vector3(0, -length * 0.5, 0), c, pivot)
	if foot.a > 0.0:
		_box(Vector3(th * 1.05, length * 0.22, th * 1.05), Vector3(0, -length * 0.89, 0), foot, pivot)
	legs.append(pivot)
	return pivot


func _eye(x: float, y: float, z: float, sz := 0.08) -> void:
	_box(Vector3(sz, sz, 0.02), Vector3(x, y, z), Color(0.97, 0.97, 0.97))
	_box(Vector3(sz * 0.55, sz * 0.7, 0.02), Vector3(x + (0.012 if x < 0.0 else -0.012), y, z - 0.012), Color(0.05, 0.05, 0.08))


func _eyes(y: float, z: float, dx: float, sz := 0.08) -> void:
	_eye(-dx, y, z, sz)
	_eye(dx, y, z, sz)


func _arm(x: float, y: float, length: float, th: float, c: Color, hand: Color) -> Node3D:
	var pivot := Node3D.new()
	pivot.position = Vector3(x, y, 0)
	add_child(pivot)
	_box(Vector3(th, length, th), Vector3(0, -length * 0.5, 0), c, pivot)
	_box(Vector3(th * 1.02, length * 0.3, th * 1.02), Vector3(0, -length * 0.85, 0), hand, pivot)
	arms.append(pivot)
	return pivot


func _ready() -> void:
	match kind:
		"pig":
			health = 10.0
			hw = 0.35
			height = 0.85
			speed = 1.5
			var pink := Color(0.93, 0.62, 0.62)
			var dark := Color(0.8, 0.46, 0.46)
			for p in [[-0.2, -0.3], [0.2, -0.3], [-0.2, 0.3], [0.2, 0.3]]:
				_leg(p[0], p[1], 0.3, 0.2, pink.darkened(0.08), Color(0.35, 0.22, 0.2))
			_box(Vector3(0.7, 0.5, 0.95), Vector3(0, 0.55, 0.0), pink)
			_box(Vector3(0.72, 0.1, 0.5), Vector3(0, 0.82, 0.05), pink.lightened(0.05))
			_box(Vector3(0.5, 0.45, 0.45), Vector3(0, 0.72, -0.65), pink)
			_box(Vector3(0.26, 0.18, 0.12), Vector3(0, 0.66, -0.93), Color(0.9, 0.6, 0.6))
			_box(Vector3(0.05, 0.06, 0.02), Vector3(-0.06, 0.66, -0.995), Color(0.4, 0.2, 0.2))
			_box(Vector3(0.05, 0.06, 0.02), Vector3(0.06, 0.66, -0.995), Color(0.4, 0.2, 0.2))
			_box(Vector3(0.14, 0.14, 0.05), Vector3(-0.2, 0.98, -0.6), dark)
			_box(Vector3(0.14, 0.14, 0.05), Vector3(0.2, 0.98, -0.6), dark)
			_box(Vector3(0.08, 0.08, 0.1), Vector3(0, 0.75, 0.52), dark)
			_box(Vector3(0.05, 0.08, 0.06), Vector3(0.03, 0.82, 0.58), dark)
			_eyes(0.82, -0.88, 0.14, 0.09)
		"cow":
			health = 10.0
			hw = 0.4
			height = 1.4
			speed = 1.4
			var brown := Color(0.34, 0.2, 0.11)
			var white := Color(0.93, 0.93, 0.9)
			for p in [[-0.25, -0.4], [0.25, -0.4], [-0.25, 0.4], [0.25, 0.4]]:
				_leg(p[0], p[1], 0.55, 0.22, brown.darkened(0.1), Color(0.2, 0.15, 0.12))
			_box(Vector3(0.75, 0.7, 1.2), Vector3(0, 0.9, 0), brown)
			_box(Vector3(0.78, 0.34, 0.42), Vector3(0, 0.98, 0.25), white)
			_box(Vector3(0.3, 0.3, 0.3), Vector3(0.38, 1.12, -0.28), white)
			_box(Vector3(0.3, 0.3, 0.3), Vector3(-0.38, 0.8, 0.0), white)
			_box(Vector3(0.28, 0.12, 0.4), Vector3(0, 0.52, 0.3), Color(0.95, 0.7, 0.7))
			_box(Vector3(0.5, 0.5, 0.45), Vector3(0, 1.12, -0.8), brown)
			_box(Vector3(0.34, 0.2, 0.12), Vector3(0, 1.0, -1.06), Color(0.85, 0.74, 0.66))
			_box(Vector3(0.05, 0.05, 0.02), Vector3(-0.07, 1.0, -1.125), Color(0.4, 0.2, 0.2))
			_box(Vector3(0.05, 0.05, 0.02), Vector3(0.07, 1.0, -1.125), Color(0.4, 0.2, 0.2))
			_box(Vector3(0.09, 0.22, 0.09), Vector3(-0.28, 1.46, -0.78), Color(0.92, 0.9, 0.82))
			_box(Vector3(0.09, 0.22, 0.09), Vector3(0.28, 1.46, -0.78), Color(0.92, 0.9, 0.82))
			_box(Vector3(0.18, 0.1, 0.06), Vector3(-0.34, 1.28, -0.78), brown.darkened(0.15))
			_box(Vector3(0.18, 0.1, 0.06), Vector3(0.34, 1.28, -0.78), brown.darkened(0.15))
			_box(Vector3(0.07, 0.5, 0.07), Vector3(0, 0.85, 0.64), brown.darkened(0.2))
			_box(Vector3(0.12, 0.14, 0.12), Vector3(0, 0.58, 0.64), Color(0.15, 0.1, 0.08))
			_eyes(1.2, -1.03, 0.16, 0.09)
		"sheep":
			health = 8.0
			hw = 0.4
			height = 1.25
			speed = 1.5
			var wool := Color(0.94, 0.94, 0.92)
			for p in [[-0.2, -0.35], [0.2, -0.35], [-0.2, 0.35], [0.2, 0.35]]:
				_leg(p[0], p[1], 0.45, 0.17, Color(0.78, 0.74, 0.68), Color(0.3, 0.26, 0.24))
			_box(Vector3(0.9, 0.85, 1.1), Vector3(0, 0.88, 0), wool)
			_box(Vector3(0.96, 0.4, 0.8), Vector3(0, 1.08, 0.05), wool.darkened(0.04))
			_box(Vector3(0.8, 0.3, 1.0), Vector3(0, 0.55, 0), wool.darkened(0.08))
			_box(Vector3(0.44, 0.2, 0.36), Vector3(0, 1.38, -0.62), wool)
			_box(Vector3(0.38, 0.42, 0.4), Vector3(0, 1.0, -0.72), Color(0.4, 0.34, 0.3))
			_box(Vector3(0.12, 0.08, 0.2), Vector3(-0.25, 1.05, -0.7), Color(0.34, 0.28, 0.25))
			_box(Vector3(0.12, 0.08, 0.2), Vector3(0.25, 1.05, -0.7), Color(0.34, 0.28, 0.25))
			_box(Vector3(0.2, 0.1, 0.08), Vector3(0, 0.9, -0.93), Color(0.5, 0.42, 0.38))
			_eyes(1.07, -0.93, 0.12, 0.08)
		"chicken":
			health = 4.0
			hw = 0.2
			height = 0.6
			speed = 1.3
			var w := Color(0.97, 0.97, 0.96)
			for p in [[-0.07, 0.0], [0.07, 0.0]]:
				_leg(p[0], p[1], 0.25, 0.05, Color(0.95, 0.75, 0.2))
			_box(Vector3(0.3, 0.3, 0.45), Vector3(0, 0.4, 0), w)
			_box(Vector3(0.2, 0.26, 0.2), Vector3(0, 0.65, -0.2), w)
			_box(Vector3(0.12, 0.07, 0.1), Vector3(0, 0.62, -0.34), Color(0.95, 0.55, 0.1))
			_box(Vector3(0.05, 0.09, 0.1), Vector3(0, 0.8, -0.2), Color(0.85, 0.1, 0.1))
			_box(Vector3(0.04, 0.1, 0.05), Vector3(0, 0.55, -0.32), Color(0.85, 0.1, 0.1))
			_box(Vector3(0.04, 0.2, 0.3), Vector3(-0.17, 0.42, 0.02), w.darkened(0.1))
			_box(Vector3(0.04, 0.2, 0.3), Vector3(0.17, 0.42, 0.02), w.darkened(0.1))
			_box(Vector3(0.1, 0.2, 0.1), Vector3(0, 0.55, 0.26), w.darkened(0.05))
			_box(Vector3(0.08, 0.14, 0.08), Vector3(0, 0.62, 0.3), w.darkened(0.15))
			_eyes(0.69, -0.305, 0.07, 0.05)
		"zombie":
			health = 20.0
			hw = 0.3
			height = 1.85
			speed = 2.5
			hostile = true
			sun_burn = true
			var skin := Color(0.33, 0.55, 0.27)
			var shirt := Color(0.0, 0.5, 0.58)
			var pants := Color(0.2, 0.2, 0.52)
			_leg(-0.13, 0.0, 0.75, 0.25, pants, Color(0.25, 0.25, 0.28))
			_leg(0.13, 0.0, 0.75, 0.25, pants, Color(0.25, 0.25, 0.28))
			_box(Vector3(0.5, 0.75, 0.28), Vector3(0, 1.125, 0), shirt)
			_box(Vector3(0.5, 0.12, 0.29), Vector3(0, 0.82, 0), shirt.darkened(0.3))
			_box(Vector3(0.18, 0.2, 0.29), Vector3(0.12, 1.35, 0), shirt.darkened(0.25))
			_box(Vector3(0.5, 0.5, 0.5), Vector3(0, 1.75, 0), skin)
			_box(Vector3(0.52, 0.14, 0.52), Vector3(0, 2.0, 0), Color(0.2, 0.3, 0.15))
			_box(Vector3(0.1, 0.1, 0.02), Vector3(-0.12, 1.78, -0.255), Color(0.1, 0.05, 0.05))
			_box(Vector3(0.1, 0.1, 0.02), Vector3(0.12, 1.78, -0.255), Color(0.1, 0.05, 0.05))
			_box(Vector3(0.2, 0.05, 0.02), Vector3(0, 1.6, -0.255), Color(0.12, 0.18, 0.1))
			for sx in [-0.37, 0.37]:
				var a := _arm(sx, 1.45, 0.75, 0.25, shirt, skin)
				a.rotation.x = -PI / 2.0
		"villager":
			health = 20.0
			hw = 0.3
			height = 1.95
			speed = 1.1
			if prof < 0:
				prof = randi() % 5
			var skin := Color(0.8, 0.6, 0.48)
			var robes := [Color(0.5, 0.34, 0.2), Color(0.86, 0.86, 0.84), Color(0.22, 0.22, 0.24), Color(0.5, 0.2, 0.56), Color(0.92, 0.9, 0.86)]
			var aprons := [Color(0.32, 0.5, 0.2), Color(0.3, 0.4, 0.78), Color(0.1, 0.1, 0.12), Color(0.82, 0.72, 0.2), Color(0.75, 0.2, 0.18)]
			var robe: Color = robes[prof]
			var apron: Color = aprons[prof]
			_leg(-0.14, 0.0, 0.72, 0.27, robe.darkened(0.12), robe.darkened(0.35))
			_leg(0.14, 0.0, 0.72, 0.27, robe.darkened(0.12), robe.darkened(0.35))
			_box(Vector3(0.6, 0.78, 0.38), Vector3(0, 1.1, 0), robe)
			_box(Vector3(0.64, 0.12, 0.42), Vector3(0, 0.78, 0), robe.darkened(0.2))
			_box(Vector3(0.62, 0.5, 0.04), Vector3(0, 1.02, -0.21), apron)
			_box(Vector3(0.64, 0.08, 0.4), Vector3(0, 1.42, 0), apron.darkened(0.15))
			_box(Vector3(0.1, 0.4, 0.04), Vector3(0, 1.1, 0.2), robe.darkened(0.25))
			_box(Vector3(0.52, 0.52, 0.5), Vector3(0, 1.74, 0), skin)
			_box(Vector3(0.54, 0.1, 0.52), Vector3(0, 1.97, 0.01), skin.darkened(0.3) if prof != 0 else Color(0.9, 0.78, 0.4))
			_box(Vector3(0.16, 0.26, 0.16), Vector3(0, 1.66, -0.32), skin.darkened(0.1))
			_box(Vector3(0.42, 0.06, 0.02), Vector3(0, 1.88, -0.256), Color(0.28, 0.2, 0.14))
			for ex in [-0.13, 0.13]:
				_box(Vector3(0.12, 0.09, 0.02), Vector3(ex, 1.8, -0.256), Color(0.97, 0.97, 0.97))
				_box(Vector3(0.07, 0.08, 0.02), Vector3(ex + (0.012 if ex < 0.0 else -0.012), 1.8, -0.262), Color(0.2, 0.55, 0.25))
			_box(Vector3(0.18, 0.03, 0.02), Vector3(0, 1.58, -0.256), skin.darkened(0.35))
			if prof == 0:
				_box(Vector3(0.95, 0.04, 0.95), Vector3(0, 2.03, 0), Color(0.88, 0.76, 0.38))
				_box(Vector3(0.52, 0.14, 0.52), Vector3(0, 2.12, 0), Color(0.8, 0.66, 0.3))
			elif prof == 3:
				_box(Vector3(0.56, 0.2, 0.54), Vector3(0, 2.08, 0), Color(0.5, 0.2, 0.56))
			elif prof == 1:
				_box(Vector3(0.58, 0.08, 0.04), Vector3(0, 1.74, -0.27), Color(0.2, 0.2, 0.22))
			# сложенные руки
			_box(Vector3(0.84, 0.2, 0.28), Vector3(0, 1.16, -0.25), robe.darkened(0.08))
			_box(Vector3(0.2, 0.2, 0.28), Vector3(-0.42, 1.16, -0.25), robe.darkened(0.08))
			_box(Vector3(0.2, 0.2, 0.28), Vector3(0.42, 1.16, -0.25), robe.darkened(0.08))
			_box(Vector3(0.3, 0.12, 0.12), Vector3(0.0, 1.16, -0.4), skin)
		"golem":
			health = 100.0
			hw = 0.7
			height = 2.75
			speed = 1.3
			var iron := Color(0.8, 0.79, 0.76)
			var dk := Color(0.6, 0.6, 0.58)
			var vine := Color(0.3, 0.52, 0.24)
			_leg(-0.3, 0.0, 1.0, 0.42, iron.darkened(0.12), dk)
			_leg(0.3, 0.0, 1.0, 0.42, iron.darkened(0.12), dk)
			_box(Vector3(0.9, 0.35, 0.55), Vector3(0, 1.1, 0), dk)
			_box(Vector3(1.1, 0.95, 0.7), Vector3(0, 1.8, 0), iron)
			_box(Vector3(1.5, 0.5, 0.8), Vector3(0, 2.3, 0), iron.lightened(0.04))
			_box(Vector3(0.3, 0.26, 0.04), Vector3(-0.3, 1.9, -0.36), vine)
			_box(Vector3(0.22, 0.4, 0.04), Vector3(0.35, 1.6, -0.36), vine)
			_box(Vector3(0.16, 0.3, 0.04), Vector3(-0.1, 2.3, 0.41), vine)
			_box(Vector3(0.04, 0.5, 0.04), Vector3(0.2, 1.8, -0.36), dk.darkened(0.3))
			_box(Vector3(0.5, 0.45, 0.45), Vector3(0, 2.78, -0.04), iron)
			_box(Vector3(0.52, 0.07, 0.04), Vector3(0, 2.86, -0.27), dk.darkened(0.4))
			_box(Vector3(0.12, 0.3, 0.14), Vector3(0, 2.7, -0.33), iron.darkened(0.12))
			for ex2 in [-0.13, 0.13]:
				_box(Vector3(0.1, 0.07, 0.02), Vector3(ex2, 2.8, -0.275), Color(0.85, 0.2, 0.15))
			for ax in [-0.95, 0.95]:
				var arm := Node3D.new()
				arm.position = Vector3(ax, 2.45, 0.0)
				add_child(arm)
				_box(Vector3(0.38, 1.6, 0.42), Vector3(0, -0.8, 0), iron.darkened(0.06), arm)
				_box(Vector3(0.42, 0.4, 0.46), Vector3(0, -1.5, 0), dk, arm)
				_box(Vector3(0.14, 0.3, 0.04), Vector3(0, -0.6, -0.22), vine, arm)
				arms.append(arm)
		"creeper":
			health = 20.0
			hw = 0.3
			height = 1.7
			speed = 2.3
			hostile = true
			var g := Color(0.3, 0.68, 0.25)
			for p in [[-0.17, -0.2], [0.17, -0.2], [-0.17, 0.2], [0.17, 0.2]]:
				_leg(p[0], p[1], 0.4, 0.26, g.darkened(0.1))
			_box(Vector3(0.5, 0.8, 0.3), Vector3(0, 0.8, 0), g)
			_box(Vector3(0.52, 0.2, 0.32), Vector3(0, 0.55, 0), g.darkened(0.15))
			_box(Vector3(0.14, 0.3, 0.32), Vector3(0.14, 1.0, 0), g.lightened(0.08))
			_box(Vector3(0.5, 0.5, 0.5), Vector3(0, 1.45, 0), g)
			_box(Vector3(0.12, 0.12, 0.02), Vector3(-0.12, 1.52, -0.255), Color(0.05, 0.1, 0.05))
			_box(Vector3(0.12, 0.12, 0.02), Vector3(0.12, 1.52, -0.255), Color(0.05, 0.1, 0.05))
			_box(Vector3(0.12, 0.18, 0.02), Vector3(0, 1.38, -0.255), Color(0.05, 0.1, 0.05))
			_box(Vector3(0.08, 0.14, 0.02), Vector3(-0.1, 1.3, -0.255), Color(0.05, 0.1, 0.05))
			_box(Vector3(0.08, 0.14, 0.02), Vector3(0.1, 1.3, -0.255), Color(0.05, 0.1, 0.05))
		"skeleton":
			health = 20.0
			hw = 0.3
			height = 1.9
			speed = 2.2
			hostile = true
			sun_burn = true
			var bone := Color(0.86, 0.86, 0.82)
			var dk := Color(0.16, 0.16, 0.16)
			_leg(-0.12, 0.0, 0.8, 0.12, bone)
			_leg(0.12, 0.0, 0.8, 0.12, bone)
			_box(Vector3(0.46, 0.7, 0.2), Vector3(0, 1.15, 0), bone.darkened(0.05))
			for ry in [0.95, 1.1, 1.25, 1.4]:
				_box(Vector3(0.48, 0.05, 0.22), Vector3(0, ry, 0), dk)
			_box(Vector3(0.1, 0.7, 0.22), Vector3(0, 1.15, 0), bone)
			_box(Vector3(0.5, 0.5, 0.5), Vector3(0, 1.75, 0), bone)
			_box(Vector3(0.12, 0.12, 0.02), Vector3(-0.12, 1.78, -0.255), dk)
			_box(Vector3(0.12, 0.12, 0.02), Vector3(0.12, 1.78, -0.255), dk)
			_box(Vector3(0.18, 0.06, 0.02), Vector3(0, 1.62, -0.255), dk)
			for sx in [-0.31, 0.31]:
				var a := _arm(sx, 1.45, 0.75, 0.12, bone, bone)
				a.rotation.x = -1.3
			_box(Vector3(0.04, 0.7, 0.05), Vector3(0.31, 1.25, -0.5), Color(0.5, 0.35, 0.2))
			_box(Vector3(0.012, 0.7, 0.012), Vector3(0.31, 1.25, -0.46), Color(0.9, 0.9, 0.9))
		"spider":
			health = 16.0
			hw = 0.55
			height = 0.9
			speed = 3.0
			hostile = true
			var sp := Color(0.14, 0.11, 0.1)
			_box(Vector3(0.85, 0.6, 0.95), Vector3(0, 0.55, 0.55), sp)
			_box(Vector3(0.3, 0.12, 0.35), Vector3(0, 0.88, 0.55), Color(0.4, 0.1, 0.1))
			_box(Vector3(0.55, 0.45, 0.55), Vector3(0, 0.5, -0.1), sp.lightened(0.05))
			_box(Vector3(0.45, 0.4, 0.4), Vector3(0, 0.5, -0.65), sp.lightened(0.08))
			for ex in [-0.1, 0.1]:
				_box(Vector3(0.1, 0.1, 0.02), Vector3(ex, 0.58, -0.86), Color(0.9, 0.1, 0.1))
				_box(Vector3(0.06, 0.06, 0.02), Vector3(ex * 1.9, 0.52, -0.86), Color(0.75, 0.1, 0.1))
			_box(Vector3(0.06, 0.18, 0.06), Vector3(-0.09, 0.35, -0.86), Color(0.5, 0.45, 0.4))
			_box(Vector3(0.06, 0.18, 0.06), Vector3(0.09, 0.35, -0.86), Color(0.5, 0.45, 0.4))
			for i in 4:
				for side in [-1, 1]:
					var pv := Node3D.new()
					pv.position = Vector3(side * 0.2, 0.5, -0.3 + i * 0.28)
					pv.rotation.y = side * (0.5 - i * 0.35)
					add_child(pv)
					var up := Node3D.new()
					up.rotation.z = side * -0.55
					pv.add_child(up)
					_box(Vector3(0.7, 0.07, 0.07), Vector3(side * 0.35, 0.0, 0), sp.lightened(0.1), up)
					var lo := Node3D.new()
					lo.position = Vector3(side * 0.7, 0.0, 0)
					lo.rotation.z = side * 1.0
					up.add_child(lo)
					_box(Vector3(0.07, 0.6, 0.07), Vector3(0, -0.3, 0), sp, lo)
					legs.append(pv)
		"bat":
			health = 6.0
			hw = 0.2
			height = 0.4
			speed = 3.4
			flying = true
			var bc := Color(0.22, 0.17, 0.2)
			_box(Vector3(0.2, 0.26, 0.2), Vector3(0, 0.2, 0), bc)
			_box(Vector3(0.2, 0.2, 0.2), Vector3(0, 0.4, -0.02), bc.lightened(0.05))
			_box(Vector3(0.06, 0.1, 0.04), Vector3(-0.07, 0.55, -0.02), bc)
			_box(Vector3(0.06, 0.1, 0.04), Vector3(0.07, 0.55, -0.02), bc)
			_box(Vector3(0.04, 0.04, 0.02), Vector3(-0.05, 0.42, -0.125), Color(0.9, 0.2, 0.2))
			_box(Vector3(0.04, 0.04, 0.02), Vector3(0.05, 0.42, -0.125), Color(0.9, 0.2, 0.2))
			for side in [-1, 1]:
				var wv := Node3D.new()
				wv.position = Vector3(side * 0.1, 0.28, 0.0)
				add_child(wv)
				_box(Vector3(0.5, 0.03, 0.34), Vector3(side * 0.25, 0.0, 0.02), bc.darkened(0.1), wv)
				_box(Vector3(0.22, 0.03, 0.22), Vector3(side * 0.6, 0.0, 0.1), bc.darkened(0.2), wv)
				wings.append(wv)
	if kind.begins_with("fish"):
		_build_fish()
	elif kind == "dolphin":
		_build_dolphin()
	if not aquatic and not flying:
		_blob_shadow()
	heading = randf() * TAU
	timer = randf_range(0.5, 3.0)
	rotation.y = heading
	swim_y = position.y
	snd_t = randf_range(4.0, 14.0)


static var _blob_tex: ImageTexture


func _blob_shadow() -> void:
	if _blob_tex == null:
		var img := Image.create(32, 32, false, Image.FORMAT_RGBA8)
		for y in 32:
			for x in 32:
				var d := Vector2(x - 15.5, y - 15.5).length() / 16.0
				img.set_pixel(x, y, Color(0, 0, 0, clampf(1.0 - d, 0.0, 1.0) * 0.55))
		_blob_tex = ImageTexture.create_from_image(img)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_texture = _blob_tex
	m.cull_mode = BaseMaterial3D.CULL_DISABLED
	var pm := PlaneMesh.new()
	pm.size = Vector2(1.0, 1.0)
	var mi := MeshInstance3D.new()
	mi.mesh = pm
	mi.material_override = m
	mi.position = Vector3(0, 0.03, 0)
	mi.scale = Vector3(1.5, 1, 1.5) * maxf(0.9, hw * 2.6)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)


func _build_fish() -> void:
	aquatic = true
	health = 3.0
	hw = 0.2
	height = 0.3
	speed = 1.3
	var pal := [Color(0.95, 0.55, 0.2), Color(0.55, 0.6, 0.7), Color(0.85, 0.3, 0.3)]
	var c: Color = pal[int(kind.substr(4)) % 3]
	_box(Vector3(0.16, 0.24, 0.5), Vector3(0, 0.15, 0), c)
	_box(Vector3(0.05, 0.14, 0.24), Vector3(0, 0.3, 0.03), c.darkened(0.2))
	_box(Vector3(0.14, 0.2, 0.12), Vector3(0, 0.15, -0.3), c.lightened(0.1))
	_eyes(0.19, -0.34, 0.06, 0.05)
	tail = Node3D.new()
	tail.position = Vector3(0, 0.15, 0.25)
	add_child(tail)
	_box(Vector3(0.04, 0.22, 0.2), Vector3(0, 0, 0.1), c.darkened(0.15), tail)


func _build_dolphin() -> void:
	aquatic = true
	health = 12.0
	hw = 0.45
	height = 0.7
	speed = 2.6
	var g := Color(0.45, 0.55, 0.65)
	var w := Color(0.88, 0.92, 0.95)
	_box(Vector3(0.6, 0.6, 1.5), Vector3(0, 0.4, 0), g)
	_box(Vector3(0.5, 0.25, 1.3), Vector3(0, 0.2, 0.0), w)
	_box(Vector3(0.45, 0.45, 0.5), Vector3(0, 0.45, -0.95), g)
	_box(Vector3(0.2, 0.15, 0.4), Vector3(0, 0.38, -1.3), g.lightened(0.1))
	_box(Vector3(0.08, 0.4, 0.4), Vector3(0, 0.8, 0.1), g.darkened(0.15))
	_box(Vector3(0.7, 0.06, 0.3), Vector3(0, 0.25, -0.3), g.darkened(0.1))
	_eyes(0.55, -1.2, 0.2, 0.07)
	tail = Node3D.new()
	tail.position = Vector3(0, 0.4, 0.75)
	add_child(tail)
	_box(Vector3(0.35, 0.3, 0.6), Vector3(0, 0, 0.3), g, tail)
	_box(Vector3(0.9, 0.07, 0.35), Vector3(0, 0, 0.7), g.darkened(0.1), tail)


func _snd_name() -> String:
	if kind.begins_with("fish"):
		return ""
	if kind == "dolphin":
		return "bat"
	if kind == "villager":
		return "pig"
	if kind == "golem":
		return "zombie"
	return kind


func _swim(dt: float) -> void:
	var px := position.x
	var pz := position.z
	var in_w := world.get_block(floori(px), floori(position.y + height * 0.5), floori(pz)) in [G.WATER, G.SEAWEED]
	if not in_w:
		vel.y = maxf(vel.y - 28.0 * dt, -30.0)
		vel.x = lerpf(vel.x, 0.0, minf(1.0, 4.0 * dt))
		vel.z = lerpf(vel.z, 0.0, minf(1.0, 4.0 * dt))
		var r0 := world.move_body(position, vel, hw, height, dt)
		position = r0["pos"]
		vel = r0["vel"]
		if tail:
			tail.rotation.y = sin(anim * 3.0) * 0.8
		anim += dt * 12.0
		return
	timer -= dt
	var fast := flee_t > 0.0
	if fast:
		flee_t -= dt
	if timer <= 0.0:
		timer = randf_range(2.0, 6.0)
		heading += randf_range(-1.2, 1.2)
		swim_y = clampf(position.y + randf_range(-3.0, 3.0), 2.0, 22.0)
	var spd := speed * (2.2 if fast else 1.0)
	var dir := Vector3(-sin(heading), 0, -cos(heading))
	var ahead := position + dir * (1.2 + hw)
	var ab := world.get_block(floori(ahead.x), floori(position.y + height * 0.5), floori(ahead.z))
	if ab != G.WATER:
		heading += PI * 0.6 + randf() * 0.8
		dir = Vector3(-sin(heading), 0, -cos(heading))
		swim_y = clampf(position.y + randf_range(-2.0, 2.0), 2.0, 22.0)
	var top_b := world.get_block(floori(px), floori(position.y + height + 0.6), floori(pz))
	var up := clampf(swim_y - position.y, -1.5, 1.5)
	if top_b != G.WATER and up > 0.0:
		up = 0.0
	vel = vel.lerp(Vector3(dir.x * spd, up * 0.7, dir.z * spd), minf(1.0, 3.0 * dt))
	var r := world.move_body(position, vel, hw, height, dt)
	position = r["pos"]
	vel = r["vel"]
	if r["hit_x"] or r["hit_z"]:
		heading += PI * 0.7
	rotation.y = lerp_angle(rotation.y, heading, minf(1.0, 4.0 * dt))
	pitch = lerpf(pitch, clampf(vel.y * 0.25, -0.5, 0.5), minf(1.0, 4.0 * dt))
	rotation.x = pitch
	anim += dt * (6.0 + spd * 3.0)
	if tail:
		tail.rotation.y = sin(anim) * 0.5


func _fly(dt: float) -> void:
	timer -= dt
	if timer <= 0.0:
		timer = randf_range(0.6, 1.8)
		heading += randf_range(-1.6, 1.6)
		swim_y = clampf(position.y + randf_range(-2.5, 2.5), 3.0, 60.0)
	var dir := Vector3(-sin(heading), 0, -cos(heading))
	var up := clampf(swim_y - position.y, -2.0, 2.0)
	vel = vel.lerp(Vector3(dir.x * speed, up * 1.6, dir.z * speed), minf(1.0, 3.0 * dt))
	var r := world.move_body(position, vel, hw, height, dt)
	position = r["pos"]
	vel = r["vel"]
	if r["hit_x"] or r["hit_z"]:
		heading += PI * 0.8
		swim_y = position.y + randf_range(-1.0, 2.0)
	rotation.y = lerp_angle(rotation.y, heading, minf(1.0, 6.0 * dt))
	anim += dt * 22.0
	for i in wings.size():
		var sg := -1.0 if i == 0 else 1.0
		(wings[i] as Node3D).rotation.z = sin(anim) * 0.9 * sg


func hurt(amount: float, from: Vector3) -> void:
	health -= amount
	hurt_t = 0.25
	provoked = true
	var away := position - from
	away.y = 0.0
	if away.length() > 0.01:
		away = away.normalized()
	vel = Vector3(away.x * 6.0, 5.0 if not aquatic else 1.0, away.z * 6.0)
	if not hostile:
		flee_t = 3.0
		flee_from = from
	for m in mats:
		m.albedo_color = Color(1.0, 0.45, 0.45)
	var sn := _snd_name()
	if sn != "":
		Sfx.play(self, sn, position, -2.0, 1.25)
	if health <= 0.0:
		if sn != "":
			Sfx.play(self, sn, position, -1.0, 0.7)
		died.emit(kind, position)
		queue_free()


func ray_hit(o: Vector3, d: Vector3, maxd: float) -> float:
	var bmin := Vector3(position.x - hw, position.y, position.z - hw)
	var bmax := Vector3(position.x + hw, position.y + height, position.z + hw)
	var tmin := 0.0
	var tmax := maxd
	for a in 3:
		var da: float = d[a]
		var oa: float = o[a]
		if absf(da) < 0.00001:
			if oa < bmin[a] or oa > bmax[a]:
				return -1.0
		else:
			var t1 := (bmin[a] - oa) / da
			var t2 := (bmax[a] - oa) / da
			if t1 > t2:
				var tmp := t1
				t1 = t2
				t2 = tmp
			tmin = maxf(tmin, t1)
			tmax = minf(tmax, t2)
			if tmin > tmax:
				return -1.0
	return tmin


func _shoot() -> void:
	var from := position + Vector3(0, 1.5, 0)
	var target := player.position + Vector3(0, 1.3, 0)
	var dv := target - from
	var dist := dv.length()
	var dir := dv / maxf(dist, 0.01)
	var hit := world.raycast(from, dir, dist)
	if hit.has("pos") and float(hit["dist"]) < dist - 1.0:
		return
	var ar := Arrow.new()
	ar.world = world
	ar.player = player
	ar.vel = dir * 22.0 + Vector3(0, dist * 0.18, 0)
	get_parent().add_child(ar)
	ar.position = from + dir * 0.6
	Sfx.play(self, "arrow", position, -2.0)


## 0 — путь свободен, 1 — вода, 2 — стена, 3 — обрыв
func _probe(dir: Vector3) -> int:
	var d := dir.normalized()
	var reach := hw + 0.75
	var fy := floori(position.y + 0.1)
	for dist: float in [reach, reach + 0.8]:
		var p: Vector3 = position + d * dist
		var x := floori(p.x)
		var z := floori(p.z)
		var b0 := world.get_block(x, fy, z)
		if b0 < 0:
			return 2
		var b1 := world.get_block(x, fy + 1, z)
		var b2 := world.get_block(x, fy + 2, z)
		var up := 0
		if G.SOLID[b0] != 0:
			if G.SOLID[b1] != 0 or G.SOLID[b2] != 0:
				return 2
			up = 1
		elif G.SOLID[b1] != 0:
			return 2
		var gy := fy + up
		var found := false
		for k in 4:
			var b := world.get_block(x, gy - k, z)
			if b in [G.WATER, G.SEAWEED]:
				return 1
			if b >= 0 and G.SOLID[b] != 0:
				found = true
				break
		if not found:
			return 3
	return 0


## Ближайший берег, когда моб оказался в воде
func _shore_dir() -> Vector3:
	var best := 99.0
	var out := Vector3.ZERO
	for i in 16:
		var a := float(i) * TAU / 16.0
		var d := Vector3(-sin(a), 0, -cos(a))
		for r in range(1, 10):
			var x := floori(position.x + d.x * r)
			var z := floori(position.z + d.z * r)
			var top := world.column_top(x, z)
			if top < 0:
				continue
			var b := world.get_block(x, top, z)
			if b in [G.WATER, G.SEAWEED]:
				continue
			if float(top) + 1.0 >= position.y - 0.5 and float(top) <= position.y + 1.2:
				if float(r) < best:
					best = float(r)
					out = d
				break
	return out


## Умный выбор направления: обходит воду, стены и обрывы
func _steer(desired: Vector3, chasing: bool) -> Vector3:
	if aquatic or flying:
		return desired
	var pr := _probe(desired)
	if pr == 0 or (chasing and pr == 3):
		return desired
	if chasing and pr == 2 and on_floor:
		return desired  # прыжок через препятствие в погоне
	var base := atan2(-desired.x, -desired.z)
	var sgn := 1.0 if randf() < 0.5 else -1.0
	for a in [0.6, 1.2, 1.9, 2.6]:
		for s in [sgn, -sgn]:
			var h: float = base + a * s
			var nd := Vector3(-sin(h), 0, -cos(h)) * desired.length()
			if _probe(nd) == 0:
				heading = h
				return nd
	heading = base + PI
	timer = minf(timer, 0.5)
	return Vector3.ZERO


func _process(dt: float) -> void:
	if world == null or player == null:
		return
	dt = minf(dt, 0.05)
	var ppos := player.position
	var dist := position.distance_to(ppos)
	if dist > 90.0:
		# жители, големы и питомцы не пропадают — просто ждут
		if kind != "villager" and kind != "golem":
			queue_free()
		return
	if dist > 64.0 and not hostile:
		return

	if hurt_t > 0.0:
		hurt_t -= dt
		if hurt_t <= 0.0 and fuse <= 0.0:
			for m in mats:
				m.albedo_color = Color.WHITE
	atk_cd = maxf(0.0, atk_cd - dt)
	snd_t -= dt
	if snd_t <= 0.0:
		snd_t = randf_range(7.0, 18.0)
		var sn := _snd_name()
		if sn != "" and sn != "creeper" and dist < 30.0:
			Sfx.play(self, sn, position, -5.0, randf_range(0.92, 1.08))

	if aquatic:
		_swim(dt)
		return
	if flying:
		_fly(dt)
		return

	var desired := Vector3.ZERO
	var spd := speed
	var active := hostile and G.mode == "survival" and not player.dead and dist < 26.0
	if kind == "spider" and G.day > 0.55 and not provoked:
		active = false
	if active:
		var to_p := ppos - position
		to_p.y = 0.0
		var tn := to_p.normalized()
		match kind:
			"creeper":
				if dist < 3.0 or fuse > 0.0:
					if fuse <= 0.0:
						Sfx.play(self, "fuse", position, 0.0)
					fuse += dt
					desired = Vector3.ZERO
					var pulse := 1.0 + 0.12 * sin(fuse * 28.0)
					scale = Vector3(pulse, pulse, pulse)
					var fl := 0.5 + 0.5 * sin(fuse * 24.0)
					for m in mats:
						m.albedo_color = Color(1, 1, 1).lerp(Color(2.0, 2.0, 2.0), fl)
					if fuse > 1.5:
						exploded.emit(position + Vector3(0, 0.8, 0))
						queue_free()
						return
					if dist > 5.5 and fuse < 1.0:
						fuse = 0.0
						scale = Vector3.ONE
						for m in mats:
							m.albedo_color = Color.WHITE
				else:
					desired = tn
			"skeleton":
				if dist > 13.0:
					desired = tn
				elif dist < 6.0:
					desired = -tn
				else:
					desired = Vector3(-tn.z, 0, tn.x) * strafe * 0.7
				if randf() < dt * 0.4:
					strafe = -strafe
				shoot_cd -= dt
				if shoot_cd <= 0.0 and dist < 20.0:
					shoot_cd = randf_range(1.6, 2.6)
					_shoot()
			"spider":
				desired = tn
				if dist < 4.0 and on_floor and randf() < dt * 1.2:
					vel.y = 7.0
				if dist < 1.7 and atk_cd <= 0.0 and absf(ppos.y - position.y) < 1.5:
					atk_cd = 1.0
					player.hurt(2.0)
					player.vel = Vector3(tn.x * 4.0, 3.5, tn.z * 4.0)
					Sfx.play(self, "spider", position, -3.0)
			_:
				desired = tn
				if dist < 1.3 and atk_cd <= 0.0 and absf(ppos.y - position.y) < 1.5:
					atk_cd = 1.0
					player.hurt(3.0)
					player.vel = Vector3(tn.x * 6.0, 4.5, tn.z * 6.0)
	if sun_burn and G.day > 0.7:
		var top := world.column_top(floori(position.x), floori(position.z))
		if top >= 0 and top < position.y + 1.0:
			burn_t += dt
			if burn_t >= 1.0:
				burn_t = 0.0
				hurt(1.0, position + Vector3(0, 0, 0.01))
				if is_queued_for_deletion():
					return
	if kind == "golem":
		var tgt: Mob = null
		var best := 14.0
		for ch in get_parent().get_children():
			if ch is Mob and ch.hostile and not ch.is_queued_for_deletion():
				var dd: float = ch.position.distance_to(position)
				if dd < best:
					best = dd
					tgt = ch
		if tgt != null:
			var to_t := tgt.position - position
			to_t.y = 0.0
			desired = to_t.normalized()
			spd = speed * 1.6
			if best < 2.6 and atk_cd <= 0.0:
				atk_cd = 1.3
				tgt.hurt(7.0, position)
				tgt.vel.y = 9.0
		elif provoked and dist < 24.0 and G.mode == "survival" and not player.dead:
			var to_pl := ppos - position
			to_pl.y = 0.0
			desired = to_pl.normalized()
			spd = speed * 1.5
			if dist < 2.6 and atk_cd <= 0.0 and absf(ppos.y - position.y) < 2.0:
				atk_cd = 1.3
				player.hurt(8.0)
				player.vel = Vector3(desired.x * 8.0, 7.0, desired.z * 8.0)
	if not hostile and not (kind == "golem" and desired.length() > 0.1):
		if flee_t > 0.0 and kind == "golem":
			flee_t = 0.0
		if flee_t > 0.0:
			flee_t -= dt
			var away2 := position - flee_from
			away2.y = 0.0
			desired = away2.normalized()
			spd = speed * 2.2
		else:
			timer -= dt
			if timer <= 0.0:
				walking = not walking and randf() < 0.65
				timer = randf_range(1.0, 4.0)
				heading = randf() * TAU
			if walking:
				desired = Vector3(-sin(heading), 0, -cos(heading))
			if has_home and position.distance_to(home) > 16.0:
				var back := home - position
				back.y = 0.0
				desired = back.normalized()
	elif not active and kind != "creeper":
		timer -= dt
		if timer <= 0.0:
			walking = not walking and randf() < 0.5
			timer = randf_range(1.5, 4.0)
			heading = randf() * TAU
		if walking:
			desired = Vector3(-sin(heading), 0, -cos(heading)) * 0.5

	var in_water := world.get_block(floori(position.x), floori(position.y + 0.3), floori(position.z)) in [G.WATER, G.SEAWEED]
	if in_water and not aquatic and not flying:
		var sd2 := _shore_dir()
		if sd2 != Vector3.ZERO:
			desired = sd2
			heading = atan2(-sd2.x, -sd2.z)
			if on_floor or vel.y < 2.0:
				vel.y = maxf(vel.y, 2.5)
	elif desired.length() > 0.05:
		desired = _steer(desired, active)
	if in_water:
		spd *= 0.6
	vel.x = lerpf(vel.x, desired.x * spd, minf(1.0, 8.0 * dt))
	vel.z = lerpf(vel.z, desired.z * spd, minf(1.0, 8.0 * dt))
	if in_water:
		vel.y = lerpf(vel.y, 1.6, minf(1.0, 6.0 * dt))
	else:
		vel.y = maxf(vel.y - 28.0 * dt, -50.0)

	var r := world.move_body(position, vel, hw, height, dt)
	position = r["pos"]
	vel = r["vel"]
	on_floor = r["on_ground"]
	if (r["hit_x"] or r["hit_z"]) and desired.length() > 0.1:
		if kind == "spider" and active:
			vel.y = 5.5
		elif r["on_ground"]:
			vel.y = 8.0

	if desired.length() > 0.05:
		var target := atan2(-desired.x, -desired.z)
		if kind == "skeleton" and active:
			var look := ppos - position
			target = atan2(-look.x, -look.z)
		rotation.y = lerp_angle(rotation.y, target, minf(1.0, 9.0 * dt))
		anim += dt * spd * 4.5
	else:
		anim = lerpf(anim, 0.0, minf(1.0, 6.0 * dt))
	var mv := clampf(desired.length() * 2.0, 0.0, 1.0)
	for i in legs.size():
		var lg: Node3D = legs[i]
		if kind == "spider":
			lg.position.y = 0.5 + absf(sin(anim * 1.6 + float(i))) * 0.05 * mv
		else:
			var sgn := 1.0 if (i == 0 or i == 3) else -1.0
			lg.rotation.x = sin(anim) * 0.7 * sgn * mv
	if kind == "golem":
		for ai in arms.size():
			var am: Node3D = arms[ai]
			var sg2 := 1.0 if ai == 0 else -1.0
			if atk_cd > 0.85:
				am.rotation.x = lerpf(am.rotation.x, -2.3, minf(1.0, 20.0 * dt))
			else:
				am.rotation.x = lerpf(am.rotation.x, sin(anim) * 0.5 * sg2 * mv, minf(1.0, 10.0 * dt))
	if position.y < -20.0:
		if hostile:
			queue_free()
		else:
			var top := world.column_top(floori(position.x), floori(position.z))
			position.y = float(maxi(top, 26)) + 2.0
			vel = Vector3.ZERO
