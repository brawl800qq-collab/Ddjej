class_name Atlas
extends RefCounted
## Процедурная генерация всех текстур (никаких внешних файлов не нужно).
## Атлас: 16x16 плиток по 16 пикселей = 256x256.

const T := 16
const COLS := 16
const HD_TILES := [0, 1, 2, 4, 5, 6, 7, 255]

const HELMET := [
	"................", "................", "................",
	"....########....", "...##########...", "..############..",
	"..############..", "..############..", "..###......###..",
	"..###......###..", "................", "................",
]
const CHEST := [
	"................", "..###......###..", ".####......####.",
	".#####....#####.", ".##############.", "..############..",
	"..############..", "..############..", "..############..",
	"..############..", "..############..", "...##########...",
]
const LEGS := [
	"................", "...##########...", "...##########...",
	"...##########...", "...###....###...", "...###....###...",
	"...###....###...", "...###....###...", "...###....###...",
	"...###....###...", "...###....###...", "................",
]
const BOOTS := [
	"................", "................", "................",
	"................", "................", "...###....###...",
	"...###....###...", "...###....###...", "..####....####..",
	"..####....####..", "..####....####..", "................",
]
const INGOT := [
	"................", "................", "................",
	"................", "....########....", "...##########...",
	"..############..", "..############..", "...##########...",
	"....########....", "................", "................",
]
const GEM := [
	"................", "................", "................",
	"......####......", ".....######.....", "....########....",
	"...##########...", "....########....", ".....######.....",
	"......####......", ".......##.......", "................",
]
const HIDE := [
	"................", "................", "................",
	"...##########...", "..############..", "..############..",
	"..############..", "..############..", "..############..",
	"..############..", "...##########...", "................",
]


static func _shade(c: Color, f: float) -> Color:
	return Color(clampf(c.r * f, 0.0, 1.0), clampf(c.g * f, 0.0, 1.0), clampf(c.b * f, 0.0, 1.0), c.a)


static func _px(img: Image, tile: int, x: int, y: int, c: Color) -> void:
	if x < 0 or y < 0 or x >= T or y >= T:
		return
	img.set_pixel((tile % COLS) * T + x, (tile / COLS) * T + y, c)


static func _noise(img: Image, tile: int, base: Color, amt: float, rng: RandomNumberGenerator) -> void:
	for y in T:
		for x in T:
			_px(img, tile, x, y, _shade(base, 1.0 + rng.randf_range(-amt, amt)))


static func _line(img: Image, tile: int, x0: int, y0: int, x1: int, y1: int, c: Color) -> void:
	var n := maxi(absi(x1 - x0), absi(y1 - y0))
	for i in range(n + 1):
		var t := float(i) / float(maxi(n, 1))
		_px(img, tile, roundi(lerpf(x0, x1, t)), roundi(lerpf(y0, y1, t)), c)


static func _pixels(img: Image, tile: int, pts: Array, c: Color) -> void:
	for p in pts:
		_px(img, tile, p[0], p[1], c)


static func _stone(img: Image, tile: int, rng: RandomNumberGenerator) -> void:
	var stone := Color(0.5, 0.5, 0.52)
	_noise(img, tile, stone, 0.07, rng)
	for i in 10:
		var bx := rng.randi() % 14
		var by := rng.randi() % 14
		var f := rng.randf_range(0.8, 1.12)
		for dy in 2:
			for dx in 2:
				_px(img, tile, bx + dx, by + dy, _shade(stone, f))


static func _deepslate(img: Image, tile: int, rng: RandomNumberGenerator) -> void:
	var base := Color(0.25, 0.25, 0.29)
	for y in T:
		var band := 1.0 + 0.10 * sin(float(y) * 1.7) + (0.08 if y % 5 == 0 else 0.0)
		for x in T:
			_px(img, tile, x, y, _shade(base, band * (1.0 + rng.randf_range(-0.08, 0.08))))
	for i in 9:
		var bx := rng.randi() % 13
		var by := rng.randi() % 15
		var f := rng.randf_range(0.78, 1.18)
		for dx in 3:
			_px(img, tile, bx + dx, by, _shade(base, f))


static func _leaves(img: Image, tile: int, base: Color, rng: RandomNumberGenerator, accent := Color(0, 0, 0, 0), acc_p := 0.0) -> void:
	var cov := []
	cov.resize(T * T)
	cov.fill(false)
	for y in T:
		for x in T:
			_px(img, tile, x, y, _shade(base, 0.5 + rng.randf() * 0.1))
	var shape := [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1], [1, 1]]
	for layer in 3:
		var n := 16 - layer * 3
		for i in n:
			var cx := rng.randi() % T
			var cy := rng.randi() % T
			var f := 0.62 + float(layer) * 0.26 + rng.randf_range(-0.08, 0.08)
			var lc := _shade(base, f)
			if accent.a > 0.0 and rng.randf() < acc_p:
				lc = _shade(accent, 0.8 + float(layer) * 0.15)
			for d in shape:
				var px := posmod(cx + int(d[0]), T)
				var py := posmod(cy + int(d[1]), T)
				var hl := lc
				if int(d[0]) == 1 and int(d[1]) == 1:
					hl = _shade(lc, 0.7)
				elif int(d[1]) == -1:
					hl = _shade(lc, 1.12)
				_px(img, tile, px, py, hl)
				cov[py * T + px] = true
	for y in T:
		for x in T:
			if not cov[y * T + x] and rng.randf() < 0.42:
				_px(img, tile, x, y, Color(0, 0, 0, 0))


static func _blade(img: Image, tile: int, x0: int, top: int, lean: float, col: Color) -> void:
	var h := 15 - top
	for k in range(h + 1):
		var t := float(k) / float(maxi(h, 1))
		var xx := x0 + int(round(lean * t * t))
		_px(img, tile, xx, 15 - k, _shade(col, lerpf(0.6, 1.18, t)))
		if t > 0.3 and t < 0.9:
			_px(img, tile, xx + 1, 15 - k, _shade(col, lerpf(0.5, 1.0, t)))


static func _ore(img: Image, tile: int, dot: Color, count: int, rng: RandomNumberGenerator, deep := false) -> void:
	if deep:
		_deepslate(img, tile, rng)
	else:
		_stone(img, tile, rng)
	for i in count:
		var bx := 1 + rng.randi() % 12
		var by := 1 + rng.randi() % 12
		for dy in 2:
			for dx in 2:
				if rng.randf() < 0.85:
					_px(img, tile, bx + dx, by + dy, _shade(dot, 1.0 + rng.randf_range(-0.2, 0.2)))


static func _m(rows: Array, x: int, y: int) -> bool:
	if y < 0 or y >= rows.size():
		return false
	var r: String = rows[y]
	if x < 0 or x >= r.length():
		return false
	return r[x] == "#"


static func _mask(img: Image, tile: int, rows: Array, base: Color, rng: RandomNumberGenerator) -> void:
	var ol := _shade(base, 0.3)
	ol.a = 1.0
	for y in rows.size():
		var r: String = rows[y]
		for x in r.length():
			if r[x] != "#":
				continue
			var up := _m(rows, x, y - 1)
			var dn := _m(rows, x, y + 1)
			var lf := _m(rows, x - 1, y)
			var rt := _m(rows, x + 1, y)
			var f := (1.1 - float(y) * 0.022) * (1.0 + rng.randf_range(-0.05, 0.05))
			if not up or not lf:
				f *= 1.18
			if not dn or not rt:
				f *= 0.7
			if not (up and dn and lf and rt):
				f = minf(f, 1.0) * 0.82
			var c := _shade(base, f)
			# заклёпки и стыки пластин
			if (x * 3 + y * 5) % 11 == 0 and up and dn and lf and rt:
				c = _shade(base, 1.3)
			_px(img, tile, x, y, c)
	_outline_tile(img, tile, ol)
	# детали: линии стыков
	var seam := _shade(base, 0.7)
	if rows == CHEST:
		for yy in range(4, 11):
			_px(img, tile, 8, yy, seam)
		for xx in range(3, 13):
			_px(img, tile, xx, 10, _shade(base, 0.62))
	elif rows == HELMET:
		for xx in range(4, 12):
			_px(img, tile, xx, 7, Color(0.06, 0.06, 0.09))
			_px(img, tile, xx, 8, Color(0.1, 0.1, 0.14))
		_px(img, tile, 8, 4, _shade(base, 1.3))
		_px(img, tile, 7, 4, _shade(base, 1.3))
	elif rows == LEGS:
		for yy in range(5, 11):
			_px(img, tile, 8, yy, Color(0, 0, 0, 0))
		for xx in range(3, 13):
			_px(img, tile, xx, 2, _shade(base, 0.62))
	elif rows == BOOTS:
		for xx in [3, 4, 5, 10, 11, 12]:
			_px(img, tile, xx, 8, _shade(base, 0.7))


static func _outline_tile(img: Image, tile: int, col: Color) -> void:
	var ox := (tile % COLS) * T
	var oy := (tile / COLS) * T
	var add := []
	for y in T:
		for x in T:
			if img.get_pixel(ox + x, oy + y).a > 0.1:
				continue
			var near := false
			for d in [[1, 0], [-1, 0], [0, 1], [0, -1]]:
				var nx: int = x + d[0]
				var ny: int = y + d[1]
				if nx >= 0 and ny >= 0 and nx < T and ny < T and img.get_pixel(ox + nx, oy + ny).a > 0.9:
					near = true
					break
			if near:
				add.append([x, y])
	for a in add:
		img.set_pixel(ox + a[0], oy + a[1], col)


## Головка инструмента: тоны от светлого к тёмному
static func _head_cols(head: Color) -> Array:
	return [_shade(head, 1.28), _shade(head, 1.05), _shade(head, 0.82), _shade(head, 0.62)]


static func _handle(img: Image, tile: int, x0: int, y0: int, x1: int, y1: int) -> void:
	var n := maxi(absi(x1 - x0), absi(y1 - y0))
	var lt := Color(0.66, 0.47, 0.25)
	var dk := Color(0.42, 0.28, 0.14)
	for i in range(n + 1):
		var t := float(i) / float(maxi(n, 1))
		var x := roundi(lerpf(x0, x1, t))
		var y := roundi(lerpf(y0, y1, t))
		_px(img, tile, x, y, lt if i % 2 == 0 else _shade(lt, 0.88))
		_px(img, tile, x + 1, y, dk)


static func _tools(img: Image, base: int, head: Color) -> void:
	var hc := _head_cols(head)
	var ol := Color(0.07, 0.05, 0.04, 1.0)
	# кирка: изогнутая двухслойная головка
	_handle(img, base, 2, 14, 10, 6)
	var outer := [[3, 7], [3, 6], [4, 5], [5, 4], [6, 3], [7, 2], [8, 2], [9, 2], [10, 2], [11, 3], [12, 4], [13, 5], [14, 6], [14, 7]]
	var inner := [[4, 7], [4, 6], [5, 5], [6, 4], [7, 3], [8, 3], [9, 3], [10, 3], [11, 4], [12, 5], [13, 6]]
	var core := [[5, 6], [6, 5], [7, 4], [8, 4], [9, 4], [10, 4], [11, 5], [12, 6]]
	_pixels(img, base, outer, hc[1])
	_pixels(img, base, inner, hc[2])
	_pixels(img, base, core, hc[3])
	_pixels(img, base, [[5, 4], [6, 3], [7, 2], [8, 2], [4, 5]], hc[0])
	_pixels(img, base, [[10, 5], [9, 4]], hc[2])
	_outline_tile(img, base, ol)
	# топор: широкое лезвие с заточкой
	_handle(img, base + 1, 3, 14, 11, 6)
	var blade := [[7, 2], [8, 2], [9, 2], [10, 2], [6, 3], [7, 3], [8, 3], [9, 3], [10, 3], [11, 3], [6, 4], [7, 4], [8, 4], [9, 4], [10, 4], [11, 4], [12, 4], [7, 5], [8, 5], [9, 5], [10, 5], [11, 5], [12, 5], [8, 6], [9, 6], [10, 6], [11, 6]]
	_pixels(img, base + 1, blade, hc[1])
	_pixels(img, base + 1, [[6, 3], [6, 4], [7, 5], [8, 6], [12, 4], [12, 5], [11, 6]], hc[0])
	_pixels(img, base + 1, [[10, 3], [11, 3], [11, 4], [10, 5], [9, 6], [10, 6]], hc[2])
	_pixels(img, base + 1, [[9, 4], [8, 4], [9, 5]], hc[3])
	_outline_tile(img, base + 1, ol)
	# лопата: округлый совок
	_handle(img, base + 2, 2, 14, 10, 6)
	var spade := [[11, 1], [12, 1], [10, 2], [11, 2], [12, 2], [13, 2], [9, 3], [10, 3], [11, 3], [12, 3], [13, 3], [14, 3], [9, 4], [10, 4], [11, 4], [12, 4], [13, 4], [14, 4], [10, 5], [11, 5], [12, 5], [13, 5], [11, 6], [12, 6]]
	_pixels(img, base + 2, spade, hc[1])
	_pixels(img, base + 2, [[11, 1], [10, 2], [9, 3], [9, 4], [10, 5]], hc[0])
	_pixels(img, base + 2, [[13, 3], [14, 3], [14, 4], [13, 5], [12, 6]], hc[2])
	_pixels(img, base + 2, [[12, 4], [11, 5]], hc[3])
	_outline_tile(img, base + 2, ol)
	# меч: клинок с гранью, гарда, рукоять и навершие
	for k in range(9):
		var bx := 6 + k
		var by := 9 - k
		_px(img, base + 3, bx, by, hc[1])
		_px(img, base + 3, bx + 1, by, hc[2])
		_px(img, base + 3, bx, by - 1, hc[0])
	_px(img, base + 3, 14, 1, hc[0])
	_px(img, base + 3, 15, 0, hc[1])
	var gold := Color(0.78, 0.6, 0.22)
	_line(img, base + 3, 3, 8, 8, 13, _shade(gold, 1.0))
	_line(img, base + 3, 4, 8, 8, 12, _shade(gold, 0.8))
	_handle(img, base + 3, 2, 14, 5, 11)
	_pixels(img, base + 3, [[1, 15], [2, 15], [1, 14]], gold)
	_outline_tile(img, base + 3, ol)


static func _armor(img: Image, base: int, c: Color, rng: RandomNumberGenerator) -> void:
	_mask(img, base, HELMET, c, rng)
	_mask(img, base + 1, CHEST, c, rng)
	_mask(img, base + 2, LEGS, c, rng)
	_mask(img, base + 3, BOOTS, c, rng)


static func build() -> Image:
	var img := Image.create(T * COLS, T * COLS, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var rng := RandomNumberGenerator.new()
	rng.seed = 424242

	var green := Color(0.34, 0.70, 0.24)
	var dirt := Color(0.55, 0.38, 0.25)
	var wood := Color(0.72, 0.57, 0.34)
	var bark := Color(0.40, 0.29, 0.17)

	# 0 трава (верх)
	_noise(img, 0, green, 0.13, rng)
	for i in 10:
		_px(img, 0, rng.randi() % T, rng.randi() % T, _shade(green, 0.78))
	# 1 трава (бок)
	_noise(img, 1, dirt, 0.10, rng)
	for x in T:
		var depth := 3 + rng.randi() % 2
		for y in depth:
			_px(img, 1, x, y, _shade(green, 1.0 + rng.randf_range(-0.13, 0.13)))
	# 2 земля
	_noise(img, 2, dirt, 0.10, rng)
	for i in 14:
		_px(img, 2, rng.randi() % T, rng.randi() % T, _shade(dirt, 0.72))
	# 3 камень
	_stone(img, 3, rng)
	# 4 песок
	_noise(img, 4, Color(0.86, 0.80, 0.55), 0.05, rng)
	# 5 бревно (бок)
	for y in T:
		for x in T:
			var f := 1.0 + rng.randf_range(-0.07, 0.07)
			if x % 4 == 0:
				f *= 0.78
			elif x % 4 == 2:
				f *= 1.06
			_px(img, 5, x, y, _shade(bark, f))
	# 6 бревно (торец)
	for y in T:
		for x in T:
			var d := maxf(absf(x - 7.5), absf(y - 7.5))
			var c: Color
			if d > 6.5:
				c = _shade(bark, 1.0 + rng.randf_range(-0.07, 0.07))
			else:
				var ring := int(d) % 2
				c = _shade(wood, (1.0 if ring == 0 else 0.84) * (1.0 + rng.randf_range(-0.04, 0.04)))
			_px(img, 6, x, y, c)
	# 7 листва
	for y in T:
		for x in T:
			var c := _shade(Color(0.20, 0.55, 0.16), 1.0 + rng.randf_range(-0.22, 0.22))
			if rng.randf() < 0.12:
				c = Color(0, 0, 0, 0)
			_px(img, 7, x, y, c)
	# 8 доски
	for y in T:
		for x in T:
			var f := 1.0 + rng.randf_range(-0.05, 0.05)
			if y % 4 == 3:
				f *= 0.72
			var row := y / 4
			var jx := 5 if row % 2 == 0 else 12
			if x == jx and y % 4 != 3:
				f *= 0.8
			_px(img, 8, x, y, _shade(wood, f))
	# 9 булыжник
	for y in T:
		for x in T:
			var cy := y / 5
			var xo := x + (3 if cy % 2 == 1 else 0)
			var cx := xo / 5
			var h := float((cx * 73 + cy * 151) % 7) / 7.0
			var f := (0.72 + h * 0.4) * (1.0 + rng.randf_range(-0.05, 0.05))
			if xo % 5 == 0 or y % 5 == 0:
				f *= 0.62
			_px(img, 9, x, y, _shade(Color(0.5, 0.5, 0.5), f))
	# 10 вода
	for y in T:
		for x in T:
			var c := _shade(Color(0.18, 0.42, 0.90), 1.0 + rng.randf_range(-0.05, 0.05))
			c.a = 0.72
			_px(img, 10, x, y, c)
	# 11 стекло
	var gl := Color(0.85, 0.95, 1.0, 0.95)
	for i in T:
		_px(img, 11, i, 0, gl)
		_px(img, 11, i, T - 1, gl)
		_px(img, 11, 0, i, gl)
		_px(img, 11, T - 1, i, gl)
	for i in 4:
		_px(img, 11, 3 + i, 3 + i, Color(1, 1, 1, 0.85))
	for i in 2:
		_px(img, 11, 10 + i, 11 + i, Color(1, 1, 1, 0.85))
	# 12 бедрок
	_noise(img, 12, Color(0.24, 0.24, 0.26), 0.35, rng)
	# 13 верстак (верх)
	for y in T:
		for x in T:
			var f := 1.0 + rng.randf_range(-0.04, 0.04)
			if x < 2 or y < 2 or x > 13 or y > 13:
				f *= 0.62
			elif x == 7 or x == 8 or y == 7 or y == 8:
				f *= 0.78
			_px(img, 13, x, y, _shade(wood, f))
	# 14 верстак (бок)
	for y in T:
		for x in T:
			var f := 1.0 + rng.randf_range(-0.04, 0.04)
			if y < 3:
				f *= 0.6
			elif y % 4 == 3:
				f *= 0.75
			_px(img, 14, x, y, _shade(wood, f))
	_pixels(img, 14, [[3, 7], [4, 8], [5, 9], [4, 7], [11, 6], [12, 6], [11, 7], [12, 7]], Color(0.25, 0.25, 0.28))
	_pixels(img, 14, [[8, 9], [9, 9], [8, 10], [9, 10]], Color(0.65, 0.2, 0.15))
	# 15 угольная руда
	_ore(img, 15, Color(0.08, 0.08, 0.09), 6, rng)
	# 16 снег (верх)
	_noise(img, 16, Color(0.95, 0.97, 1.0), 0.03, rng)
	# 17 снег (бок)
	_noise(img, 17, dirt, 0.10, rng)
	for x in T:
		var depth := 4 + rng.randi() % 2
		for y in depth:
			_px(img, 17, x, y, _shade(Color(0.95, 0.97, 1.0), 1.0 + rng.randf_range(-0.03, 0.03)))
	# 18 гравий
	for y in T:
		for x in T:
			var g := rng.randf_range(0.36, 0.64)
			_px(img, 18, x, y, Color(g, g * 0.97, g * 0.93))
	for i in 18:
		var bx := rng.randi() % 14
		var by := rng.randi() % 14
		var g2 := rng.randf_range(0.3, 0.7)
		for dy in 2:
			for dx in 2:
				_px(img, 18, bx + dx, by + dy, Color(g2, g2 * 0.96, g2 * 0.9))
	# 19-21 руды
	_ore(img, 19, Color(0.86, 0.66, 0.52), 7, rng)
	_ore(img, 20, Color(0.98, 0.82, 0.2), 6, rng)
	_ore(img, 21, Color(0.3, 0.92, 0.92), 6, rng)
	# 22 печь (спереди), 23 печь (бок/верх)
	_stone(img, 23, rng)
	for y in T:
		for x in T:
			var c := _shade(Color(0.48, 0.48, 0.5), 1.0 + rng.randf_range(-0.06, 0.06))
			if x < 1 or x > 14 or y < 1 or y > 14:
				c = _shade(c, 0.7)
			_px(img, 22, x, y, c)
	for y in range(6, 13):
		for x in range(4, 12):
			_px(img, 22, x, y, Color(0.07, 0.06, 0.06))
	for x in range(5, 11):
		_px(img, 22, x, 11, Color(0.95, 0.5, 0.1))
		if x % 2 == 0:
			_px(img, 22, x, 10, Color(1.0, 0.8, 0.2))
	# 32 (зарезервировано) ... 35 песчаник верх / 36 песчаник бок
	_noise(img, 35, Color(0.84, 0.78, 0.52), 0.04, rng)
	for y in T:
		for x in T:
			var f := 1.0 + rng.randf_range(-0.04, 0.04)
			if y == 3 or y == 4 or y == 11:
				f *= 0.8
			_px(img, 36, x, y, _shade(Color(0.84, 0.78, 0.52), f))
	# 37 кактус (бок), 38 кактус (верх)
	for y in T:
		for x in T:
			var f := 1.0 + rng.randf_range(-0.06, 0.06)
			if x % 4 == 0:
				f *= 0.82
			_px(img, 37, x, y, _shade(Color(0.15, 0.55, 0.2), f))
	for i in 12:
		_px(img, 37, rng.randi() % T, rng.randi() % T, Color(0.85, 0.9, 0.6))
	for y in T:
		for x in T:
			var edge := x < 1 or y < 1 or x > 14 or y > 14
			_px(img, 38, x, y, _shade(Color(0.15, 0.55, 0.2), 0.8 if edge else 1.05 + rng.randf_range(-0.05, 0.05)))
	# 39 каменные кирпичи
	for y in T:
		for x in T:
			var row := y / 4
			var xo := x + (4 if row % 2 == 1 else 0)
			var f := 1.0 + rng.randf_range(-0.05, 0.05)
			if y % 4 == 3 or xo % 8 == 7:
				f *= 0.62
			_px(img, 39, x, y, _shade(Color(0.52, 0.52, 0.54), f))
	# 40 берёза (бок)
	for y in T:
		for x in T:
			_px(img, 40, x, y, _shade(Color(0.86, 0.86, 0.8), 1.0 + rng.randf_range(-0.05, 0.05)))
	for i in 9:
		var bx := rng.randi() % 12
		var by := rng.randi() % 15
		for dx in 3:
			_px(img, 40, bx + dx, by, Color(0.15, 0.15, 0.15))
	# 41 листва берёзы, 42 хвоя
	for y in T:
		for x in T:
			var c := _shade(Color(0.45, 0.68, 0.26), 1.0 + rng.randf_range(-0.2, 0.2))
			if rng.randf() < 0.12:
				c = Color(0, 0, 0, 0)
			_px(img, 41, x, y, c)
			var c2 := _shade(Color(0.12, 0.38, 0.24), 1.0 + rng.randf_range(-0.2, 0.2))
			if rng.randf() < 0.1:
				c2 = Color(0, 0, 0, 0)
			_px(img, 42, x, y, c2)
	# 43 шерсть
	for y in T:
		for x in T:
			var f := 1.0 + rng.randf_range(-0.04, 0.04)
			if (x + y) % 5 == 0:
				f *= 0.93
			_px(img, 43, x, y, _shade(Color(0.94, 0.94, 0.94), f))
	# 44 красный цветок, 45 жёлтый цветок
	for kind in 2:
		var tile := 44 + kind
		var petal := Color(0.85, 0.12, 0.12) if kind == 0 else Color(0.98, 0.85, 0.15)
		_line(img, tile, 8, 15, 8, 8, Color(0.2, 0.55, 0.15))
		_pixels(img, tile, [[7, 12], [6, 11], [9, 11], [10, 10]], Color(0.2, 0.55, 0.15))
		_pixels(img, tile, [[7, 5], [8, 5], [9, 5], [6, 6], [7, 6], [9, 6], [10, 6], [7, 7], [8, 7], [9, 7], [8, 4]], petal)
		_px(img, tile, 8, 6, Color(1.0, 0.9, 0.3) if kind == 0 else Color(0.9, 0.5, 0.1))
	# 46 высокая трава
	var blade := Color(0.3, 0.72, 0.22)
	for b in [[3, 6], [6, 3], [9, 5], [12, 7], [5, 9], [10, 9]]:
		_line(img, 46, b[0], 15, b[0] + (1 if b[0] % 2 == 0 else -1), b[1], _shade(blade, 1.0 + rng.randf_range(-0.2, 0.2)))
	# 47 лёд
	for y in T:
		for x in T:
			var c := _shade(Color(0.62, 0.82, 0.96), 1.0 + rng.randf_range(-0.04, 0.04))
			c.a = 0.9
			_px(img, 47, x, y, c)
	_line(img, 47, 2, 12, 9, 5, Color(1, 1, 1, 0.7))
	_line(img, 47, 8, 14, 14, 8, Color(1, 1, 1, 0.6))
	# 48 ель (бревно, бок)
	for y in T:
		for x in T:
			var f := 1.0 + rng.randf_range(-0.07, 0.07)
			if x % 4 == 0:
				f *= 0.75
			_px(img, 48, x, y, _shade(Color(0.27, 0.19, 0.11), f))

	# 49 водоросли
	for fx in [[4, 15, 10], [8, 15, 6], [11, 15, 11]]:
		var cx := float(fx[0])
		for y in range(fx[1], fx[2] - 1, -1):
			var wob := sin(float(y) * 0.9 + cx) * 1.2
			var gc := _shade(Color(0.18, 0.55, 0.28), 0.8 + rng.randf() * 0.4)
			_px(img, 49, int(cx + wob), y, gc)
			_px(img, 49, int(cx + wob) + 1, y, _shade(gc, 0.82))
	# 50 факел
	for y in range(6, 16):
		_px(img, 50, 7, y, Color(0.46, 0.31, 0.15))
		_px(img, 50, 8, y, Color(0.36, 0.24, 0.11))
	_pixels(img, 50, [[7, 3], [8, 3], [7, 4], [8, 4], [7, 5], [8, 5]], Color(1.0, 0.72, 0.12))
	_pixels(img, 50, [[7, 2], [8, 4], [7, 5]], Color(1.0, 0.95, 0.5))
	_pixels(img, 50, [[6, 4], [9, 4], [8, 2]], Color(0.95, 0.4, 0.08))
	_pixels(img, 50, [[7, 1]], Color(0.95, 0.35, 0.08))
	# 51 кровать (верх), 52 кровать (бок)
	for y in T:
		for x in T:
			var bc := _shade(Color(0.72, 0.1, 0.12), 1.0 + rng.randf_range(-0.05, 0.05))
			if y < 5:
				bc = _shade(Color(0.93, 0.93, 0.95), 1.0 + rng.randf_range(-0.03, 0.03))
			if x == 0 or x == 15 or y == 15:
				bc = _shade(bc, 0.78)
			if y == 5:
				bc = _shade(bc, 0.85)
			_px(img, 51, x, y, bc)
	for y in T:
		for x in T:
			var sc := _shade(Color(0.72, 0.1, 0.12), 1.0 + rng.randf_range(-0.05, 0.05))
			if y >= 9:
				sc = _shade(Color(0.55, 0.38, 0.2), 1.0 + rng.randf_range(-0.07, 0.07))
				if y == 9:
					sc = _shade(sc, 0.7)
			_px(img, 52, x, y, sc)
	# 53-55 цветы
	var fl := [Color(0.25, 0.4, 0.95), Color(0.97, 0.97, 0.97), Color(0.95, 0.5, 0.72)]
	for k in 3:
		var tl := 53 + k
		_line(img, tl, 8, 15, 8, 8, Color(0.2, 0.55, 0.15))
		_pixels(img, tl, [[7, 12], [6, 11], [9, 12], [10, 11]], Color(0.2, 0.55, 0.15))
		_pixels(img, tl, [[7, 4], [8, 4], [9, 4], [6, 5], [7, 5], [9, 5], [10, 5], [6, 6], [7, 6], [8, 6], [9, 6], [10, 6], [7, 7], [8, 7], [9, 7], [8, 3]], fl[k])
		_px(img, tl, 8, 5, Color(1.0, 0.85, 0.2) if k != 0 else Color(0.95, 0.95, 1.0))

	# 56 андезит, 57 грязь, 58 замшелый булыжник, 59 цветущая листва
	for y in T:
		for x in T:
			var f56 := 1.0 + rng.randf_range(-0.07, 0.07)
			if (x * 5 + y * 3) % 11 == 0:
				f56 *= 0.85
			_px(img, 56, x, y, _shade(Color(0.58, 0.58, 0.58), f56))
			_px(img, 57, x, y, _shade(Color(0.28, 0.2, 0.13), 1.0 + rng.randf_range(-0.12, 0.12)))
			var mc := _shade(Color(0.5, 0.5, 0.52), 1.0 + rng.randf_range(-0.08, 0.08))
			if ((x / 4) + (y / 4)) % 2 == 0 and y % 4 == 3:
				mc = _shade(mc, 0.7)
			if rng.randf() < 0.38:
				mc = _shade(Color(0.2, 0.46, 0.18), 1.0 + rng.randf_range(-0.2, 0.2))
			_px(img, 58, x, y, mc)
			var lc := _shade(Color(0.20, 0.50, 0.17), 1.0 + rng.randf_range(-0.22, 0.22))
			if rng.randf() < 0.16:
				lc = Color(0.96, 0.55, 0.72)
			if rng.randf() < 0.1:
				lc = Color(0, 0, 0, 0)
			_px(img, 59, x, y, lc)
	# ---- предметы ----
	var stick := Color(0.5, 0.35, 0.18)
	# 24 палка
	_line(img, 24, 4, 13, 12, 5, stick)
	_line(img, 24, 5, 13, 12, 6, _shade(stick, 0.75))
	# инструменты
	_tools(img, 25, Color(0.72, 0.57, 0.34))
	_tools(img, 29, Color(0.55, 0.55, 0.58))
	_tools(img, 72, Color(0.88, 0.88, 0.9))
	_tools(img, 76, Color(0.35, 0.92, 0.92))
	# 33 сырое мясо
	for y in T:
		for x in T:
			var d := Vector2(x - 7.5, y - 7.5).length()
			if d < 5.5:
				var c := _shade(Color(0.88, 0.45, 0.45), 1.0 + rng.randf_range(-0.08, 0.08))
				if d > 4.4:
					c = _shade(c, 0.75)
				_px(img, 33, x, y, c)
	_pixels(img, 33, [[5, 5], [6, 5], [5, 6]], Color(1, 0.75, 0.75))
	_line(img, 33, 11, 11, 14, 14, Color(0.95, 0.95, 0.9))
	_pixels(img, 33, [[14, 13], [13, 14], [15, 14], [14, 15]], Color(0.95, 0.95, 0.9))
	# 34 уголь
	for y in T:
		for x in T:
			var d := Vector2(x - 7.5, y - 8.0).length()
			if d < 4.6 + rng.randf_range(-0.6, 0.6):
				_px(img, 34, x, y, _shade(Color(0.1, 0.1, 0.11), 1.0 + rng.randf_range(-0.3, 0.6)))
	# 64 железный слиток, 65 золотой слиток, 66 алмаз, 67 кожа
	_mask(img, 64, INGOT, Color(0.86, 0.86, 0.88), rng)
	_mask(img, 65, INGOT, Color(0.98, 0.8, 0.2), rng)
	_mask(img, 66, GEM, Color(0.35, 0.92, 0.92), rng)
	_mask(img, 67, HIDE, Color(0.55, 0.36, 0.22), rng)
	_pixels(img, 67, [[5, 5], [8, 5], [11, 5], [5, 10], [8, 10], [11, 10]], Color(0.35, 0.22, 0.12))
	# 68 жареное мясо
	for y in T:
		for x in T:
			var d := Vector2(x - 7.5, y - 7.5).length()
			if d < 5.5:
				var c := _shade(Color(0.62, 0.35, 0.18), 1.0 + rng.randf_range(-0.1, 0.1))
				if d > 4.4:
					c = _shade(c, 0.7)
				_px(img, 68, x, y, c)
	_pixels(img, 68, [[5, 5], [6, 5], [5, 6]], Color(0.85, 0.6, 0.4))
	_line(img, 68, 11, 11, 14, 14, Color(0.95, 0.95, 0.9))
	_pixels(img, 68, [[14, 13], [13, 14], [15, 14], [14, 15]], Color(0.95, 0.95, 0.9))
	# 69 яблоко
	for y in T:
		for x in T:
			var d := Vector2(x - 7.5, y - 9.0).length()
			if d < 5.0:
				var c := _shade(Color(0.85, 0.12, 0.1), 1.0 + rng.randf_range(-0.06, 0.06))
				if d > 4.0:
					c = _shade(c, 0.7)
				_px(img, 69, x, y, c)
	_pixels(img, 69, [[5, 7], [6, 7]], Color(1.0, 0.6, 0.6))
	_line(img, 69, 8, 4, 8, 2, Color(0.35, 0.22, 0.1))
	_pixels(img, 69, [[9, 3], [10, 3], [10, 2]], Color(0.2, 0.6, 0.15))
	# 93 сырая рыба, 94 жареная рыба
	for k in 2:
		var tl := 93 + k
		var body := Color(0.86, 0.5, 0.42) if k == 0 else Color(0.6, 0.38, 0.2)
		for y in T:
			for x in T:
				var d := Vector2((x - 7.0) / 6.0, (y - 8.0) / 3.2).length()
				if d < 1.0:
					var c := _shade(body, 1.0 + rng.randf_range(-0.07, 0.07) - (0.15 if y > 9 else 0.0))
					_px(img, tl, x, y, c)
		_pixels(img, tl, [[13, 6], [14, 5], [14, 6], [14, 9], [14, 10], [13, 9], [13, 8], [13, 7]], _shade(body, 0.85))
		_pixels(img, tl, [[3, 7]], Color(0.05, 0.05, 0.05))
		_line(img, tl, 6, 8, 9, 8, _shade(body, 1.2))
	# броня
	_armor(img, 80, Color(0.56, 0.36, 0.22), rng)
	_armor(img, 84, Color(0.86, 0.86, 0.88), rng)
	_armor(img, 88, Color(0.35, 0.92, 0.92), rng)
	# 92 щит (иконка брони в HUD)
	# ---- v5: объёмная листва, трава, новые блоки ----
	_leaves(img, 7, Color(0.20, 0.55, 0.16), rng)
	_leaves(img, 41, Color(0.42, 0.66, 0.24), rng)
	_leaves(img, 42, Color(0.11, 0.38, 0.24), rng)
	_leaves(img, 59, Color(0.20, 0.52, 0.17), rng, Color(0.96, 0.55, 0.72), 0.2)
	_noise(img, 0, Color(0.31, 0.64, 0.22), 0.10, rng)
	for i in 52:
		var gx := rng.randi() % T
		var gy := rng.randi() % T
		var gc := _shade(Color(0.31, 0.64, 0.22), rng.randf_range(0.7, 1.22))
		for k in 2 + rng.randi() % 2:
			_px(img, 0, gx, posmod(gy + k, T), _shade(gc, 1.0 + 0.08 * k))
	for x in T:
		if rng.randf() < 0.55:
			_px(img, 1, x, 4 + rng.randi() % 2, _shade(Color(0.28, 0.58, 0.2), rng.randf_range(0.7, 1.1)))
		if rng.randf() < 0.25:
			_px(img, 1, x, 5, _shade(Color(0.26, 0.5, 0.18), rng.randf_range(0.7, 1.0)))
	img.fill_rect(Rect2i(46 % COLS * T, 46 / COLS * T, T, T), Color(0, 0, 0, 0))
	var bcol := Color(0.3, 0.7, 0.2)
	for b in [[2, 5, -2.0], [4, 2, 1.0], [6, 6, -1.0], [8, 3, 2.0], [10, 5, 0.0], [12, 1, -2.0], [13, 7, 1.0], [5, 8, 0.0], [9, 9, -1.0]]:
		_blade(img, 46, int(b[0]), int(b[1]), float(b[2]), _shade(bcol, rng.randf_range(0.85, 1.2)))
	# 60 кровать (ножная часть, верх)
	for y in T:
		for x in T:
			var bc := _shade(Color(0.72, 0.1, 0.12), 1.0 + rng.randf_range(-0.05, 0.05))
			if y == 4 or y == 5:
				bc = _shade(bc, 1.14)
			if y >= 13:
				bc = _shade(Color(0.55, 0.38, 0.2), 1.0 + rng.randf_range(-0.07, 0.07))
			if x == 0 or x == 15:
				bc = _shade(bc, 0.78)
			_px(img, 60, x, y, bc)
	# 61 глубинный сланец, 62 медная, 63 изумрудная
	_deepslate(img, 61, rng)
	_ore(img, 62, Color(0.82, 0.46, 0.28), 6, rng)
	_pixels(img, 62, [[3, 4], [10, 9], [6, 12], [12, 3]], Color(0.25, 0.72, 0.62))
	_ore(img, 63, Color(0.15, 0.85, 0.42), 4, rng)
	_ore(img, 103, Color(0.88, 0.1, 0.1), 7, rng)
	_ore(img, 104, Color(0.08, 0.08, 0.09), 6, rng, true)
	_ore(img, 105, Color(0.86, 0.66, 0.52), 7, rng, true)
	_ore(img, 106, Color(0.98, 0.82, 0.2), 6, rng, true)
	_ore(img, 107, Color(0.3, 0.92, 0.92), 6, rng, true)
	_ore(img, 108, Color(0.82, 0.46, 0.28), 6, rng, true)
	_ore(img, 109, Color(0.88, 0.1, 0.1), 7, rng, true)
	# предметы: 100 медный слиток, 101 изумруд, 102 красная пыль
	_mask(img, 100, INGOT, Color(0.84, 0.5, 0.34), rng)
	_mask(img, 101, GEM, Color(0.2, 0.85, 0.42), rng)
	for pt in [[5, 9], [6, 8], [7, 9], [8, 8], [9, 9], [10, 8], [6, 10], [8, 10], [7, 11], [9, 11], [5, 10], [10, 10], [7, 7], [9, 7]]:
		_px(img, 102, pt[0], pt[1], _shade(Color(0.9, 0.08, 0.08), rng.randf_range(0.8, 1.15)))
	# ---- v6: сено, сундук, грядка, пшеница, дверь, хлеб ----
	var straw := Color(0.86, 0.72, 0.22)
	for y in T:
		for x in T:
			var f := 1.0 + rng.randf_range(-0.10, 0.10)
			if (x * 3 + y) % 4 == 0:
				f *= 0.86
			_px(img, 110, x, y, _shade(straw, f))
			var sf := 1.0 + rng.randf_range(-0.08, 0.08)
			if y % 3 == 2:
				sf *= 0.82
			_px(img, 111, x, y, _shade(straw, sf))
	for y in T:
		for x in [3, 4, 11, 12]:
			_px(img, 111, x, y, _shade(Color(0.55, 0.28, 0.14), 1.0 + rng.randf_range(-0.1, 0.1)))
	for x in T:
		_px(img, 110, x, 2, _shade(Color(0.55, 0.28, 0.14), 0.95))
		_px(img, 110, x, 13, _shade(Color(0.55, 0.28, 0.14), 0.95))
	var cwood := Color(0.58, 0.40, 0.18)
	for y in T:
		for x in T:
			var f2 := 1.0 + rng.randf_range(-0.06, 0.06)
			if y % 5 == 4:
				f2 *= 0.8
			var edge := x < 1 or y < 1 or x > 14 or y > 14
			var c112 := _shade(cwood, f2 * (0.62 if edge else 1.0))
			_px(img, 112, x, y, c112)
			var c113 := _shade(cwood, f2 * (0.62 if edge else 1.0))
			if y == 5 or y == 6:
				c113 = _shade(Color(0.33, 0.22, 0.1), 1.0 + rng.randf_range(-0.05, 0.05))
			_px(img, 113, x, y, c113)
	_pixels(img, 113, [[7, 5], [8, 5], [7, 6], [8, 6], [7, 7], [8, 7], [7, 8]], Color(0.78, 0.78, 0.82))
	_pixels(img, 113, [[7, 6], [8, 6]], Color(0.3, 0.3, 0.34))
	_pixels(img, 112, [[7, 7], [8, 7], [7, 8], [8, 8]], Color(0.78, 0.78, 0.82))
	for y in T:
		for x in T:
			var fm := 1.0 + rng.randf_range(-0.08, 0.08)
			var fc := Color(0.36, 0.22, 0.12)
			if x % 4 == 0:
				fc = _shade(fc, 0.62)
			_px(img, 115, x, y, _shade(fc, fm))
			_px(img, 116, x, y, _shade(Color(0.55, 0.38, 0.25), 1.0 + rng.randf_range(-0.1, 0.1)))
	# пшеница: 117..120
	var stalk := [Color(0.32, 0.68, 0.2), Color(0.45, 0.72, 0.22), Color(0.66, 0.7, 0.24), Color(0.86, 0.72, 0.28)]
	var heights := [4, 8, 12, 14]
	for st in 4:
		var tl := 117 + st
		var hh: int = heights[st]
		for bx in [1, 3, 5, 7, 9, 11, 13, 15]:
			var hv: int = hh - (int(bx) * 7 % 3)
			for yy in range(hv):
				var wob := 1 if (yy > hv / 2 and (bx % 4 == 1)) else 0
				var cc := _shade(stalk[st], 0.8 + 0.3 * float(yy) / float(maxi(hv, 1)))
				_px(img, tl, bx + wob, 15 - yy, cc)
				if bx < 15:
					_px(img, tl, bx + 1 + wob, 15 - yy, _shade(cc, 0.8))
			if st == 3:
				_pixels(img, tl, [[bx, 15 - hv], [bx, 14 - hv], [bx + 1, 15 - hv], [bx + 1, 16 - hv - 2]], _shade(Color(0.92, 0.78, 0.3), 1.05))
	# дверь
	var dwood := Color(0.62, 0.47, 0.27)
	for y in T:
		for x in T:
			var f3 := 1.0 + rng.randf_range(-0.05, 0.05)
			if x % 4 == 3:
				f3 *= 0.78
			var fr := x < 1 or x > 14 or y < 1 or y > 14
			var cd := _shade(dwood, f3 * (0.7 if fr else 1.0))
			_px(img, 121, x, y, cd)
			_px(img, 122, x, y, cd)
	for wy in [3, 4, 5, 6, 8, 9, 10, 11]:
		pass
	for rect in [[3, 3, 5, 5], [8, 3, 12, 5], [3, 7, 5, 10], [8, 7, 12, 10]]:
		for yy in range(int(rect[1]), int(rect[3]) + 1):
			for xx in range(int(rect[0]), int(rect[2]) + 1):
				_px(img, 122, xx, yy, Color(0.55, 0.78, 0.88, 1.0) if (xx + yy) % 2 == 0 else Color(0.45, 0.7, 0.82, 1.0))
	_pixels(img, 121, [[12, 8], [12, 9]], Color(0.82, 0.82, 0.86))
	# хлеб, пшеница (предмет), семена
	for y in range(5, 12):
		for x in range(2, 14):
			var inside := ((x - 8.0) / 6.0) * ((x - 8.0) / 6.0) + ((y - 8.5) / 3.6) * ((y - 8.5) / 3.6) < 1.0
			if inside:
				var bc := Color(0.78, 0.5, 0.2)
				if y < 7:
					bc = Color(0.88, 0.6, 0.26)
				elif y > 10:
					bc = Color(0.6, 0.38, 0.15)
				_px(img, 124, x, y, _shade(bc, 1.0 + rng.randf_range(-0.07, 0.07)))
	for x in [5, 8, 11]:
		_pixels(img, 124, [[x, 6], [x + 1, 7]], Color(0.95, 0.76, 0.42))
	for bx in [4, 7, 10]:
		for yy in range(4, 14):
			_px(img, 125, bx + (yy - 4) / 5, 14 - (yy - 4), _shade(Color(0.9, 0.74, 0.3), 0.85 + 0.03 * yy))
		_pixels(img, 125, [[bx + 2, 3], [bx + 1, 2], [bx + 3, 4]], Color(0.95, 0.82, 0.38))
	_pixels(img, 125, [[3, 12], [4, 13], [5, 12], [6, 13], [7, 12], [8, 13], [9, 12], [10, 13], [11, 12], [12, 13]], Color(0.55, 0.3, 0.14))
	for pt in [[4, 5], [8, 4], [11, 6], [6, 9], [10, 10], [5, 12], [12, 12], [8, 8]]:
		_pixels(img, 126, [[pt[0], pt[1]], [pt[0] + 1, pt[1]]], Color(0.42, 0.55, 0.2))
		_pixels(img, 126, [[pt[0], pt[1] + 1]], Color(0.3, 0.4, 0.14))
	return img


static func _dist_seg(p: Vector2, a: Vector2, b: Vector2) -> float:
	var ab := b - a
	var t := clampf((p - a).dot(ab) / maxf(ab.length_squared(), 0.0001), 0.0, 1.0)
	return p.distance_to(a + ab * t)


## Полоска из 10 стадий трещин (160x16)
static func build_cracks() -> Image:
	var img := Image.create(T * 10, T, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var rng := RandomNumberGenerator.new()
	rng.seed = 99
	var angles := []
	for i in 5:
		angles.append(rng.randf() * TAU)
	var center := Vector2(8, 8)
	for s in 10:
		var length := 2.0 + s * 1.1
		var lim := 0.55 + s * 0.12
		var segs := []
		for a in angles:
			segs.append(center + Vector2(cos(a), sin(a)) * length)
		for y in T:
			for x in T:
				var dmin := 99.0
				for e in segs:
					dmin = minf(dmin, _dist_seg(Vector2(x + 0.5, y + 0.5), center, e))
				if dmin < lim:
					img.set_pixel(s * T + x, y, Color(0, 0, 0, 0.7))
	return img


## Иконки HUD: щит (0 пустой, 1 половина, 2 полный), пузырь
static func _icon(rows: Array, base: Color, state: int, hl_xy := Vector2i(1, 1)) -> Image:
	var h := rows.size()
	var w: int = String(rows[0]).length()
	var img := Image.create(w + 2, h + 2, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in h:
		var r: String = rows[y]
		for x in w:
			if r[x] != "#":
				continue
			var lit := state == 2 or (state == 1 and x < (w + 1) / 2)
			var up := y > 0 and String(rows[y - 1])[x] == "#"
			var lf := x > 0 and r[x - 1] == "#"
			var dn := y < h - 1 and String(rows[y + 1])[x] == "#"
			var rt := x < w - 1 and r[x + 1] == "#"
			var c := Color(0.17, 0.12, 0.13, 0.9)
			if lit:
				var f := 1.12 - 0.05 * float(y)
				if not up or not lf:
					f *= 1.2
				if not dn or not rt:
					f *= 0.78
				c = Color(clampf(base.r * f, 0, 1), clampf(base.g * f, 0, 1), clampf(base.b * f, 0, 1), 1.0)
			img.set_pixel(x + 1, y + 1, c)
	if state > 0:
		img.set_pixel(hl_xy.x + 1, hl_xy.y + 1, Color(1, 1, 1, 0.95))
	var add := []
	for y in h + 2:
		for x in w + 2:
			if img.get_pixel(x, y).a > 0.05:
				continue
			for dy in range(-1, 2):
				for dx in range(-1, 2):
					var nx := x + dx
					var ny := y + dy
					if nx >= 0 and ny >= 0 and nx < w + 2 and ny < h + 2 and img.get_pixel(nx, ny).a > 0.05:
						add.append([x, y])
						dx = 2
						break
	for a in add:
		img.set_pixel(a[0], a[1], Color(0.04, 0.02, 0.03, 0.95))
	return img


static func build_heart(state: int) -> Image:
	var rows := [
		".##...##.", "####.####", "#########", "#########",
		".#######.", "..#####..", "...###...", "....#....",
	]
	return _icon(rows, Color(0.9, 0.1, 0.12), state, Vector2i(1, 1))


static func build_food(state: int) -> Image:
	var rows := [
		"....#####.", "...#######", "..########", "..########",
		"..#######.", "...#####..", "..###.....", ".###......", "##........",
	]
	var img := _icon(rows, Color(0.78, 0.42, 0.14), state, Vector2i(5, 1))
	# кость
	var bone := Color(0.96, 0.95, 0.88) if state > 0 else Color(0.3, 0.3, 0.3, 0.85)
	for p in [[2, 8], [1, 9], [2, 9], [3, 8], [1, 8], [3, 7]]:
		img.set_pixel(p[0] + 1, p[1] + 1, bone)
	return img


static func build_shield(state: int) -> Image:
	var rows := [
		"..##...##..", ".####.####.", "###########", "###########",
		".#########.", ".#########.", ".#########.", "..#######..", "...#####...",
	]
	return _icon(rows, Color(0.78, 0.8, 0.88), state, Vector2i(2, 2))


static func build_bubble() -> Image:
	var img := Image.create(11, 11, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in 11:
		for x in 11:
			var d := Vector2(x - 5.0, y - 5.0).length()
			if d < 4.6 and d > 3.2:
				img.set_pixel(x, y, Color(0.8, 0.95, 1.0, 0.98))
			elif d <= 3.2:
				img.set_pixel(x, y, Color(0.4, 0.66, 0.96, 0.55))
			elif d < 5.6:
				img.set_pixel(x, y, Color(0.05, 0.1, 0.25, 0.8))
	for p in [[3, 3], [4, 2], [3, 4]]:
		img.set_pixel(p[0], p[1], Color(1, 1, 1, 1))
	img.set_pixel(7, 7, Color(0.9, 1, 1, 0.9))
	return img


## Увеличивает атлас (1K: scale=4, 2K: scale=8) и готовит мипмапы
static func build_hires(base: Image, scale: int) -> Image:
	var w := base.get_width()
	var h := base.get_height()
	var out := base.duplicate()
	# заливаем цвет под прозрачными пикселями, чтобы не появлялась тёмная кайма
	for y in h:
		for x in w:
			if base.get_pixel(x, y).a < 0.05:
				var r := 0.0
				var g := 0.0
				var b := 0.0
				var n := 0
				for dy in range(-1, 2):
					for dx in range(-1, 2):
						var xx := x + dx
						var yy := y + dy
						if xx < 0 or yy < 0 or xx >= w or yy >= h:
							continue
						var c := base.get_pixel(xx, yy)
						if c.a > 0.5:
							r += c.r
							g += c.g
							b += c.b
							n += 1
				if n > 0:
					out.set_pixel(x, y, Color(r / n, g / n, b / n, 0.0))
	out.resize(w * scale, h * scale, Image.INTERPOLATE_CUBIC)
	# детальные текстуры блоков (трава, земля, камень, песок, дерево, листва, булыжник)
	var ts := T * scale
	for tile in HD_TILES:
		var path := "res://assets/hd/tile_%d.png" % tile
		if not ResourceLoader.exists(path):
			continue
		var hd: Image = load(path).get_image()
		hd.convert(Image.FORMAT_RGBA8)
		hd.resize(ts, ts, Image.INTERPOLATE_LANCZOS)
		out.blit_rect(hd, Rect2i(0, 0, ts, ts), Vector2i((tile % COLS) * ts, (tile / COLS) * ts))
		if tile == 7:
			for v in [[41, Color(1.12, 1.08, 0.8)], [42, Color(0.55, 0.85, 1.0)], [59, Color(1.0, 1.0, 1.0)]]:
				var h2: Image = hd.duplicate()
				for yy in ts:
					for xx in ts:
						var cc := h2.get_pixel(xx, yy)
						h2.set_pixel(xx, yy, Color(minf(cc.r * v[1].r, 1.0), minf(cc.g * v[1].g, 1.0), minf(cc.b * v[1].b, 1.0), 1.0))
				out.blit_rect(h2, Rect2i(0, 0, ts, ts), Vector2i((v[0] % COLS) * ts, (v[0] / COLS) * ts))
	out.generate_mipmaps()
	return out
