class_name StreamCache
extends RefCounted
## Общий для потоков кэш путей ручьёв (экземпляр, а не static — так безопаснее).

var data := {}
var mtx := Mutex.new()
