class_name World
extends Node3D
## Воксельный мир: чанки (генерация и меши в потоках), физика тел, рейкаст.

const CS := 16
const CH := 64
const SEA := 24

const DIRS := [Vector3i(0, 1, 0), Vector3i(0, -1, 0), Vector3i(1, 0, 0), Vector3i(-1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1)]
const FACE_ORIGIN := [Vector3(0, 1, 0), Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(0, 0, 0), Vector3(0, 0, 1), Vector3(0, 0, 0)]
const FACE_U := [Vector3(1, 0, 0), Vector3(0, 0, 1), Vector3(0, 0, 1), Vector3(0, 1, 0), Vector3(0, 1, 0), Vector3(1, 0, 0)]
const FACE_V := [Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(0, 1, 0), Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(0, 1, 0)]
const FACE_SHADE := [1.0, 0.55, 0.82, 0.82, 0.68, 0.68]
const UV_MODE := [0, 0, 1, 2, 2, 1]
const CI := [0.0, 1.0, 1.0, 0.0]
const CJ := [0.0, 0.0, 1.0, 1.0]

signal animal_spawn(kind: String, pos: Vector3)


## Буфер вершин для статических мешей (рука, трещины, дроп)
class MeshBuf:
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var c := PackedColorArray()
	var t := PackedVector2Array()
	var i := PackedInt32Array()

	func to_mesh(mat: Material) -> ArrayMesh:
		var mesh := ArrayMesh.new()
		if v.size() > 0:
			var arr := []
			arr.resize(Mesh.ARRAY_MAX)
			arr[Mesh.ARRAY_VERTEX] = v
			arr[Mesh.ARRAY_NORMAL] = n
			arr[Mesh.ARRAY_COLOR] = c
			arr[Mesh.ARRAY_TEX_UV] = t
			arr[Mesh.ARRAY_INDEX] = i
			mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
			mesh.surface_set_material(0, mat)
		return mesh


var seed_value := 0
var radius := 5
var ao_enabled := true
var gen: WorldGen
var containers := {}   # Vector3i -> Array из 27 слотов [id, n, износ]
var stream_cache := StreamCache.new()
var chunks := {}      # Vector2i -> PackedByteArray
var hmaps := {}       # Vector2i -> PackedByteArray
var bios := {}
var hm_changed := false
var maxys := {}       # Vector2i -> int
var edits := {}       # Vector2i -> Dictionary(Vector3i -> int)
var detail_done := {}
var nodes := {}       # Vector2i -> Array[MeshInstance3D x3]
var meshed := {}
var dirty := {}
var gen_pending := {}
var mesh_pending := {}
var gen_queue: Array = []
var mesh_queue: Array = []
var center_chunk := Vector2i(99999, 99999)

var threaded := true
var _mutex := Mutex.new()
var _results: Array = []
var _spawned := {}    # чанки, для которых уже выпущены животные


func setup(s: int) -> void:
	seed_value = s
	gen = WorldGen.new()
	gen.setup(s)


func _exit_tree() -> void:
	# дожидаемся задач, чтобы не трогать освобождённые данные
	for i in 200:
		if gen_pending.is_empty() and mesh_pending.is_empty():
			break
		OS.delay_msec(5)


# ---------------- доступ к блокам ----------------
func get_block(x: int, y: int, z: int) -> int:
	if y < 0:
		return G.BEDROCK
	if y >= CH:
		return G.AIR
	var key := Vector2i(x >> 4, z >> 4)
	if not chunks.has(key):
		return -1
	var d: PackedByteArray = chunks[key]
	return d[(x & 15) + (z & 15) * CS + y * 256]


func column_top(x: int, z: int) -> int:
	var key := Vector2i(x >> 4, z >> 4)
	if not hmaps.has(key):
		return -1
	var hm: PackedByteArray = hmaps[key]
	return hm[(x & 15) + (z & 15) * CS]


func is_solid_at(x: int, y: int, z: int) -> bool:
	var id := get_block(x, y, z)
	return id < 0 or G.SOLID[id] == 1


func is_water_at(x: int, y: int, z: int) -> bool:
	var wid := get_block(x, y, z)
	return wid == G.WATER or wid == G.SEAWEED


func _recalc_col(d: PackedByteArray, hm: PackedByteArray, lx: int, lz: int) -> void:
	var top := 0
	for y in range(CH - 1, -1, -1):
		var id := d[lx + lz * CS + y * 256]
		if id != 0 and id != G.WATER:
			top = y
			break
	hm[lx + lz * CS] = top


signal edited(x: int, y: int, z: int, id: int)
var applying_remote := false


func set_block(x: int, y: int, z: int, id: int, record := true) -> void:
	if y < 0 or y >= CH:
		return
	var key := Vector2i(x >> 4, z >> 4)
	if not chunks.has(key):
		return
	var d: PackedByteArray = chunks[key]
	var lx := x & 15
	var lz := z & 15
	d[lx + lz * CS + y * 256] = id
	if record:
		if not edits.has(key):
			edits[key] = {}
		edits[key][Vector3i(x, y, z)] = id
		if not applying_remote:
			edited.emit(x, y, z, id)
	_recalc_col(d, hmaps[key], lx, lz)
	hm_changed = true
	maxys[key] = maxi(maxys[key], y + 1)
	dirty[key] = true
	if lx == 0:
		_dirty_if(Vector2i(key.x - 1, key.y))
	if lx == 15:
		_dirty_if(Vector2i(key.x + 1, key.y))
	if lz == 0:
		_dirty_if(Vector2i(key.x, key.y - 1))
	if lz == 15:
		_dirty_if(Vector2i(key.x, key.y + 1))


func _dirty_if(k: Vector2i) -> void:
	if meshed.has(k):
		dirty[k] = true


func edits_flat() -> PackedInt32Array:
	var out := PackedInt32Array()
	for key in edits:
		var ed: Dictionary = edits[key]
		for pv in ed:
			var p: Vector3i = pv
			out.append(p.x)
			out.append(p.y)
			out.append(p.z)
			out.append(ed[pv])
	return out


func load_edits(arr: PackedInt32Array) -> void:
	edits.clear()
	var i := 0
	while i + 3 < arr.size():
		var p := Vector3i(arr[i], arr[i + 1], arr[i + 2])
		var key := Vector2i(p.x >> 4, p.z >> 4)
		if not edits.has(key):
			edits[key] = {}
		edits[key][p] = arr[i + 3]
		i += 4


## Ищет подходящую точку появления на суше
func find_spawn() -> Vector3:
	for r in range(0, 60):
		var steps := maxi(1, r * 4)
		for s in steps:
			var a := TAU * float(s) / float(steps)
			var wx := int(cos(a) * r * 8.0)
			var wz := int(sin(a) * r * 8.0)
			var ci := gen.col_info(wx, wz)
			if ci.y != WorldGen.B_OCEAN and ci.y != WorldGen.B_BEACH and ci.x > SEA + 1 and ci.x < SEA + 12:
				return Vector3(wx + 0.5, ci.x + 2.0, wz + 0.5)
	return Vector3(0.5, SEA + 10.0, 0.5)


# ---------------- потоки ----------------
func _gen_job(key: Vector2i, edit: Dictionary) -> void:
	var g := WorldGen.new()
	g.setup(seed_value)
	g.cache = stream_cache
	var res := g.generate(key, edit)
	res["kind"] = "gen"
	_mutex.lock()
	_results.append(res)
	_mutex.unlock()


func _mesh_job(key: Vector2i, c9: Array, h9: Array, bio: PackedByteArray, maxy: int, cfg: Dictionary) -> void:
	var res := ChunkMesher.build(c9, h9, bio, maxy, cfg)
	res["kind"] = "mesh"
	res["key"] = key
	_mutex.lock()
	_results.append(res)
	_mutex.unlock()


func _request_gen(key: Vector2i) -> void:
	gen_pending[key] = true
	var ed: Dictionary = {}
	if edits.has(key):
		ed = (edits[key] as Dictionary).duplicate()
	var cb := _gen_job.bind(key, ed)
	if threaded:
		WorkerThreadPool.add_task(cb)
	else:
		cb.call()


func _request_mesh(key: Vector2i) -> void:
	var c9 := []
	var h9 := []
	for dz in range(-1, 2):
		for dx in range(-1, 2):
			var k := key + Vector2i(dx, dz)
			if chunks.has(k):
				c9.append(chunks[k])
				h9.append(hmaps[k])
			else:
				c9.append(null)
				h9.append(null)
	mesh_pending[key] = true
	dirty.erase(key)
	G.apply_grass()
	var bn := 0
	var ddx := key.x - center_chunk.x
	var ddz := key.y - center_chunk.y
	if ddx * ddx + ddz * ddz <= G.blade_chunks * G.blade_chunks:
		bn = G.blade_n
	if bn > 0:
		detail_done[key] = true
	var cfg := {"ao": ao_enabled and G.ao, "opq": G.OPAQUE, "plant": G.PLANT, "low": G.LOW, "tint": G.TINT, "t_top": G.T_TOP, "t_bot": G.T_BOT, "t_side": G.T_SIDE, "water": G.WATER, "torch": G.TORCH, "furnace": G.FURNACE, "weed": G.SEAWEED, "cobble": -1, "stone": -1, "ox": key.x * CS, "oz": key.y * CS, "blades": bn, "tall": G.TALL_GRASS, "cards": bn > 0, "leaf": G.LEAF, "leaf_depth": G.leaf_depth, "shaped": G.SHAPED, "boxes": G.SHAPE_BOXES, "fence": G.FENCE}
	var cb := _mesh_job.bind(key, c9, h9, bios[key], int(maxys[key]), cfg)
	if threaded:
		WorkerThreadPool.add_task(cb)
	else:
		cb.call()


func _in_range(k: Vector2i, extra: int) -> bool:
	var dx := k.x - center_chunk.x
	var dz := k.y - center_chunk.y
	var r := radius + extra
	return dx * dx + dz * dz <= r * r + 1


func _apply_mesh(res: Dictionary) -> void:
	var key: Vector2i = res["key"]
	mesh_pending.erase(key)
	if not chunks.has(key) or not _in_range(key, 2):
		return
	var pair: Array
	if nodes.has(key):
		pair = nodes[key]
	else:
		pair = []
		for i in 3:
			var mi := MeshInstance3D.new()
			mi.position = Vector3(key.x * CS, 0, key.y * CS)
			mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			add_child(mi)
			pair.append(mi)
		for i in 2:
			var mm := MultiMeshInstance3D.new()
			mm.position = Vector3(key.x * CS + 8, 32, key.y * CS + 8)
			mm.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
			mm.visibility_range_end = 27.0
			add_child(mm)
			pair.append(mm)
		nodes[key] = pair
	var mats := [G.terrain_mat, G.water_mat, G.plant_mat]
	var names := ["main", "water", "plant"]
	for i in 3:
		var arr: Array = res[names[i]]
		var mesh := ArrayMesh.new()
		if arr.size() > 0:
			mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
			mesh.surface_set_material(0, mats[i])
		(pair[i] as MeshInstance3D).mesh = mesh
	_fill_models(pair[3], "stone_lo", res["s_pos"], res["s_inf"])
	_fill_models(pair[4], "cobble_lo", res["c_pos"], res["c_inf"])
	meshed[key] = true


static var _lo_cache := {}


func _fill_models(mmi: MultiMeshInstance3D, nm: String, pos: PackedVector3Array, inf: PackedVector2Array) -> void:
	if pos.is_empty() or not G.real_models:
		mmi.multimesh = null
		return
	if not _lo_cache.has(nm):
		var src: ArrayMesh = load("res://assets/models/%s.res" % nm)
		var arr: Array = src.surface_get_arrays(0)
		if nm == "cobble_lo":
			var cols: PackedColorArray = arr[Mesh.ARRAY_COLOR]
			for ci in cols.size():
				cols[ci] = Color(cols[ci].r * 0.5, cols[ci].g * 0.5, cols[ci].b * 0.52, 1.0)
			arr[Mesh.ARRAY_COLOR] = cols
		var m := ArrayMesh.new()
		m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
		m.surface_set_material(0, inst_material())
		_lo_cache[nm] = m
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.use_colors = true
	mm.use_custom_data = true
	mm.mesh = _lo_cache[nm]
	mm.instance_count = pos.size()
	for i in pos.size():
		var rot := float((int(pos[i].x * 7.0 + pos[i].y * 13.0 + pos[i].z * 5.0)) % 4) * PI * 0.5
		mm.set_instance_transform(i, Transform3D(Basis(Vector3.UP, rot), pos[i] - Vector3(8, 32, 8)))
		mm.set_instance_color(i, Color.WHITE)
		mm.set_instance_custom_data(i, Color(inf[i].x, inf[i].y, 0, 0))
	mmi.multimesh = mm


static var _inst_mat: ShaderMaterial


static func inst_material() -> ShaderMaterial:
	if _inst_mat == null:
		var sh := Shader.new()
		sh.code = """
shader_type spatial;
render_mode unshaded, cull_back, depth_draw_opaque;
uniform float day = 1.0;
uniform float model_r = 14.5;
varying vec2 info;
varying vec3 wn;
varying vec3 wpos;
void vertex() {
	wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	info = INSTANCE_CUSTOM.xy;
	wn = normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz);
}
void fragment() {
	if (length(wpos - INV_VIEW_MATRIX[3].xyz) > model_r) {
		discard;
	}
	float l = 0.55 + 0.45 * max(dot(normalize(wn), normalize(vec3(-0.35, 0.8, 0.45))), 0.0);
	vec3 amb = vec3(mix(0.30, 1.0, day)) * mix(0.35, 1.0, info.x);
	vec3 torch = vec3(1.0, 0.72, 0.38) * info.y * 1.1;
	ALBEDO = COLOR.rgb * l * (amb + torch) * 1.3;
}
"""
		_inst_mat = ShaderMaterial.new()
		_inst_mat.shader = sh
	return _inst_mat


func _apply_gen(res: Dictionary) -> void:
	var key: Vector2i = res["key"]
	gen_pending.erase(key)
	if not _in_range(key, 3):
		return
	chunks[key] = res["d"]
	hmaps[key] = res["hm"]
	bios[key] = res["bio"]
	hm_changed = true
	maxys[key] = res["maxy"]
	for cv in res.get("chests", []):
		var cp: Vector3i = cv[0]
		var cd: PackedByteArray = res["d"]
		if not containers.has(cp) and cd[(cp.x & 15) + (cp.z & 15) * CS + cp.y * 256] == G.CHEST:
			containers[cp] = cv[1]
	if not _spawned.has(key):
		_spawned[key] = true
		for sp in res["spawns"]:
			animal_spawn.emit(sp[0], sp[1])


func _free_chunk_nodes(key: Vector2i) -> void:
	if nodes.has(key):
		for n in nodes[key]:
			n.queue_free()
		nodes.erase(key)
	meshed.erase(key)
	detail_done.erase(key)


# ---------------- стриминг ----------------
func update_center(pos: Vector3) -> void:
	var c := Vector2i(floori(pos.x) >> 4, floori(pos.z) >> 4)
	if c == center_chunk:
		return
	center_chunk = c
	_rebuild_queues()


func force_refresh() -> void:
	center_chunk = Vector2i(99999, 99999)


func _rebuild_queues() -> void:
	gen_queue.clear()
	mesh_queue.clear()
	var gr := radius + 1
	var lst := []
	for dz in range(-gr, gr + 1):
		for dx in range(-gr, gr + 1):
			var dist := dx * dx + dz * dz
			if dist > gr * gr + 1:
				continue
			lst.append([dist, center_chunk + Vector2i(dx, dz)])
	lst.sort_custom(func(a, b): return a[0] < b[0])
	for e in lst:
		var k: Vector2i = e[1]
		if not chunks.has(k) and not gen_pending.has(k):
			gen_queue.append(k)
		if e[0] <= radius * radius + 1 and not meshed.has(k) and not mesh_pending.has(k):
			mesh_queue.append(k)
	for k in nodes.keys():
		if not _in_range(k, 2):
			_free_chunk_nodes(k)
		elif meshed.has(k) and not detail_done.has(k):
			var ex: int = k.x - center_chunk.x
			var ez: int = k.y - center_chunk.y
			if ex * ex + ez * ez <= G.blade_chunks * G.blade_chunks:
				dirty[k] = true
	for k in chunks.keys():
		if not _in_range(k, 4):
			chunks.erase(k)
			hmaps.erase(k)
			bios.erase(k)
			maxys.erase(k)
			_spawned.erase(k)
			dirty.erase(k)
			_free_chunk_nodes(k)


func _neighbors_ready(k: Vector2i) -> bool:
	return chunks.has(k + Vector2i(1, 0)) and chunks.has(k + Vector2i(-1, 0)) and chunks.has(k + Vector2i(0, 1)) and chunks.has(k + Vector2i(0, -1))


## Вызывается каждый кадр; budget_us — бюджет на применение готовых мешей
func process_queues(budget_us: int) -> void:
	var t0 := Time.get_ticks_usec()
	# забираем результаты потоков
	_mutex.lock()
	var got := _results
	_results = []
	_mutex.unlock()
	var deferred := []
	for res in got:
		if Time.get_ticks_usec() - t0 > budget_us and res["kind"] == "mesh":
			deferred.append(res)
			continue
		if res["kind"] == "gen":
			_apply_gen(res)
		else:
			_apply_mesh(res)
	if not deferred.is_empty():
		_mutex.lock()
		_results.append_array(deferred)
		_mutex.unlock()

	# правки блоков — сразу в работу
	if not dirty.is_empty():
		for k in dirty.keys():
			if mesh_pending.has(k):
				continue
			if chunks.has(k):
				_request_mesh(k)
			else:
				dirty.erase(k)

	# новая генерация
	var lim := 4 if threaded else 1
	var inflight_gen := gen_pending.size()
	while inflight_gen < lim and not gen_queue.is_empty():
		var k2: Vector2i = gen_queue.pop_front()
		if not chunks.has(k2) and not gen_pending.has(k2) and _in_range(k2, 1):
			_request_gen(k2)
			inflight_gen += 1
	# новые меши
	var inflight_mesh := mesh_pending.size()
	var tries := mesh_queue.size()
	while inflight_mesh < lim and tries > 0 and not mesh_queue.is_empty():
		tries -= 1
		var k3: Vector2i = mesh_queue.pop_front()
		if meshed.has(k3) or mesh_pending.has(k3) or not _in_range(k3, 1):
			continue
		if chunks.has(k3) and _neighbors_ready(k3):
			_request_mesh(k3)
			inflight_mesh += 1
		else:
			mesh_queue.append(k3)


## Готовы ли меши вокруг точки (для экрана загрузки)
func area_ready(pos: Vector3, r: int) -> bool:
	var c := Vector2i(floori(pos.x) >> 4, floori(pos.z) >> 4)
	for dz in range(-r, r + 1):
		for dx in range(-r, r + 1):
			if not meshed.has(c + Vector2i(dx, dz)):
				return false
	return true


func chunk_progress(pos: Vector3, r: int) -> float:
	var c := Vector2i(floori(pos.x) >> 4, floori(pos.z) >> 4)
	var total := 0
	var ok := 0
	for dz in range(-r, r + 1):
		for dx in range(-r, r + 1):
			total += 1
			if meshed.has(c + Vector2i(dx, dz)):
				ok += 1
	return float(ok) / float(maxi(total, 1))


# ---------------- физика тел ----------------
## Боксы блока в локальных координатах (забор считается по соседям)
func _boxes_of(id: int, x: int, y: int, z: int) -> Array:
	if id == G.FENCE:
		var res := [PackedFloat32Array([0.375, 0.0, 0.375, 0.625, 1.5, 0.625])]
		var ds := [Vector3i(1, 0, 0), Vector3i(-1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1)]
		for k in 4:
			var dv: Vector3i = ds[k]
			var nid := get_block(x + dv.x, y, z + dv.z)
			if nid == G.FENCE or (nid > 0 and G.OPAQUE[nid] == 1):
				if k == 0:
					res.append(PackedFloat32Array([0.625, 0.0, 0.4375, 1.0, 1.5, 0.5625]))
				elif k == 1:
					res.append(PackedFloat32Array([0.0, 0.0, 0.4375, 0.375, 1.5, 0.5625]))
				elif k == 2:
					res.append(PackedFloat32Array([0.4375, 0.0, 0.625, 0.5625, 1.5, 1.0]))
				else:
					res.append(PackedFloat32Array([0.4375, 0.0, 0.0, 0.5625, 1.5, 0.375]))
		return res
	return G.SHAPE_BOXES[id]


func _box_hit(id: int, x: int, y: int, z: int, p: Vector3, hw: float, h: float) -> bool:
	var ax0 := p.x - hw
	var ax1 := p.x + hw
	var az0 := p.z - hw
	var az1 := p.z + hw
	var ay1 := p.y + h
	for bx in _boxes_of(id, x, y, z):
		if x + float(bx[3]) > ax0 + 0.0001 and x + float(bx[0]) < ax1 - 0.0001 and z + float(bx[5]) > az0 + 0.0001 and z + float(bx[2]) < az1 - 0.0001 and y + float(bx[4]) > p.y + 0.0001 and y + float(bx[1]) < ay1 - 0.0001:
			return true
	return false


func body_collides(p: Vector3, hw: float, h: float) -> bool:
	var x0 := floori(p.x - hw)
	var x1 := floori(p.x + hw - 0.0005)
	var y0 := floori(p.y)
	var y1 := floori(p.y + h - 0.0005)
	var z0 := floori(p.z - hw)
	var z1 := floori(p.z + hw - 0.0005)
	for x in range(x0, x1 + 1):
		for z in range(z0, z1 + 1):
			for y in range(y0 - 1, y1 + 1):
				var id := get_block(x, y, z)
				if id < 0:
					return true
				if G.SOLID[id] == 0:
					continue
				if G.SHAPED[id] == 0:
					if y >= y0:
						return true
					continue
				if y < y0 and id != G.FENCE:
					continue
				if _box_hit(id, x, y, z, p, hw, h):
					return true
	return false


## Высота самой верхней опоры под телом (для приземления на плиты/ступени)
func _land_y(p: Vector3, hw: float, h: float, old_y: float) -> float:
	var best := -1000.0
	for x in range(floori(p.x - hw), floori(p.x + hw - 0.0005) + 1):
		for z in range(floori(p.z - hw), floori(p.z + hw - 0.0005) + 1):
			for y in range(floori(p.y) - 1, floori(p.y + h - 0.0005) + 1):
				var id := get_block(x, y, z)
				if id < 0 or G.SOLID[id] == 0:
					continue
				if G.SHAPED[id] == 0:
					best = maxf(best, float(y + 1))
					continue
				for bx in _boxes_of(id, x, y, z):
					if x + float(bx[3]) > p.x - hw + 0.0001 and x + float(bx[0]) < p.x + hw - 0.0001 and z + float(bx[5]) > p.z - hw + 0.0001 and z + float(bx[2]) < p.z + hw - 0.0001:
						var top := y + float(bx[4])
						if top <= old_y + 0.75 and top > p.y - 0.0001:
							best = maxf(best, top)
	return best


func _ceil_y(p: Vector3, hw: float, h: float, old_y: float) -> float:
	var best := 1000.0
	for x in range(floori(p.x - hw), floori(p.x + hw - 0.0005) + 1):
		for z in range(floori(p.z - hw), floori(p.z + hw - 0.0005) + 1):
			for y in range(floori(p.y), floori(p.y + h - 0.0005) + 1):
				var id := get_block(x, y, z)
				if id < 0 or G.SOLID[id] == 0:
					continue
				if G.SHAPED[id] == 0:
					best = minf(best, float(y))
					continue
				for bx in _boxes_of(id, x, y, z):
					if x + float(bx[3]) > p.x - hw + 0.0001 and x + float(bx[0]) < p.x + hw - 0.0001 and z + float(bx[5]) > p.z - hw + 0.0001 and z + float(bx[2]) < p.z + hw - 0.0001:
						var bot := y + float(bx[1])
						if bot >= old_y + h - 0.75:
							best = minf(best, bot)
	return best


## Верхняя точка твёрдого блока в клетке (0 — пусто), для автопрыжка
func solid_top(x: int, y: int, z: int) -> float:
	var id := get_block(x, y, z)
	if id < 0:
		return 1.0
	if G.SOLID[id] == 0:
		return 0.0
	return float(G.TOPH[id])


## Доля тела в воде: 0 — нет, 1 — полностью
func water_level_at(p: Vector3, h: float) -> float:
	var cnt := 0
	var tot := 0
	var y := p.y + 0.1
	while y < p.y + h:
		tot += 1
		if get_block(floori(p.x), floori(y), floori(p.z)) == G.WATER:
			cnt += 1
		y += 0.5
	return float(cnt) / float(maxi(tot, 1))


func move_body(pos: Vector3, vel: Vector3, hw: float, h: float, dt: float) -> Dictionary:
	var p := pos
	var v := vel
	var hit_x := false
	var hit_z := false
	var fastest := maxf(maxf(absf(v.x), absf(v.y)), absf(v.z))
	var steps := maxi(1, ceili(fastest * dt / 0.35))
	var sdt := dt / float(steps)
	for s in steps:
		var ny := p.y + v.y * sdt
		if body_collides(Vector3(p.x, ny, p.z), hw, h):
			if v.y < 0.0:
				var ly := _land_y(Vector3(p.x, ny, p.z), hw, h, p.y)
				if ly > -999.0:
					p.y = ly + 0.001
				else:
					p.y = floorf(ny) + 1.0 + 0.001
			else:
				var cy := _ceil_y(Vector3(p.x, ny, p.z), hw, h, p.y)
				if cy < 999.0:
					p.y = cy - h - 0.001
				else:
					p.y = floorf(ny + h) - h - 0.001
			v.y = 0.0
		else:
			p.y = ny
		var grounded := v.y <= 0.001 and body_collides(Vector3(p.x, p.y - 0.03, p.z), hw, h)
		var nx := p.x + v.x * sdt
		if body_collides(Vector3(nx, p.y, p.z), hw, h):
			var up := _step_up(Vector3(nx, p.y, p.z), hw, h) if grounded else -1.0
			if up >= 0.0:
				p.x = nx
				p.y = up
			else:
				v.x = 0.0
				hit_x = true
		else:
			p.x = nx
		var nz := p.z + v.z * sdt
		if body_collides(Vector3(p.x, p.y, nz), hw, h):
			var up2 := _step_up(Vector3(p.x, p.y, nz), hw, h) if grounded else -1.0
			if up2 >= 0.0:
				p.z = nz
				p.y = up2
			else:
				v.z = 0.0
				hit_z = true
		else:
			p.z = nz
	var on_ground := false
	if v.y <= 0.0 and body_collides(Vector3(p.x, p.y - 0.03, p.z), hw, h):
		on_ground = true
		v.y = 0.0
	return {"pos": p, "vel": v, "on_ground": on_ground, "hit_x": hit_x, "hit_z": hit_z}


## Подъём на ступеньку до 0.6 блока: возвращает новую высоту или -1
func _step_up(np: Vector3, hw: float, h: float) -> float:
	for k in range(1, 7):
		var lift := float(k) * 0.1
		if not body_collides(Vector3(np.x, np.y + lift, np.z), hw, h):
			return np.y + lift
	return -1.0


# ---------------- рейкаст по вокселям ----------------
func raycast(o: Vector3, dir: Vector3, maxd: float) -> Dictionary:
	var x := floori(o.x)
	var y := floori(o.y)
	var z := floori(o.z)
	var sx := 1 if dir.x > 0.0 else -1
	var sy := 1 if dir.y > 0.0 else -1
	var sz := 1 if dir.z > 0.0 else -1
	var tdx: float = INF if absf(dir.x) < 0.000001 else absf(1.0 / dir.x)
	var tdy: float = INF if absf(dir.y) < 0.000001 else absf(1.0 / dir.y)
	var tdz: float = INF if absf(dir.z) < 0.000001 else absf(1.0 / dir.z)
	var tmx: float = INF if absf(dir.x) < 0.000001 else (float(x + (1 if sx > 0 else 0)) - o.x) / dir.x
	var tmy: float = INF if absf(dir.y) < 0.000001 else (float(y + (1 if sy > 0 else 0)) - o.y) / dir.y
	var tmz: float = INF if absf(dir.z) < 0.000001 else (float(z + (1 if sz > 0 else 0)) - o.z) / dir.z
	var t := 0.0
	var normal := Vector3i.ZERO
	while t <= maxd:
		var id := get_block(x, y, z)
		if id > 0 and id != G.WATER:
			return {"pos": Vector3i(x, y, z), "normal": normal, "dist": t, "id": id}
		if tmx < tmy and tmx < tmz:
			x += sx
			t = tmx
			tmx += tdx
			normal = Vector3i(-sx, 0, 0)
		elif tmy < tmz:
			y += sy
			t = tmy
			tmy += tdy
			normal = Vector3i(0, -sy, 0)
		else:
			z += sz
			t = tmz
			tmz += tdz
			normal = Vector3i(0, 0, -sz)
	return {}


# ---------------- статические меши для руки / трещин / дропа ----------------
static func _uvm(um: int, i: float, j: float) -> Vector2:
	if um == 1:
		return Vector2(i, 1.0 - j)
	if um == 2:
		return Vector2(j, 1.0 - i)
	return Vector2(i, j)


static func _cube(tiles: Array, cols: int, rows: int, size: float, shaded: bool, mat: Material) -> ArrayMesh:
	var b := MeshBuf.new()
	for f in 6:
		var o: Vector3 = FACE_ORIGIN[f] - Vector3(0.5, 0.5, 0.5)
		var u: Vector3 = FACE_U[f]
		var v: Vector3 = FACE_V[f]
		var nrm := Vector3(DIRS[f])
		var tile: int = tiles[f]
		var tc := tile % cols
		var tr := tile / cols
		var l: float = FACE_SHADE[f] if shaded else 1.0
		var base := b.v.size()
		for k in 4:
			var ci: float = CI[k]
			var cj: float = CJ[k]
			b.v.push_back((o + u * ci + v * cj) * size)
			b.n.push_back(nrm)
			b.c.push_back(Color(l, l, l, 1.0))
			var uv := _uvm(UV_MODE[f], ci, cj)
			b.t.push_back(Vector2((float(tc) + 0.01 + uv.x * 0.98) / float(cols), (float(tr) + 0.01 + uv.y * 0.98) / float(rows)))
		b.i.append_array(PackedInt32Array([base, base + 1, base + 2, base, base + 2, base + 3]))
	return b.to_mesh(mat)


static func block_cube(id: int, size: float, mat: Material = null) -> ArrayMesh:
	var m: Material = mat if mat != null else G.hand_mat
	var top: int = G.T_TOP[id]
	var bot: int = G.T_BOT[id]
	var side: int = G.T_SIDE[id]
	return _cube([top, bot, side, side, side, side], 16, 16, size, true, m)


static func overlay_cube(stage: int, size: float) -> ArrayMesh:
	var s := clampi(stage, 0, 9)
	return _cube([s, s, s, s, s, s], 10, 1, size, false, G.hand_mat)


static func item_quad(tile: int, size: float, mat: Material = null) -> ArrayMesh:
	var m: Material = mat if mat != null else G.hand_mat
	var b := MeshBuf.new()
	var h := size * 0.5
	var corners := [Vector3(-h, -h, 0), Vector3(h, -h, 0), Vector3(h, h, 0), Vector3(-h, h, 0)]
	var uvs := [Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0)]
	var tc := tile % 16
	var tr := tile / 16
	for k in 4:
		b.v.push_back(corners[k])
		b.n.push_back(Vector3(0, 0, 1))
		b.c.push_back(Color(1, 1, 1, 1))
		var uv: Vector2 = uvs[k]
		b.t.push_back(Vector2((float(tc) + 0.02 + uv.x * 0.96) * 0.0625, (float(tr) + 0.02 + uv.y * 0.96) * 0.0625))
	b.i.append_array(PackedInt32Array([0, 1, 2, 0, 2, 3]))
	return b.to_mesh(m)


## Объёмный предмет (как в Minecraft): плоская картинка с толщиной в 1 пиксель
static var _ext_mat: StandardMaterial3D

static var _model_mat: ShaderMaterial
static var _model_cache := {}

static func model_material() -> ShaderMaterial:
	if _model_mat == null:
		var sh := Shader.new()
		sh.code = """
shader_type spatial;
render_mode unshaded, cull_back, depth_draw_opaque;
uniform vec3 tint = vec3(1.0);
varying vec3 vn;
void vertex() { vn = (MODELVIEW_NORMAL_MATRIX * NORMAL); }
void fragment() {
	vec3 n = normalize(vn);
	float l = 0.5 + 0.5 * max(dot(n, normalize(vec3(-0.35, 0.75, 0.55))), 0.0);
	ALBEDO = COLOR.rgb * l * tint * 1.25;
}
"""
		_model_mat = ShaderMaterial.new()
		_model_mat.shader = sh
	return _model_mat


## Настоящая 3D-модель блока (камень / булыжник), масштабированная под размер
static func model_mesh(id: int, size: float) -> ArrayMesh:
	var key := "%d_%.3f" % [id, size]
	if _model_cache.has(key):
		return _model_cache[key]
	var path := "res://assets/models/stone.res" if id == G.STONE else "res://assets/models/cobble.res"
	var src: ArrayMesh = load(path)
	var arr: Array = src.surface_get_arrays(0)
	var pv: PackedVector3Array = arr[Mesh.ARRAY_VERTEX]
	var out := PackedVector3Array()
	out.resize(pv.size())
	for i in pv.size():
		out[i] = pv[i] * size
	arr[Mesh.ARRAY_VERTEX] = out
	if id == G.COBBLE:
		var cols: PackedColorArray = arr[Mesh.ARRAY_COLOR]
		for i in cols.size():
			cols[i] = Color(cols[i].r * 0.7, cols[i].g * 0.7, cols[i].b * 0.7, 1.0)
		arr[Mesh.ARRAY_COLOR] = cols
	var m := ArrayMesh.new()
	m.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	m.surface_set_material(0, model_material())
	_model_cache[key] = m
	return m


static func ext_material() -> StandardMaterial3D:
	if _ext_mat == null:
		_ext_mat = StandardMaterial3D.new()
		_ext_mat.albedo_texture = G.atlas_tex
		_ext_mat.vertex_color_use_as_albedo = true
		_ext_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
		_ext_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
		_ext_mat.alpha_scissor_threshold = 0.5
		_ext_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		_ext_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	return _ext_mat


static func item_extruded(tile: int, size: float, mat: Material = null) -> ArrayMesh:
	var m: Material = mat if mat != null else ext_material()
	var b := MeshBuf.new()
	var img: Image = G.atlas_img
	var tc := tile % 16
	var tr := tile / 16
	var px := size / 16.0
	var d := px * 1.0
	var op := []
	for y in 16:
		for x in 16:
			op.append(img.get_pixel(tc * 16 + x, tr * 16 + y).a > 0.5)
	var uvp := func(ux: float, uy: float) -> Vector2:
		return Vector2((float(tc) + ux / 16.0) * 0.0625, (float(tr) + uy / 16.0) * 0.0625)
	var quad := func(p: Array, nrm: Vector3, uv: Array) -> void:
		var o := b.v.size()
		for k in 4:
			b.v.push_back(p[k])
			b.n.push_back(nrm)
			b.c.push_back(Color(1, 1, 1, 1))
			b.t.push_back(uv[k])
		b.i.append_array(PackedInt32Array([o, o + 1, o + 2, o, o + 2, o + 3]))
	var x0 := -size * 0.5
	var y0 := size * 0.5
	var hd := d * 0.5
	var uvf := [uvp.call(0.0, 16.0), uvp.call(16.0, 16.0), uvp.call(16.0, 0.0), uvp.call(0.0, 0.0)]
	quad.call([Vector3(x0, y0 - size, hd), Vector3(x0 + size, y0 - size, hd), Vector3(x0 + size, y0, hd), Vector3(x0, y0, hd)], Vector3(0, 0, 1), uvf)
	var uvb := [uvp.call(16.0, 16.0), uvp.call(0.0, 16.0), uvp.call(0.0, 0.0), uvp.call(16.0, 0.0)]
	quad.call([Vector3(x0 + size, y0 - size, -hd), Vector3(x0, y0 - size, -hd), Vector3(x0, y0, -hd), Vector3(x0 + size, y0, -hd)], Vector3(0, 0, -1), uvb)
	for y in 16:
		for x in 16:
			if not op[y * 16 + x]:
				continue
			var cu: Vector2 = uvp.call(x + 0.5, y + 0.5)
			var uvc := [cu, cu, cu, cu]
			var xa := x0 + x * px
			var xb := xa + px
			var ya := y0 - y * px
			var yb := ya - px
			if x == 0 or not op[y * 16 + x - 1]:
				quad.call([Vector3(xa, yb, -hd), Vector3(xa, yb, hd), Vector3(xa, ya, hd), Vector3(xa, ya, -hd)], Vector3(-1, 0, 0), uvc)
			if x == 15 or not op[y * 16 + x + 1]:
				quad.call([Vector3(xb, yb, hd), Vector3(xb, yb, -hd), Vector3(xb, ya, -hd), Vector3(xb, ya, hd)], Vector3(1, 0, 0), uvc)
			if y == 0 or not op[(y - 1) * 16 + x]:
				quad.call([Vector3(xa, ya, hd), Vector3(xb, ya, hd), Vector3(xb, ya, -hd), Vector3(xa, ya, -hd)], Vector3(0, 1, 0), uvc)
			if y == 15 or not op[(y + 1) * 16 + x]:
				quad.call([Vector3(xa, yb, -hd), Vector3(xb, yb, -hd), Vector3(xb, yb, hd), Vector3(xa, yb, hd)], Vector3(0, -1, 0), uvc)
	return b.to_mesh(m)


## Меш для предмета в руке: блок — кубик, растение/предмет — плоская картинка
static func held_mesh(id: int, size: float, mat: Material = null) -> ArrayMesh:
	if G.is_block(id) and not G.is_plant(id):
		return block_cube(id, size, mat if mat != null else ext_material())
	return item_extruded(G.item_tile(id), size, mat)
