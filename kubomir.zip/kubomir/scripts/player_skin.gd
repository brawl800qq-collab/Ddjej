class_name PlayerSkin
extends RefCounted
## Скины в формате майнкрафта (PNG 64x64 или 64x32). По умолчанию рисуется встроенный скин.

const PATH := "user://skin.png"
static var _cache: Image = null
static var version := 0


## Границы граней бокса в раскладке скина: w×h×d с началом (u, v)
static func faces(u: int, v: int, w: int, h: int, d: int) -> Dictionary:
	return {
		"top": Rect2i(u + d, v, w, d),
		"bottom": Rect2i(u + d + w, v, w, d),
		"right": Rect2i(u, v + d, d, h),
		"front": Rect2i(u + d, v + d, w, h),
		"left": Rect2i(u + d + w, v + d, d, h),
		"back": Rect2i(u + 2 * d + w, v + d, w, h),
	}


static func _n(c: Color, rng: RandomNumberGenerator, a := 0.04) -> Color:
	var f := 1.0 + rng.randf_range(-a, a)
	return Color(clampf(c.r * f, 0, 1), clampf(c.g * f, 0, 1), clampf(c.b * f, 0, 1), c.a)


static func _fill(img: Image, r: Rect2i, c: Color, rng: RandomNumberGenerator) -> void:
	for y in range(r.position.y, r.end.y):
		for x in range(r.position.x, r.end.x):
			img.set_pixel(x, y, _n(c, rng))


static func default_image() -> Image:
	var img := Image.create(64, 64, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	var skin := Color(0.84, 0.64, 0.5)
	var hair := Color(0.28, 0.17, 0.09)
	var shirt := Color(0.1, 0.62, 0.68)
	var pants := Color(0.25, 0.27, 0.6)
	var shoe := Color(0.33, 0.33, 0.36)
	# голова
	var hf := faces(0, 0, 8, 8, 8)
	for k in hf:
		_fill(img, hf[k], skin, rng)
	_fill(img, hf["top"], hair, rng)
	_fill(img, hf["back"], hair, rng)
	for k2 in ["right", "left"]:
		var r: Rect2i = hf[k2]
		_fill(img, Rect2i(r.position, Vector2i(r.size.x, 3)), hair, rng)
		_fill(img, Rect2i(r.position + Vector2i(0 if k2 == "left" else r.size.x - 2, 3), Vector2i(2, 3)), hair, rng)
	var fr: Rect2i = hf["front"]
	_fill(img, Rect2i(fr.position, Vector2i(8, 2)), hair, rng)
	for sx in [0, 7]:
		_fill(img, Rect2i(fr.position + Vector2i(sx, 2), Vector2i(1, 1)), hair, rng)
	for ex in [1, 5]:
		img.set_pixel(fr.position.x + ex, fr.position.y + 4, Color(0.97, 0.97, 0.97))
		img.set_pixel(fr.position.x + ex + 1, fr.position.y + 4, Color(0.18, 0.24, 0.7))
	img.set_pixel(fr.position.x + 3, fr.position.y + 5, _n(Color(0.66, 0.46, 0.36), rng))
	img.set_pixel(fr.position.x + 4, fr.position.y + 5, _n(Color(0.66, 0.46, 0.36), rng))
	for mx in range(2, 6):
		img.set_pixel(fr.position.x + mx, fr.position.y + 6, _n(Color(0.58, 0.32, 0.3), rng))
	# тело
	var bf := faces(16, 16, 8, 12, 4)
	for k3 in bf:
		_fill(img, bf[k3], shirt, rng)
	_fill(img, bf["bottom"], Color(0.2, 0.2, 0.24), rng)
	var bfr: Rect2i = bf["front"]
	for bx in range(2, 6):
		img.set_pixel(bfr.position.x + bx, bfr.position.y, _n(skin, rng))
	img.set_pixel(bfr.position.x + 3, bfr.position.y + 1, _n(skin, rng))
	img.set_pixel(bfr.position.x + 4, bfr.position.y + 1, _n(skin, rng))
	# руки (правая 40,16; левая 32,48)
	for org in [Vector2i(40, 16), Vector2i(32, 48)]:
		var af := faces(org.x, org.y, 4, 12, 4)
		for k4 in af:
			_fill(img, af[k4], skin, rng)
		for k5 in ["right", "front", "left", "back"]:
			var ar: Rect2i = af[k5]
			_fill(img, Rect2i(ar.position, Vector2i(ar.size.x, 4)), shirt, rng)
		_fill(img, af["top"], shirt, rng)
	# ноги (правая 0,16; левая 16,48)
	for org2 in [Vector2i(0, 16), Vector2i(16, 48)]:
		var lf := faces(org2.x, org2.y, 4, 12, 4)
		for k6 in lf:
			_fill(img, lf[k6], pants, rng)
		for k7 in ["right", "front", "left", "back"]:
			var lr: Rect2i = lf[k7]
			_fill(img, Rect2i(lr.position + Vector2i(0, 9), Vector2i(lr.size.x, 3)), shoe, rng)
		_fill(img, lf["bottom"], shoe, rng)
	return img


## Приводит старый скин 64x32 к 64x64 (зеркалит левую руку и ногу)
static func normalize(src: Image) -> Image:
	var img := src.duplicate()
	img.convert(Image.FORMAT_RGBA8)
	if img.get_width() != 64:
		img.resize(64, int(round(64.0 * img.get_height() / maxf(img.get_width(), 1.0))), Image.INTERPOLATE_NEAREST)
	if img.get_height() == 32:
		var out := Image.create(64, 64, false, Image.FORMAT_RGBA8)
		out.fill(Color(0, 0, 0, 0))
		out.blit_rect(img, Rect2i(0, 0, 64, 32), Vector2i(0, 0))
		_mirror_part(out, Vector2i(0, 16), Vector2i(16, 48), 4, 12, 4)
		_mirror_part(out, Vector2i(40, 16), Vector2i(32, 48), 4, 12, 4)
		return out
	if img.get_height() != 64:
		img.resize(64, 64, Image.INTERPOLATE_NEAREST)
	return img


static func _mirror_part(img: Image, from: Vector2i, to: Vector2i, w: int, h: int, d: int) -> void:
	var fa := faces(from.x, from.y, w, h, d)
	var ta := faces(to.x, to.y, w, h, d)
	var map := {"top": "top", "bottom": "bottom", "front": "front", "back": "back", "right": "left", "left": "right"}
	for k in map:
		var sr: Rect2i = fa[k]
		var dr: Rect2i = ta[map[k]]
		for y in sr.size.y:
			for x in sr.size.x:
				img.set_pixel(dr.position.x + (sr.size.x - 1 - x), dr.position.y + y, img.get_pixel(sr.position.x + x, sr.position.y + y))


static func current() -> Image:
	if _cache != null:
		return _cache
	if FileAccess.file_exists(PATH):
		var im := Image.new()
		if im.load(PATH) == OK:
			_cache = normalize(im)
			return _cache
	_cache = default_image()
	return _cache


static func is_slim(img: Image) -> bool:
	return img.get_pixel(55, 20).a < 0.1 and img.get_pixel(54, 25).a < 0.1


## Устанавливает скин из файла; возвращает true, если получилось
static func set_from_file(path: String) -> bool:
	var im := Image.new()
	if im.load(path) != OK:
		return false
	if im.get_width() < 32 or im.get_height() < 16:
		return false
	var norm := normalize(im)
	norm.save_png(PATH)
	_cache = norm
	version += 1
	return true


static func reset() -> void:
	if FileAccess.file_exists(PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(PATH))
	_cache = null
	version += 1
