class_name ItemDrop
extends Node3D
## Выпавший предмет: падает, крутится, притягивается к игроку.

var world: World
var player: Player
var id := 0
var count := 1
var vel := Vector3.ZERO
var age := 0.0
var spin := 0.0
var mi: MeshInstance3D
var wear := 0
static var _mesh_cache := {}


static func make(w: World, p: Player, item_id: int, n: int, pos: Vector3, v: Vector3) -> ItemDrop:
	var d := ItemDrop.new()
	d.world = w
	d.player = p
	d.id = item_id
	d.count = n
	d.position = pos
	d.vel = v
	return d


func _ready() -> void:
	mi = MeshInstance3D.new()
	var is_cube := G.is_block(id) and not G.is_plant(id)
	if not _mesh_cache.has(id):
		_mesh_cache[id] = World.held_mesh(id, 0.26 if is_cube else 0.34, G.drop_mat)
	mi.mesh = _mesh_cache[id]
	add_child(mi)
	spin = randf() * TAU


func _process(dt: float) -> void:
	if world == null or player == null:
		return
	dt = minf(dt, 0.05)
	age += dt
	spin += dt * 2.0
	if age > 300.0:
		queue_free()
		return

	var to_p := (player.position + Vector3(0, 0.8, 0)) - position
	var dist := to_p.length()
	if age > 0.35 and dist < 2.6 and not player.dead:
		vel = vel.lerp(to_p.normalized() * 11.0, minf(1.0, 14.0 * dt))
		position += vel * dt
		if dist < 0.7:
			var left := player.add_item(id, count, wear)
			if left < count:
				Sfx.play(player, "pickup", null, -6.0, Sfx.rnd_pitch(0.9, 1.3))
			if left <= 0:
				queue_free()
				return
			count = left
			age = 0.0
	else:
		var in_water := world.get_block(floori(position.x), floori(position.y), floori(position.z)) == G.WATER
		if in_water:
			vel.y = lerpf(vel.y, 1.2, minf(1.0, 4.0 * dt))
			vel.x = lerpf(vel.x, 0.0, minf(1.0, 3.0 * dt))
			vel.z = lerpf(vel.z, 0.0, minf(1.0, 3.0 * dt))
		else:
			vel.y = maxf(vel.y - 22.0 * dt, -30.0)
		var r := world.move_body(position, vel, 0.13, 0.26, dt)
		position = r["pos"]
		vel = r["vel"]
		if r["on_ground"]:
			vel.x = lerpf(vel.x, 0.0, minf(1.0, 10.0 * dt))
			vel.z = lerpf(vel.z, 0.0, minf(1.0, 10.0 * dt))
		if position.y < -10.0:
			queue_free()
			return

	mi.rotation.y = spin
	mi.rotation.x = 0.0
	mi.rotation.z = 0.0
	mi.position.y = 0.2 + sin(age * 2.5) * 0.03
