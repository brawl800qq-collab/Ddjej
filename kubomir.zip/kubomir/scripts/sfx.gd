class_name Sfx
extends RefCounted
## Процедурные звуки (без внешних файлов): шаги, блоки, мобы, дождь, ветер, гром, музыка.

const RATE := 22050
static var _cache := {}
static var _rng := RandomNumberGenerator.new()


static func _to_wav(s: PackedFloat32Array, loop := false) -> AudioStreamWAV:
	var n := s.size()
	var b := PackedByteArray()
	b.resize(n * 2)
	for i in n:
		b.encode_s16(i * 2, clampi(int(s[i] * 30000.0), -32768, 32767))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = b
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = n
	return w


## Универсальный генератор: тон (синус/пила/квадрат) + фильтрованный шум с огибающей
static func gen(dur: float, f0: float, f1: float, tone: float, noise: float, nlp: float, decay: float, wave := 0, vib := 0.0, vdep := 0.0, atk := 0.004) -> PackedFloat32Array:
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	var ph := 0.0
	var lpv := 0.0
	for i in n:
		var t := float(i) / float(n)
		var tt := float(i) / float(RATE)
		var f := lerpf(f0, f1, t) * (1.0 + vdep * sin(TAU * vib * tt))
		ph += f / float(RATE)
		var p1 := ph - floorf(ph)
		var s := 0.0
		if wave == 0:
			s = sin(TAU * p1)
		elif wave == 1:
			s = 2.0 * p1 - 1.0
			s = s * 0.7 + sin(TAU * p1) * 0.3
		else:
			s = 1.0 if p1 < 0.5 else -1.0
		var nz := _rng.randf() * 2.0 - 1.0
		lpv += (nz - lpv) * nlp
		var env := minf(tt / atk, 1.0) * pow(1.0 - t, decay)
		out[i] = (s * tone + lpv * noise) * env
	return out


static func _mix(a: PackedFloat32Array, b: PackedFloat32Array, off: int, gain := 1.0) -> PackedFloat32Array:
	var n := maxi(a.size(), b.size() + off)
	var out := PackedFloat32Array()
	out.resize(n)
	for i in a.size():
		out[i] = a[i]
	for i in b.size():
		out[i + off] += b[i] * gain
	return out


static func _scale(a: PackedFloat32Array, g: float) -> PackedFloat32Array:
	for i in a.size():
		a[i] *= g
	return a


static func _note(f: float) -> PackedFloat32Array:
	var dur := 4.5
	var n := int(dur * RATE)
	var out := PackedFloat32Array()
	out.resize(n)
	for i in n:
		var tt := float(i) / float(RATE)
		var env := minf(tt / 0.03, 1.0) * exp(-tt * 1.15)
		var s := sin(TAU * f * tt) + 0.35 * sin(TAU * f * 2.0 * tt) * exp(-tt * 2.0) + 0.15 * sin(TAU * f * 3.0 * tt) * exp(-tt * 3.0)
		out[i] = s * env * 0.35
	# эхо
	var d1 := int(0.31 * RATE)
	for i in range(d1, n):
		out[i] += out[i - d1] * 0.38
	var d2 := int(0.57 * RATE)
	for i in range(d2, n):
		out[i] += out[i - d2] * 0.22
	return out


static func _make(name: String) -> AudioStreamWAV:
	var s := PackedFloat32Array()
	var loop := false
	match name:
		"step_grass":
			s = gen(0.10, 0, 0, 0, 0.9, 0.22, 2.0, 0, 0, 0, 0.01)
		"step_stone":
			s = _mix(gen(0.07, 0, 0, 0, 0.9, 0.7, 3.0), gen(0.06, 170, 120, 0.5, 0, 0, 3.0), 0)
		"step_wood":
			s = gen(0.09, 150, 105, 0.7, 0.4, 0.35, 3.0)
		"step_sand":
			s = gen(0.13, 0, 0, 0, 0.8, 0.1, 1.5, 0, 0, 0, 0.02)
		"step_gravel":
			s = _mix(gen(0.08, 0, 0, 0, 1.0, 0.5, 1.8), gen(0.07, 0, 0, 0, 0.8, 0.4, 2.0), int(0.05 * RATE))
		"step_snow":
			s = gen(0.11, 0, 0, 0, 0.7, 0.12, 2.2, 0, 0, 0, 0.015)
		"step_water":
			s = gen(0.16, 320, 180, 0.15, 0.7, 0.2, 2.0, 0, 0, 0, 0.02)
		"break_grass":
			s = _mix(gen(0.22, 0, 0, 0, 0.9, 0.2, 2.0, 0, 0, 0, 0.01), gen(0.12, 110, 70, 0.6, 0, 0, 3.0), 0)
		"break_stone":
			s = _mix(gen(0.24, 0, 0, 0, 0.9, 0.6, 2.5), gen(0.18, 190, 85, 0.6, 0, 0, 2.5), 0)
		"break_wood":
			s = _mix(gen(0.2, 210, 120, 0.8, 0.5, 0.4, 2.5, 1), gen(0.14, 0, 0, 0, 0.6, 0.5, 3.0), 0)
		"break_sand":
			s = gen(0.26, 0, 0, 0, 0.9, 0.12, 1.6, 0, 0, 0, 0.02)
		"break_gravel":
			s = _mix(gen(0.2, 0, 0, 0, 1.0, 0.45, 1.8), gen(0.16, 0, 0, 0, 0.9, 0.35, 2.0), int(0.07 * RATE))
		"break_glass":
			s = _mix(gen(0.3, 0, 0, 0, 0.9, 0.95, 2.0), gen(0.25, 2400, 1700, 0.3, 0, 0, 2.5), 0)
		"place":
			s = gen(0.08, 210, 120, 0.85, 0.25, 0.3, 3.0)
		"splash":
			s = _mix(gen(0.5, 0, 0, 0, 0.9, 0.18, 1.6, 0, 0, 0, 0.02), gen(0.35, 260, 120, 0.2, 0, 0, 2.0), 0)
		"hurt":
			s = _mix(gen(0.28, 330, 140, 0.8, 0.2, 0.3, 1.5, 1), gen(0.1, 0, 0, 0, 0.7, 0.5, 3.0), 0)
		"death":
			s = gen(0.7, 260, 70, 0.9, 0.2, 0.2, 1.2, 1)
		"hit":
			s = _mix(gen(0.1, 130, 70, 0.9, 0.4, 0.3, 3.0), gen(0.08, 0, 0, 0, 0.8, 0.6, 3.0), 0)
		"pickup":
			s = gen(0.11, 520, 1250, 0.7, 0.0, 0.0, 1.0)
		"eat":
			s = gen(0.07, 0, 0, 0, 0.9, 0.5, 2.0)
			s = _mix(s, gen(0.07, 0, 0, 0, 0.9, 0.45, 2.0), int(0.13 * RATE))
			s = _mix(s, gen(0.07, 0, 0, 0, 0.9, 0.4, 2.0), int(0.26 * RATE))
		"click":
			s = gen(0.035, 900, 700, 0.6, 0.2, 0.5, 3.0, 2)
		"explode":
			s = _mix(gen(1.3, 0, 0, 0, 1.0, 0.1, 2.2, 0, 0, 0, 0.01), gen(1.3, 70, 28, 0.9, 0, 0, 1.6), 0)
		"fuse":
			s = gen(1.4, 0, 0, 0, 0.7, 0.55, 0.15, 0, 0, 0, 0.1)
		"thunder":
			s = _mix(gen(3.6, 0, 0, 0, 1.0, 0.045, 1.1, 0, 0, 0, 0.25), gen(3.0, 48, 30, 0.7, 0, 0, 1.0, 0, 7.0, 0.1, 0.1), 0, 0.8)
		"rain":
			loop = true
			s = gen(2.0, 0, 0, 0, 0.55, 0.55, 0.0, 0, 0, 0, 0.001)
			for i in s.size():
				s[i] = s[i] * (0.8 + 0.2 * sin(TAU * 2.0 * float(i) / float(s.size())))
		"wind":
			loop = true
			s = gen(4.0, 0, 0, 0, 1.0, 0.035, 0.0, 0, 0, 0, 0.001)
			for i in s.size():
				var tt := float(i) / float(s.size())
				s[i] = s[i] * (0.55 + 0.45 * sin(TAU * tt) * sin(TAU * 2.0 * tt + 1.0))
		"pig":
			s = _mix(gen(0.14, 170, 140, 0.9, 0.15, 0.2, 1.0, 1), gen(0.2, 150, 100, 0.9, 0.15, 0.2, 1.2, 1), int(0.16 * RATE))
		"cow":
			s = gen(0.95, 115, 88, 0.9, 0.1, 0.3, 0.7, 1, 5.0, 0.04, 0.06)
		"sheep":
			s = gen(0.6, 340, 290, 0.8, 0.1, 0.3, 0.8, 1, 13.0, 0.1, 0.03)
		"chicken":
			s = _mix(gen(0.11, 950, 720, 0.7, 0.2, 0.4, 1.5, 2), gen(0.1, 900, 700, 0.7, 0.2, 0.4, 1.5, 2), int(0.14 * RATE))
		"zombie":
			s = gen(1.0, 100, 66, 0.9, 0.3, 0.2, 0.8, 1, 3.0, 0.06, 0.08)
		"creeper":
			s = gen(0.5, 0, 0, 0, 0.8, 0.5, 1.0, 0, 0, 0, 0.02)
		"skeleton":
			s = gen(0.04, 1500, 900, 0.4, 0.8, 0.8, 3.0, 2)
			s = _mix(s, gen(0.04, 1400, 800, 0.4, 0.8, 0.8, 3.0, 2), int(0.09 * RATE))
			s = _mix(s, gen(0.04, 1600, 950, 0.4, 0.8, 0.8, 3.0, 2), int(0.19 * RATE))
		"spider":
			s = _mix(gen(0.4, 0, 0, 0, 0.9, 0.6, 0.9, 0, 0, 0, 0.03), gen(0.3, 2200, 1600, 0.2, 0, 0, 1.5, 2), 0)
		"bat":
			s = _mix(gen(0.14, 3600, 5400, 0.7, 0, 0, 1.0), gen(0.12, 3800, 5600, 0.7, 0, 0, 1.0), int(0.17 * RATE))
		"arrow":
			s = _mix(gen(0.2, 900, 280, 0.7, 0.3, 0.5, 2.5, 1), gen(0.12, 0, 0, 0, 0.5, 0.7, 3.0), 0)
		_:
			s = gen(0.05, 400, 400, 0.5, 0.2, 0.4, 3.0)
	return _to_wav(s, loop)


static func stream(name: String) -> AudioStreamWAV:
	if _cache.has(name):
		return _cache[name]
	var w: AudioStreamWAV
	if name.begins_with("note_"):
		var f := float(name.substr(5))
		w = _to_wav(_note(f))
	else:
		w = _make(name)
	_cache[name] = w
	return w


## Воспроизвести звук. pos — позиция в мире (иначе без привязки к месту).
static func play(from: Node, name: String, pos: Variant = null, vol_db := 0.0, pitch := 1.0) -> void:
	# звуки отключены по просьбе игрока
	return
	if from == null or not from.is_inside_tree() or G.volume <= 0.01:
		return
	var root := from.get_tree().root
	if pos is Vector3:
		var p := AudioStreamPlayer3D.new()
		p.stream = stream(name)
		p.volume_db = vol_db
		p.pitch_scale = pitch
		p.unit_size = 9.0
		p.max_distance = 48.0
		root.add_child(p)
		p.global_position = pos
		p.finished.connect(p.queue_free)
		p.play()
	else:
		var q := AudioStreamPlayer.new()
		q.stream = stream(name)
		q.volume_db = vol_db
		q.pitch_scale = pitch
		root.add_child(q)
		q.finished.connect(q.queue_free)
		q.play()


static func rnd_pitch(a := 0.9, b := 1.12) -> float:
	return _rng.randf_range(a, b)


## Тип звука блока: grass / stone / wood / sand / gravel / snow / glass
static func kind_of(id: int) -> String:
	if id in [G.GRASS, G.DIRT, G.LEAVES, G.BIRCH_LEAVES, G.SPRUCE_LEAVES, G.TALL_GRASS, G.RED_FLOWER, G.YELLOW_FLOWER, G.WOOL, G.SEAWEED, G.FLOWER_BLUE, G.FLOWER_WHITE, G.FLOWER_PINK, G.MUD, G.BLOOM_LEAVES]:
		return "grass"
	if id in [G.LOG, G.BIRCH_LOG, G.SPRUCE_LOG, G.PLANKS, G.TABLE, G.BED, G.TORCH, G.CACTUS]:
		return "wood"
	if id == G.SAND:
		return "sand"
	if id == G.GRAVEL:
		return "gravel"
	if id == G.SNOW:
		return "snow"
	if id == G.GLASS or id == G.ICE:
		return "glass"
	return "stone"


static func note_names() -> Array:
	return ["note_261.63", "note_293.66", "note_329.63", "note_392.0", "note_440.0", "note_523.25", "note_587.33", "note_196.0"]
