class_name Shaders
extends RefCounted
## Код шейдеров: блоки (с тенями от рельефа), растения, вода, облака, небо.

const SHADOW_FUNCS := """
uniform sampler2D hmap : filter_nearest, repeat_disable;
uniform vec2 sh_origin = vec2(0.0);
uniform int sh_steps = 12;
uniform int sh_soft = 3;

float sun_shadow1(vec3 o, vec3 sd) {
	for (int i = 1; i <= 16; i++) {
		if (i > sh_steps) {
			break;
		}
		vec3 q = o + sd * (float(i) * 1.35);
		vec2 uv = (q.xz - sh_origin) / 128.0;
		if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) {
			break;
		}
		float h = texture(hmap, uv).r * 255.0;
		if (h + 1.0 > q.y + 0.1) {
			return 0.0;
		}
	}
	return 1.0;
}

// мягкая тень: несколько смещённых проб + смягчение края
float sun_shadow(vec3 p, vec3 n, vec3 sd) {
	if (sh_steps <= 0) {
		return 1.0;
	}
	vec3 o = p + n * 0.15 + sd * 0.35;
	vec3 t1 = normalize(cross(sd, vec3(0.0, 1.0, 0.01)));
	vec3 t2 = cross(sd, t1);
	float r = 0.5;
	float s = sun_shadow1(o + t1 * r, sd);
	if (sh_soft <= 1) {
		return mix(0.12, 1.0, s);
	}
	s += sun_shadow1(o - t1 * r, sd);
	if (sh_soft >= 3) {
		s += sun_shadow1(o + t2 * r, sd);
		s += sun_shadow1(o - t2 * r, sd);
		s *= 0.25;
	} else {
		s *= 0.5;
	}
	return mix(0.12, 1.0, smoothstep(0.0, 1.0, s));
}

float vn2(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float a = fract(sin(dot(i, vec2(127.1, 311.7))) * 43758.5453);
	float b = fract(sin(dot(i + vec2(1.0, 0.0), vec2(127.1, 311.7))) * 43758.5453);
	float c = fract(sin(dot(i + vec2(0.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
	float d = fract(sin(dot(i + vec2(1.0, 1.0), vec2(127.1, 311.7))) * 43758.5453);
	return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float hash13(vec3 p) {
	p = fract(p * 0.1031);
	p += dot(p, p.zyx + 31.32);
	return fract((p.x + p.y) * p.z);
}

vec3 biome_tint(float a) {
	float k = (1.0 - a) * 5.0;
	vec3 tc = vec3(1.0);
	if (k > 0.5) {
		tc = vec3(0.80, 0.90, 0.60);
		if (k > 3.5) {
			tc = vec3(0.84, 0.84, 0.55);
		} else if (k > 2.5) {
			tc = vec3(0.62, 0.68, 0.42);
		} else if (k > 1.5) {
			tc = vec3(0.58, 0.76, 0.50);
		}
	}
	return tc;
}
"""

const LIGHT_UNIFORMS := """
uniform float day = 1.0;
uniform vec3 sun_dir = vec3(0.4, 0.8, 0.3);
uniform vec3 sun_color = vec3(1.0, 0.88, 0.66);
uniform vec3 amb_day = vec3(0.50, 0.55, 0.66);
uniform vec3 amb_night = vec3(0.10, 0.12, 0.24);
uniform vec3 player_pos = vec3(0.0);
uniform float lamp = 0.0;
uniform float wet = 0.0;
uniform float wind_str = 1.0;
uniform vec3 sky_col = vec3(0.6, 0.75, 0.95);
"""


const BUMP := """
	float btc = floor(UV.x * 16.0);
	if (UV.y < 0.0625 && (btc == 3.0 || btc == 9.0)) {
		float hh = dot(t.rgb, vec3(0.33));
		vec3 dpx = dFdx(v_wpos);
		vec3 dpy = dFdy(v_wpos);
		float dhx = dFdx(hh);
		float dhy = dFdy(hh);
		vec3 r1 = cross(dpy, n);
		vec3 r2 = cross(n, dpx);
		float det = dot(dpx, r1);
		vec3 grad = sign(det) * (dhx * r1 + dhy * r2);
		n = normalize(abs(det) * n - 0.06 * grad);
	}
"""


static func terrain(hires: bool) -> String:
	var filt := "filter_linear_mipmap_anisotropic" if hires else "filter_nearest"
	var code := """
shader_type spatial;
render_mode unshaded, cull_back, depth_draw_opaque;

uniform sampler2D atlas : source_color, %FILTER%, repeat_disable;
uniform sampler2D detail : filter_linear_mipmap, repeat_enable;
uniform float detail_amt = 0.0;
uniform float model_r = 14.5;
%LIGHT%
%SHADOW%

varying vec3 v_col;
varying float v_a;
varying vec3 v_nrm;
varying vec3 v_wpos;
varying float v_leaf;

void vertex() {
	v_col = COLOR.rgb;
	v_a = COLOR.a;
	v_nrm = NORMAL;
	vec3 wp0 = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	float tc = floor(UV.x * 16.0);
	float tr = floor(UV.y * 16.0);
	float leaf = float((tr < 0.5 && tc > 6.5 && tc < 7.5) || (tr > 1.5 && tr < 2.5 && tc > 8.5 && tc < 10.5) || (tr > 2.5 && tr < 3.5 && tc > 10.5 && tc < 11.5));
	if (leaf > 0.5) {
		float gust = 0.55 + 0.45 * sin(TIME * 0.6 + wp0.x * 0.15 + wp0.z * 0.12);
		float ph = wp0.x * 0.9 + wp0.z * 0.7 + wp0.y * 0.5;
		VERTEX.x += (sin(TIME * 1.6 + ph) * 0.035 + 0.03 * (wind_str - 1.0)) * gust * (0.6 + 0.4 * wind_str);
		VERTEX.z += cos(TIME * 1.3 + ph * 1.3) * 0.03 * gust * (0.6 + 0.4 * wind_str);
		VERTEX.y += sin(TIME * 2.1 + ph * 1.7) * 0.015 * gust;
		v_a = COLOR.a;
	}
	v_leaf = leaf;
	v_wpos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec4 t = texture(atlas, UV);
	if (t.a < 0.5) {
		discard;
	}
	if (model_r > 0.0 && UV.y < 0.0625) {
		float mtc = floor(UV.x * 16.0);
		if ((mtc == 3.0 || mtc == 9.0) && length(v_wpos - INV_VIEW_MATRIX[3].xyz) < model_r - 0.5) {
			discard;
		}
	}
	vec3 n = normalize(v_nrm);
	vec3 albedo = t.rgb * biome_tint(v_a);
	%BUMP%
	vec3 bp = floor(v_wpos - n * 0.05);
	albedo *= 0.93 + 0.14 * hash13(bp);
	if (detail_amt > 0.0) {
		vec2 uvd = v_wpos.xy;
		if (abs(n.y) > 0.5) {
			uvd = v_wpos.xz;
		} else if (abs(n.x) > 0.5) {
			uvd = v_wpos.zy;
		}
		float d1 = texture(detail, uvd * 0.5).r;
		float d2 = texture(detail, uvd * 2.3 + vec2(0.37)).r;
		albedo *= 1.0 + detail_amt * ((d1 - 0.5) * 0.9 + (d2 - 0.5) * 0.6);
	}
	float puddle = 0.0;
	if (wet > 0.01 && n.y > 0.5 && v_wpos.y > 24.6) {
		float earthy = step(1.3, albedo.r / (albedo.b + 0.02)) + step(1.15, albedo.g / (albedo.b + 0.02));
		if (earthy > 0.0) {
			vec2 pq = v_wpos.xz;
			float pn = vn2(pq * 0.33) * 0.65 + vn2(pq * 0.9 + 7.0) * 0.35;
			float mud = smoothstep(0.38, 0.62, vn2(pq * 0.55 + 3.0)) * wet;
			albedo = mix(albedo * mix(1.0, 0.8, wet), vec3(0.28, 0.2, 0.12), mud * 0.55);
			puddle = smoothstep(0.55, 0.64, pn) * wet;
			albedo = mix(albedo, vec3(0.42, 0.5, 0.58), puddle * 0.55);
		}
	} else if (wet > 0.01 && v_wpos.y > 24.6) {
		albedo *= mix(1.0, 0.82, wet);
	}
	float sky = v_col.g;
	float hemi = 0.70 + 0.30 * n.y;
	vec3 amb = mix(amb_night, amb_day, day) * hemi;
	vec3 light = amb * mix(0.35, 1.0, sky);
	vec3 sd = normalize(sun_dir);
	float diff = max(dot(n, sd), 0.0);
	float sh = 1.0;
	if (diff > 0.0 && day > 0.05 && sky > 0.9) {
		sh = sun_shadow(v_wpos, n, sd);
	}
	light += sun_color * diff * day * sky * sh * 0.46;
	if (v_leaf > 0.5) {
		float tr2 = pow(clamp(dot(-n, sd) * 0.5 + 0.5, 0.0, 1.0), 2.0);
		light += sun_color * vec3(0.55, 0.9, 0.25) * tr2 * day * sky * 0.28;
		light *= 0.93 + 0.07 * sin(TIME * 1.1 + v_wpos.x * 2.3 + v_wpos.z * 1.9 + v_wpos.y * 1.3);
	}
	light += vec3(1.0, 0.72, 0.38) * v_col.b * 1.15;
	float dl = length(v_wpos - player_pos);
	light += vec3(1.0, 0.82, 0.55) * lamp * pow(clamp(1.0 - dl / 12.0, 0.0, 1.0), 2.0) * 0.9;
	light = max(light, vec3(0.045));
	vec3 col = albedo * light * v_col.r * 0.94;
	if (puddle > 0.0) {
		vec3 e = normalize((INV_VIEW_MATRIX * vec4(-VIEW, 0.0)).xyz);
		vec3 rd = vec3(e.x, -e.y, e.z);
		vec2 pq2 = v_wpos.xz * 3.0;
		vec2 rc = floor(pq2);
		float rt = fract(TIME * 0.8 + hash13(vec3(rc, 1.0)));
		float rr = length(fract(pq2) - 0.5);
		float rip = smoothstep(0.06, 0.0, abs(rr - rt * 0.5)) * (1.0 - rt) * step(0.45, hash13(vec3(rc, 7.0))) * smoothstep(0.4, 0.9, wet);
		rd.xz += (fract(pq2) - 0.5) * rip * 1.2;
		rd = normalize(rd);
		vec3 zen = sky_col * vec3(0.5, 0.68, 1.05);
		vec3 refl = mix(sky_col, zen, clamp(rd.y * 1.6, 0.0, 1.0));
		float sdot = max(dot(rd, normalize(sun_dir)), 0.0);
		refl += sun_color * (pow(sdot, 220.0) * 3.0 + pow(sdot, 12.0) * 0.35) * day;
		refl = refl * 1.25 * (0.4 + 0.6 * day) + vec3(0.04, 0.05, 0.07);
		float fres = 0.38 + 0.6 * pow(1.0 - clamp(e.y * -1.0, 0.0, 1.0), 3.0);
		vec3 base = col * 0.95 + vec3(0.05, 0.06, 0.08);
		vec3 pud = mix(base, refl, clamp(fres, 0.0, 0.95));
		pud += vec3(rip * 0.35);
		col = mix(col, pud, puddle);
	}
	ALBEDO = col;
}
"""
	return code.replace("%FILTER%", filt).replace("%LIGHT%", LIGHT_UNIFORMS).replace("%SHADOW%", SHADOW_FUNCS).replace("%BUMP%", "")


static func plant(hires: bool) -> String:
	var filt := "filter_linear_mipmap" if hires else "filter_nearest"
	var code := """
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_opaque;

uniform sampler2D atlas : source_color, %FILTER%, repeat_disable;
%LIGHT%
%SHADOW%

varying vec3 v_col;
varying float v_a;
varying vec3 v_wpos;

void vertex() {
	v_col = COLOR.rgb;
	v_a = COLOR.a;
	vec3 wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	v_wpos = wp;
	float sway = COLOR.b * wind_str;
	float gust = 0.6 + 0.4 * sin(TIME * 0.7 + wp.x * 0.12 + wp.z * 0.1);
	VERTEX.x += sin(TIME * 1.7 + wp.x * 0.8 + wp.z * 0.6) * 0.06 * sway * gust + 0.05 * sway * (wind_str - 1.0);
	VERTEX.z += cos(TIME * 1.4 + wp.z * 0.9 + wp.x * 0.5) * 0.06 * sway * gust;
	vec3 pd = wp - player_pos;
	float pr = length(pd.xz);
	float bend = smoothstep(1.0, 0.15, pr) * step(abs(pd.y + 0.9), 1.6) * clamp(sway * 1.6, 0.0, 1.0);
	vec2 pdir = pd.xz / max(pr, 0.05);
	VERTEX.x += pdir.x * bend * 0.38;
	VERTEX.z += pdir.y * bend * 0.38;
	VERTEX.y -= bend * 0.22;
}

void fragment() {
	vec4 t = texture(atlas, UV);
	if (t.a < 0.5) {
		discard;
	}
	vec3 albedo = t.rgb * biome_tint(v_a);
	albedo *= (0.9 + 0.2 * hash13(floor(v_wpos * 0.5))) * mix(1.0, 0.82, wet);
	if (v_col.r < 1.5) {
		albedo *= mix(0.62, 1.1, v_col.b);
		if (v_col.r > 1.1) {
			albedo *= mix(0.55, 1.1, v_col.b);
		}
	}
	float sky = v_col.g;
	vec3 amb = mix(amb_night, amb_day, day);
	vec3 light = amb * mix(0.35, 1.0, sky);
	vec3 sd = normalize(sun_dir);
	float sh = 1.0;
	if (day > 0.05 && sky > 0.9) {
		sh = sun_shadow(v_wpos + vec3(0.0, 0.3, 0.0), vec3(0.0, 1.0, 0.0), sd);
	}
	light += sun_color * day * sky * sh * 0.34;
	float dl = length(v_wpos - player_pos);
	light += vec3(1.0, 0.82, 0.55) * lamp * pow(clamp(1.0 - dl / 12.0, 0.0, 1.0), 2.0) * 0.9;
	light = max(light, vec3(0.045));
	float em = step(1.5, v_col.r);
	light = mix(light, vec3(1.25), em);
	ALBEDO = albedo * light * 1.06;
}
"""
	return code.replace("%FILTER%", filt).replace("%LIGHT%", LIGHT_UNIFORMS).replace("%SHADOW%", SHADOW_FUNCS)


const WATER := """
shader_type spatial;
render_mode unshaded, cull_disabled, blend_mix;

uniform float day = 1.0;
uniform vec3 sun_dir = vec3(0.4, 0.8, 0.3);
uniform vec3 sky_color = vec3(0.6, 0.75, 0.95);
uniform vec3 deep_color = vec3(0.03, 0.20, 0.42);
uniform vec3 shallow_color = vec3(0.10, 0.50, 0.66);
uniform float waves = 1.0;
uniform int quality : hint_range(0, 2) = 2;

varying vec3 w_pos;
varying vec3 v_col;
varying vec3 v_nrm;

float wave(vec2 p, float t) {
	return sin(p.x * 1.3 + t * 1.6) * 0.5 + sin(p.y * 1.7 - t * 1.2) * 0.5 + sin((p.x + p.y) * 0.9 + t * 0.9) * 0.35;
}

float ripple(vec2 p, float t) {
	return sin(dot(p, vec2(2.3, 1.1)) * 1.9 + t * 1.9) + sin(dot(p, vec2(-1.7, 2.6)) * 1.5 - t * 1.4) + 0.7 * sin(dot(p, vec2(0.9, -3.1)) * 1.3 + t * 2.2);
}

// волны по нескольким направлениям (идея из water_3d.gdshader)
float HW(vec2 p, float t) {
	int cnt = quality >= 2 ? 6 : 3;
	float a = 0.0;
	float amp = 0.32;
	float fr = 0.8;
	for (int i = 0; i < 6; i++) {
		if (i >= cnt) {
			break;
		}
		float an = float(i) * 2.4;
		vec2 d = vec2(cos(an), sin(an));
		a += amp * sin(dot(p, d) * fr + t * (1.0 + 0.35 * float(i)));
		amp *= 0.5;
		fr *= 1.9;
	}
	return a * 0.5;
}

void vertex() {
	vec3 wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
	w_pos = wp;
	v_col = COLOR.rgb;
	v_nrm = NORMAL;
	if (NORMAL.y > 0.5 && quality > 0) {
		VERTEX.y += HW(wp.xz, TIME) * 0.22 * waves;
	}
}

void fragment() {
	float light_amt = mix(0.28, 1.0, day) * mix(0.45, 1.0, v_col.g);
	if (abs(v_nrm.y) < 0.5) {
		// боковые грани воды: водопад
		float col_id = floor(w_pos.x * 3.0 + w_pos.z * 3.0);
		float s = fract(w_pos.y * 0.7 + TIME * 1.8 + sin(col_id * 12.9) * 5.0);
		float streak = smoothstep(0.55, 0.95, s);
		vec3 base = mix(shallow_color, vec3(0.75, 0.9, 1.0), 0.35) * light_amt;
		ALBEDO = mix(base, vec3(1.0) * mix(0.5, 1.0, day), streak * 0.55);
		ALPHA = 0.88;
	} else {
		vec2 p = w_pos.xz;
		float amp = 0.55 + 0.45 * waves;
		vec3 n = vec3(0.0, 1.0, 0.0);
		float h0 = 0.0;
		if (quality > 0) {
			float e = 0.06;
			h0 = HW(p, TIME);
			float gx = HW(p - vec2(e, 0.0), TIME) - HW(p + vec2(e, 0.0), TIME);
			float gz = HW(p - vec2(0.0, e), TIME) - HW(p + vec2(0.0, e), TIME);
			n = normalize(vec3(gx * 2.2, 2.0 * e, gz * 2.2));
			float dd = length(CAMERA_POSITION_WORLD - w_pos);
			n = normalize(mix(n, vec3(0.0, 1.0, 0.0), clamp(dd / 70.0, 0.0, 1.0)));
		}
		vec3 vd = normalize(CAMERA_POSITION_WORLD - w_pos);
		float nv = abs(dot(n, vd));
		float fres = 0.02 + 0.98 * pow(1.0 - clamp(nv, 0.0, 1.0), 4.0);
		vec3 water_col = mix(shallow_color, deep_color, 0.62) * light_amt;
		vec3 rv = reflect(-vd, n);
		vec3 zen = sky_color * vec3(0.55, 0.72, 1.05);
		vec3 refl = mix(sky_color, zen, clamp(rv.y * 1.4, 0.0, 1.0));
		refl *= mix(0.30, 1.0, day);
		float k_refl = clamp(0.14 + fres * 0.85, 0.0, 0.9);
		vec3 col = mix(water_col, refl, k_refl);
		vec3 sd = normalize(sun_dir);
		float sdot = clamp(dot(rv, sd), 0.0, 1.0);
		float glint = pow(sdot, 380.0) * 4.0 + pow(sdot, 40.0) * 0.45 + pow(sdot, 8.0) * 0.04;
		col += vec3(1.0, 0.9, 0.7) * glint * day * (0.4 + 0.4 * amp);
		if (quality >= 2) {
			float nz = fract(sin(dot(floor(p * 14.0), vec2(12.9, 78.2))) * 43758.5);
			float foam = smoothstep(0.30, 0.55, h0 * 2.2) * (0.55 + 0.45 * nz) * 0.7;
			col = mix(col, vec3(0.9, 0.95, 1.0) * mix(0.3, 1.0, day) * light_amt, foam * 0.6);
		}
		ALBEDO = col;
		ALPHA = clamp(0.84 + fres * 0.12, 0.0, 0.96);
	}
}
"""

const CLOUD := """
shader_type spatial;
render_mode unshaded, cull_disabled, depth_draw_never, blend_mix;

uniform float day = 1.0;
uniform vec2 wind = vec2(0.0, 0.0);
uniform float coverage = 0.50;
uniform vec3 cloud_day = vec3(1.0, 1.0, 1.0);
uniform vec3 cloud_night = vec3(0.16, 0.18, 0.28);
uniform float gray = 0.0;

varying vec3 w_pos;

float hash(vec2 p) {
	return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float vnoise(vec2 p) {
	vec2 i = floor(p);
	vec2 f = fract(p);
	f = f * f * (3.0 - 2.0 * f);
	float a = hash(i);
	float b = hash(i + vec2(1.0, 0.0));
	float c = hash(i + vec2(0.0, 1.0));
	float d = hash(i + vec2(1.0, 1.0));
	return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float fbm(vec2 p) {
	float v = 0.0;
	float a = 0.5;
	for (int i = 0; i < 4; i++) {
		v += a * vnoise(p);
		p *= 2.03;
		a *= 0.5;
	}
	return v;
}

void vertex() {
	w_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
	vec2 uv = w_pos.xz * 0.0035 + wind;
	float n = fbm(uv);
	float a = smoothstep(coverage, coverage + 0.16, n);
	float dist = length(w_pos.xz - CAMERA_POSITION_WORLD.xz);
	a *= 1.0 - smoothstep(420.0, 700.0, dist);
	float shade = mix(0.70, 1.0, fbm(uv * 2.6 + vec2(3.7, 1.3)));
	vec3 col = mix(cloud_night, cloud_day, day) * shade;
	col = mix(col, vec3(0.40, 0.42, 0.47) * mix(0.35, 1.0, day) * shade, gray);
	ALBEDO = col;
	ALPHA = a * 0.92;
}
"""

const SKY := """
shader_type sky;

uniform vec3 top_col = vec3(0.28, 0.52, 0.95);
uniform vec3 hor_col = vec3(0.72, 0.84, 0.97);
uniform vec3 sun_dir = vec3(0.0, 1.0, 0.0);
uniform float day = 1.0;
uniform float star_amt = 0.0;

float hash3(vec3 p) {
	return fract(sin(dot(p, vec3(12.9898, 78.233, 37.719))) * 43758.5453);
}

void sky() {
	vec3 dir = normalize(EYEDIR);
	float h = dir.y;
	vec3 col;
	if (h >= 0.0) {
		col = mix(hor_col, top_col, pow(h, 0.45));
	} else {
		col = mix(hor_col, hor_col * 0.55, clamp(-h * 3.0, 0.0, 1.0));
	}
	vec3 sd = normalize(sun_dir);
	float s = max(dot(dir, sd), 0.0);
	float disc = smoothstep(0.9993, 0.9998, s);
	col += vec3(1.0, 0.92, 0.7) * disc * 2.0;
	col += vec3(1.0, 0.75, 0.45) * pow(s, 24.0) * 0.35 * clamp(day + 0.2, 0.0, 1.0);
	float m = max(dot(dir, -sd), 0.0);
	float moon = smoothstep(0.9993, 0.9997, m);
	col += vec3(0.85, 0.9, 1.0) * moon * (1.0 - day);
	if (h > 0.0) {
		vec3 p = floor(dir * 180.0);
		float st = step(0.9975, hash3(p));
		col += vec3(st) * star_amt * smoothstep(0.0, 0.25, h);
	}
	COLOR = col;
}
"""
