class_name BlocksExt
extends RefCounted
## Дополнительные блоки: плиты, ступени, двери, сундук, сено, грядка, пшеница, забор.

# материалы плит: полный блок, название, плитка верх/бок/низ, инструмент, твёрдость
const MATS := [
	{"full": 7, "name": "Доски", "top": 8, "side": 8, "bot": 8, "tool": "axe", "tier": 0, "hard": 2.0},
	{"full": 8, "name": "Булыжник", "top": 9, "side": 9, "bot": 9, "tool": "pickaxe", "tier": 1, "hard": 2.0},
	{"full": 3, "name": "Камень", "top": 3, "side": 3, "bot": 3, "tool": "pickaxe", "tier": 1, "hard": 1.5},
	{"full": 22, "name": "Каменные кирпичи", "top": 39, "side": 39, "bot": 39, "tool": "pickaxe", "tier": 1, "hard": 2.0},
	{"full": 20, "name": "Песчаник", "top": 35, "side": 36, "bot": 35, "tool": "pickaxe", "tier": 0, "hard": 0.8},
]
const STAIR_MATS := [0, 1, 3, 4]


static func _info(name: String, top: int, side: int, bot: int, solid: bool, opaque: bool, hard: float, extra := {}) -> Dictionary:
	var d := {"name": name, "top": top, "side": side, "bottom": bot, "solid": solid, "opaque": opaque, "hard": hard}
	for k in extra:
		d[k] = extra[k]
	return d


static func _box(a: float, b: float, c: float, d: float, e: float, f: float) -> PackedFloat32Array:
	return PackedFloat32Array([a, b, c, d, e, f])


## Заполняет BLOCK_INFO и возвращает массив форм (индекс — id блока)
static func register(info: Dictionary) -> Array:
	var shapes := []
	shapes.resize(128)
	for i in 128:
		shapes[i] = []
	info[53] = _info("Сено", 110, 111, 110, true, true, 0.5)
	info[54] = _info("Сундук", 112, 113, 112, true, false, 2.5, {"tool": "axe"})
	shapes[54] = [_box(0.0625, 0, 0.0625, 0.9375, 0.875, 0.9375)]
	info[55] = _info("Грядка", 115, 116, 2, true, false, 0.6, {"tool": "shovel", "drop": 2})
	shapes[55] = [_box(0, 0, 0, 1, 0.9375, 1)]
	var wheat_names := ["Пшеница (росток)", "Пшеница", "Пшеница (почти)", "Пшеница (спелая)"]
	for i in 4:
		info[56 + i] = _info(wheat_names[i], 117 + i, 117 + i, 117 + i, false, false, 0.0, {"plant": true, "drop": 154 if i < 3 else 153})
	info[60] = _info("Забор", 8, 8, 8, true, false, 2.0, {"tool": "axe"})
	info[61] = _info("Дверь", 121, 121, 121, false, false, 3.0, {"tool": "axe"})
	# двери: id = 62 + верх*4 + открыта*2 + ось
	for top in 2:
		for op in 2:
			for ax in 2:
				var id := 62 + top * 4 + op * 2 + ax
				var t := 122 if top == 1 else 121
				info[id] = _info("Дверь", t, t, t, true, false, 3.0, {"tool": "axe", "drop": 0 if top == 1 else 61})
				var closed := op == 0
				var plane_x := (ax == 0) == closed   # панель вдоль X
				if plane_x:
					shapes[id] = [_box(0, 0, 0, 1, 1, 0.1875)]
				else:
					shapes[id] = [_box(0, 0, 0, 0.1875, 1, 1)]
	# плиты
	for m in MATS.size():
		var mt: Dictionary = MATS[m]
		var base_name: String = "Плита: " + String(mt["name"])
		var ex := {"tool": mt["tool"], "tier": mt["tier"], "drop": 70 + m}
		if int(mt["tier"]) == 0:
			ex.erase("tier")
		info[70 + m] = _info(base_name, mt["top"], mt["side"], mt["bot"], true, false, mt["hard"], ex)
		info[75 + m] = _info(base_name, mt["top"], mt["side"], mt["bot"], true, false, mt["hard"], ex)
		shapes[70 + m] = [_box(0, 0, 0, 1, 0.5, 1)]
		shapes[75 + m] = [_box(0, 0.5, 0, 1, 1, 1)]
	# ступени: 0 — спинка на -Z, 1 — +Z, 2 — -X, 3 — +X
	for si in STAIR_MATS.size():
		var mt2: Dictionary = MATS[STAIR_MATS[si]]
		for f in 4:
			var id2 := 80 + si * 4 + f
			var ex2 := {"tool": mt2["tool"], "tier": mt2["tier"], "drop": 80 + si * 4}
			if int(mt2["tier"]) == 0:
				ex2.erase("tier")
			info[id2] = _info("Ступени: " + String(mt2["name"]), mt2["top"], mt2["side"], mt2["bot"], true, false, mt2["hard"], ex2)
			var up := _box(0, 0.5, 0, 1, 1, 0.5)
			if f == 1:
				up = _box(0, 0.5, 0.5, 1, 1, 1)
			elif f == 2:
				up = _box(0, 0.5, 0, 0.5, 1, 1)
			elif f == 3:
				up = _box(0.5, 0.5, 0, 1, 1, 1)
			shapes[id2] = [_box(0, 0, 0, 1, 0.5, 1), up]
	return shapes
