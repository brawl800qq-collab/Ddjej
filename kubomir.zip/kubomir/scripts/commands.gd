class_name Commands
extends RefCounted
## Команды чата: /help /time /weather /gamemode (/gm, /святое) /tp /give /heal /kill /seed /spawn /clear /fly

const WORDS := {"day": 1000, "noon": 6000, "night": 13000, "midnight": 18000, "sunrise": 23000, "sunset": 12000,
	"день": 1000, "полдень": 6000, "ночь": 13000, "полночь": 18000, "рассвет": 23000, "закат": 12000}
const WEATHER := {"clear": 0, "sun": 0, "ясно": 0, "cloudy": 1, "облачно": 1, "rain": 2, "дождь": 2, "thunder": 3, "storm": 3, "гроза": 3}


static func run(game, text: String) -> Array:
	## возвращает массив строк-ответов
	var parts := text.strip_edges().split(" ", false)
	if parts.is_empty():
		return []
	var cmd: String = parts[0].substr(1).to_lower()
	var a := parts.slice(1)
	var player: Player = game.player
	if cmd == "help" or cmd == "?" or cmd == "помощь":
		return ["/gamemode 0|1 (/святое 1 — творческий)", "/time set день|ночь|полдень|<число>", "/weather ясно|дождь|гроза",
			"/tp x y z   /give <предмет> [кол-во]", "/heal  /kill  /seed  /spawn  /clear  /fly"]
	if not G.opts.get("cheats", true):
		return ["Читы выключены. Включи их в меню паузы."]
	match cmd:
		"gamemode", "gm", "святое", "режим":
			if a.is_empty():
				return ["Режим: " + ("творческий" if G.mode == "creative" else "выживание")]
			var m: String = a[0].to_lower()
			var cr := m in ["1", "c", "creative", "творческий", "креатив"]
			var sv := m in ["0", "s", "survival", "выживание"]
			if not cr and not sv:
				return ["Используй: /святое 1 (творческий) или /святое 0 (выживание)"]
			game.set_game_mode("creative" if cr else "survival")
			return ["Режим: " + ("творческий" if cr else "выживание")]
		"time", "время":
			if a.is_empty():
				return ["Время: %d" % int(fposmod(game.tod * 24000.0, 24000.0))]
			if a[0] == "add" or a[0] == "добавить":
				if a.size() < 2 or not a[1].is_valid_int():
					return ["/time add <число>"]
				game.tod = fposmod(game.tod + float(int(a[1])) / 24000.0, 1.0)
				return ["Время сдвинуто"]
			var v: String = a[a.size() - 1].to_lower()
			if a[0] == "always" or a[0] == "всегда":
				var on: bool = not (v in ["off", "0", "нет"])
				G.set_opt("always_day", on)
				return ["Всегда день: " + ("вкл" if on else "выкл")]
			var ticks := -1
			if WORDS.has(v):
				ticks = WORDS[v]
			elif v.is_valid_int():
				ticks = int(v)
			if ticks < 0:
				return ["/time set день|ночь|полдень|полночь|<число>"]
			game.tod = fposmod(float(ticks) / 24000.0, 1.0)
			return ["Время: %d" % ticks]
		"weather", "погода":
			if a.is_empty() or not WEATHER.has(a[0].to_lower()):
				return ["/weather ясно|облачно|дождь|гроза"]
			game.weather.state = WEATHER[a[0].to_lower()]
			game.weather.timer = 600.0
			return ["Погода изменена"]
		"tp", "телепорт":
			if a.size() < 3:
				return ["/tp x y z"]
			for q in a.slice(0, 3):
				if not q.is_valid_float():
					return ["Координаты — числа"]
			var pos := Vector3(float(a[0]), float(a[1]), float(a[2]))
			pos.y = clampf(pos.y, 1.0, 62.0)
			player.position = pos
			player.vel = Vector3.ZERO
			player.fall_peak = pos.y
			game.world.update_center(pos)
			return ["Телепорт: %d %d %d" % [int(pos.x), int(pos.y), int(pos.z)]]
		"give", "дать":
			if a.is_empty():
				return ["/give <название предмета> [кол-во]"]
			var cnt := 1
			var names: Array = Array(a)
			if names.size() > 1 and String(names[names.size() - 1]).is_valid_int():
				cnt = clampi(int(names.pop_back()), 1, 64 * 9)
			var q := " ".join(names).to_lower()
			var found := -1
			for id in G.CREATIVE_ITEMS:
				var nm := G.item_name(id).to_lower()
				if nm == q:
					found = id
					break
				if found < 0 and nm.contains(q):
					found = id
			if found < 0:
				return ["Нет такого предмета: " + q]
			player.add_item(found, cnt)
			player.inv_changed.emit()
			return ["Выдано: %s ×%d" % [G.item_name(found), cnt]]
		"heal", "лечить":
			player.health = 20.0
			player.food = 20.0
			return ["Здоровье восстановлено"]
		"kill", "убить":
			if G.mode == "creative":
				return ["В творческом режиме нельзя погибнуть"]
			player.hurt(1000.0, true)
			return ["Ой."]
		"seed", "сид":
			return ["Сид: %d" % G.seed_value]
		"spawn", "спавн":
			player.position = game.spawn_point
			player.vel = Vector3.ZERO
			return ["Вы на точке спавна"]
		"clear", "очистить":
			for i in player.inv.size():
				player.inv[i] = [0, 0, 0]
			player.inv_changed.emit()
			return ["Инвентарь очищен"]
		"fly", "полёт":
			if G.mode != "creative":
				return ["Полёт доступен в творческом режиме"]
			player.toggle_fly()
			return ["Полёт: " + ("вкл" if player.flying else "выкл")]
	return ["Неизвестная команда. /help"]
