class_name CreateWorldPage
extends VBoxContainer
## Окно создания мира: название, сид, выживание/творческий, координаты, всегда день, читы.

signal create_world(id: String)
signal cancel

var name_edit: LineEdit
var seed_edit: LineEdit
var mode := "survival"
var opts := {"coords": false, "always_day": false, "cheats": true}
var mode_btns := {}
var opt_btns := {}


func _ready() -> void:
	add_theme_constant_override("separation", 12)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", G.panel_style(Color(0.08, 0.09, 0.12, 0.9), Color(0.5, 0.55, 0.62, 0.9)))
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	add_child(panel)
	var sc := ScrollContainer.new()
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(sc)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 7)
	sc.add_child(v)

	v.add_child(G.make_label("Название мира", 19, Color(0.85, 1.0, 0.7)))
	name_edit = LineEdit.new()
	name_edit.placeholder_text = "Новый мир"
	name_edit.custom_minimum_size = Vector2(0, 44)
	name_edit.add_theme_font_size_override("font_size", 22)
	v.add_child(name_edit)
	v.add_child(G.make_label("Сид (необязательно)", 19, Color(0.85, 1.0, 0.7)))
	seed_edit = LineEdit.new()
	seed_edit.placeholder_text = "случайный"
	seed_edit.custom_minimum_size = Vector2(0, 44)
	seed_edit.add_theme_font_size_override("font_size", 22)
	v.add_child(seed_edit)

	v.add_child(G.make_label("Режим игры", 19, Color(0.85, 1.0, 0.7)))
	var mr := HBoxContainer.new()
	mr.add_theme_constant_override("separation", 12)
	v.add_child(mr)
	for k in [["survival", "Выживание"], ["creative", "Творческий"]]:
		var b := G.make_button(k[1], Vector2(0, 54), 24)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var key: String = k[0]
		b.pressed.connect(func():
			mode = key
			_refresh())
		mr.add_child(b)
		mode_btns[key] = b

	v.add_child(G.make_label("Настройки мира", 19, Color(0.85, 1.0, 0.7)))
	for o in [["coords", "Показывать координаты"], ["always_day", "Всегда день"], ["cheats", "Читы (команды в чате)"]]:
		var ob := G.make_button("", Vector2(0, 46), 20)
		var key2: String = o[0]
		var nm: String = o[1]
		ob.pressed.connect(func():
			opts[key2] = not opts[key2]
			_refresh())
		v.add_child(ob)
		opt_btns[key2] = [ob, nm]

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	add_child(row)
	var cancel_b := G.make_button("Отмена", Vector2(0, 62), 24)
	cancel_b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	cancel_b.pressed.connect(func(): cancel.emit())
	row.add_child(cancel_b)
	var go := G.make_button("Создать мир", Vector2(0, 62), 28, "green")
	go.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	go.size_flags_stretch_ratio = 1.6
	go.pressed.connect(_create)
	row.add_child(go)
	_refresh()


func _refresh() -> void:
	for k in mode_btns:
		var b: Button = mode_btns[k]
		var on: bool = mode == k
		b.add_theme_stylebox_override("normal", G._btn_style("green" if on else "", "normal"))
		b.add_theme_stylebox_override("hover", G._btn_style("green" if on else "", "hover"))
		b.text = ("● " if on else "○ ") + ("Выживание" if k == "survival" else "Творческий")
	for k2 in opt_btns:
		var on2: bool = opts[k2]
		var ob: Button = opt_btns[k2][0]
		ob.text = "%s: %s" % [opt_btns[k2][1], "ВКЛ" if on2 else "выкл"]
		ob.add_theme_stylebox_override("normal", G._btn_style("green" if on2 else "", "normal"))
		ob.add_theme_stylebox_override("hover", G._btn_style("green" if on2 else "", "hover"))


func _create() -> void:
	var nm := name_edit.text.strip_edges()
	if nm == "":
		nm = "Новый мир %d" % (G.list_worlds().size() + 1)
	var txt := seed_edit.text.strip_edges()
	var sd := 0
	if txt == "":
		sd = randi() % 1000000
	elif txt.is_valid_int():
		sd = absi(int(txt)) % 1000000
	else:
		sd = absi(hash(txt)) % 1000000
	create_world.emit(G.create_world(nm, mode, sd, opts.duplicate()))
