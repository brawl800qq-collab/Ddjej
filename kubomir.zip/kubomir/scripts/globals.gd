extends Node
## Глобальные данные: блоки, предметы, броня, рецепты, шейдеры, настройки, миры-сохранения.

signal settings_changed

# ---------- состояние игры ----------
var mode := "survival"       # "survival" | "creative"
var seed_value := 12345
var current_world := ""      # id выбранного мира
var day := 1.0               # 0 = ночь, 1 = день (обновляет Game)

# ---------- настройки (сохраняются) ----------
var render_distance := 5
var max_fps := 60            # 0 = без лимита
var ao := true               # мягкие тени в углах
var waves := true            # волны на воде (выводится из water_q)
var water_q := 1             # 0 плоская, 1 волны, 2 волны+пена
var clouds := true
var fog := false
var msaa := 0                # 0 выкл, 1 = 2x, 2 = 4x
var res_scale := 1.0
var show_fps := false
var real_models := false      # настоящие 3D-модели камня/булыжника рядом с игроком
var grass_level := 0          # 0 авто, 1 выкл, 2 низкая, 3 средняя, 4 высокая, 5 ультра
var auto_blade_n := 18
var auto_blade_chunks := 2
var blade_n := 6              # травинок на блок (3D-трава)
var blade_chunks := 3         # в каких чанках от игрока рисуется 3D-трава/листья
var tex_quality := 1         # 0 классика 16px, 1 = 1K (64px), 2 = 2K (128px)
var shadows := 1             # 0 выкл, 1 низкие, 2 высокие
var glow := true
var volume := 1.0
var music := true
var sens := 1.0
var btn_scale := 1.0
var hud_alpha := 0.85
var scheme := 0              # 0 жесты (как Bedrock), 1 кнопки
var floating_joy := true
var autojump := true
var lefty := false
var auto_tune := true         # авто-настройка под устройство
var leaf_depth := true       # двойной слой листвы (глубина)
var tier_name := ""

# ---------- блоки ----------
const AIR := 0
const GRASS := 1
const DIRT := 2
const STONE := 3
const SAND := 4
const LOG := 5
const LEAVES := 6
const PLANKS := 7
const COBBLE := 8
const WATER := 9
const GLASS := 10
const BEDROCK := 11
const TABLE := 12
const COAL_ORE := 13
const SNOW := 14
const GRAVEL := 15
const IRON_ORE := 16
const GOLD_ORE := 17
const DIAMOND_ORE := 18
const FURNACE := 19
const SANDSTONE := 20
const CACTUS := 21
const STONE_BRICKS := 22
const BIRCH_LOG := 23
const BIRCH_LEAVES := 24
const SPRUCE_LEAVES := 25
const WOOL := 26
const RED_FLOWER := 27
const YELLOW_FLOWER := 28
const TALL_GRASS := 29
const ICE := 30
const SPRUCE_LOG := 31
const TORCH := 32
const SEAWEED := 33
const BED := 34
const FLOWER_BLUE := 35
const FLOWER_WHITE := 36
const FLOWER_PINK := 37
const ANDESITE := 38
const MUD := 39
const MOSSY := 40
const BLOOM_LEAVES := 41
const BED_HEAD := 42
const DEEPSLATE := 43
const COPPER_ORE := 44
const EMERALD_ORE := 45
const REDSTONE_ORE := 46
const D_COAL := 47
const D_IRON := 48
const D_GOLD := 49
const D_DIAMOND := 50
const D_COPPER := 51
const D_REDSTONE := 52
const HAY := 53
const CHEST := 54
const FARMLAND := 55
const WHEAT0 := 56
const FENCE := 60
const DOOR := 61
const DOOR_BASE := 62
const SLAB_BASE := 70
const STAIR_BASE := 80

# ---------- предметы ----------
const STICK := 100
const WOOD_PICK := 101
const STONE_PICK := 105
const MEAT := 109
const COAL := 110
const IRON_INGOT := 111
const GOLD_INGOT := 112
const DIAMOND := 113
const LEATHER := 114
const COOKED_MEAT := 115
const APPLE := 116
const RAW_FISH := 125
const COOKED_FISH := 126
const COPPER_INGOT := 150
const EMERALD := 151
const REDSTONE := 152
const WHEAT := 153
const SEEDS := 154
const BREAD := 155

var BLOCK_INFO := {
	1: {"name": "Трава", "top": 0, "side": 1, "bottom": 2, "solid": true, "opaque": true, "hard": 0.6, "tool": "shovel", "drop": 2},
	2: {"name": "Земля", "top": 2, "side": 2, "bottom": 2, "solid": true, "opaque": true, "hard": 0.5, "tool": "shovel"},
	3: {"name": "Камень", "top": 3, "side": 3, "bottom": 3, "solid": true, "opaque": true, "hard": 1.5, "tool": "pickaxe", "tier": 1, "drop": 8},
	4: {"name": "Песок", "top": 4, "side": 4, "bottom": 4, "solid": true, "opaque": true, "hard": 0.5, "tool": "shovel"},
	5: {"name": "Дубовое бревно", "top": 6, "side": 5, "bottom": 6, "solid": true, "opaque": true, "hard": 2.0, "tool": "axe"},
	6: {"name": "Дубовая листва", "top": 7, "side": 7, "bottom": 7, "solid": true, "opaque": false, "hard": 0.2, "drop": 0},
	7: {"name": "Доски", "top": 8, "side": 8, "bottom": 8, "solid": true, "opaque": true, "hard": 2.0, "tool": "axe"},
	8: {"name": "Булыжник", "top": 9, "side": 9, "bottom": 9, "solid": true, "opaque": true, "hard": 2.0, "tool": "pickaxe", "tier": 1},
	9: {"name": "Вода", "top": 10, "side": 10, "bottom": 10, "solid": false, "opaque": false, "hard": -1.0},
	10: {"name": "Стекло", "top": 11, "side": 11, "bottom": 11, "solid": true, "opaque": false, "hard": 0.3, "drop": 0},
	11: {"name": "Бедрок", "top": 12, "side": 12, "bottom": 12, "solid": true, "opaque": true, "hard": -1.0},
	12: {"name": "Верстак", "top": 13, "side": 14, "bottom": 8, "solid": true, "opaque": true, "hard": 2.5, "tool": "axe"},
	13: {"name": "Угольная руда", "top": 15, "side": 15, "bottom": 15, "solid": true, "opaque": true, "hard": 3.0, "tool": "pickaxe", "tier": 1, "drop": 110},
	14: {"name": "Снежная трава", "top": 16, "side": 17, "bottom": 2, "solid": true, "opaque": true, "hard": 0.6, "tool": "shovel", "drop": 2},
	15: {"name": "Гравий", "top": 18, "side": 18, "bottom": 18, "solid": true, "opaque": true, "hard": 0.6, "tool": "shovel"},
	16: {"name": "Железная руда", "top": 19, "side": 19, "bottom": 19, "solid": true, "opaque": true, "hard": 3.0, "tool": "pickaxe", "tier": 2},
	17: {"name": "Золотая руда", "top": 20, "side": 20, "bottom": 20, "solid": true, "opaque": true, "hard": 3.0, "tool": "pickaxe", "tier": 3},
	18: {"name": "Алмазная руда", "top": 21, "side": 21, "bottom": 21, "solid": true, "opaque": true, "hard": 3.5, "tool": "pickaxe", "tier": 3, "drop": 113},
	19: {"name": "Печь", "top": 23, "side": 22, "bottom": 23, "solid": true, "opaque": true, "hard": 3.0, "tool": "pickaxe", "tier": 1},
	20: {"name": "Песчаник", "top": 35, "side": 36, "bottom": 35, "solid": true, "opaque": true, "hard": 0.8, "tool": "pickaxe"},
	21: {"name": "Кактус", "top": 38, "side": 37, "bottom": 38, "solid": true, "opaque": true, "hard": 0.4},
	22: {"name": "Каменные кирпичи", "top": 39, "side": 39, "bottom": 39, "solid": true, "opaque": true, "hard": 2.0, "tool": "pickaxe", "tier": 1},
	23: {"name": "Берёзовое бревно", "top": 6, "side": 40, "bottom": 6, "solid": true, "opaque": true, "hard": 2.0, "tool": "axe"},
	24: {"name": "Берёзовая листва", "top": 41, "side": 41, "bottom": 41, "solid": true, "opaque": false, "hard": 0.2, "drop": 0},
	25: {"name": "Хвоя", "top": 42, "side": 42, "bottom": 42, "solid": true, "opaque": false, "hard": 0.2, "drop": 0},
	26: {"name": "Шерсть", "top": 43, "side": 43, "bottom": 43, "solid": true, "opaque": true, "hard": 0.8},
	27: {"name": "Мак", "top": 44, "side": 44, "bottom": 44, "solid": false, "opaque": false, "hard": 0.0, "plant": true},
	28: {"name": "Одуванчик", "top": 45, "side": 45, "bottom": 45, "solid": false, "opaque": false, "hard": 0.0, "plant": true},
	29: {"name": "Высокая трава", "top": 46, "side": 46, "bottom": 46, "solid": false, "opaque": false, "hard": 0.0, "plant": true, "drop": 0},
	30: {"name": "Лёд", "top": 47, "side": 47, "bottom": 47, "solid": true, "opaque": false, "hard": 0.5, "drop": 0},
	31: {"name": "Еловое бревно", "top": 6, "side": 48, "bottom": 6, "solid": true, "opaque": true, "hard": 2.0, "tool": "axe"},
	32: {"name": "Факел", "top": 50, "side": 50, "bottom": 50, "solid": false, "opaque": false, "hard": 0.0, "plant": true},
	33: {"name": "Водоросли", "top": 49, "side": 49, "bottom": 49, "solid": false, "opaque": false, "hard": 0.0, "plant": true},
	34: {"name": "Кровать", "top": 60, "side": 52, "bottom": 8, "solid": true, "opaque": false, "hard": 0.4, "low": true},
	35: {"name": "Василёк", "top": 53, "side": 53, "bottom": 53, "solid": false, "opaque": false, "hard": 0.0, "plant": true},
	36: {"name": "Ромашка", "top": 54, "side": 54, "bottom": 54, "solid": false, "opaque": false, "hard": 0.0, "plant": true},
	37: {"name": "Пион", "top": 55, "side": 55, "bottom": 55, "solid": false, "opaque": false, "hard": 0.0, "plant": true},
	38: {"name": "Андезит", "top": 56, "side": 56, "bottom": 56, "solid": true, "opaque": true, "hard": 1.5, "tool": "pickaxe", "tier": 1},
	39: {"name": "Грязь", "top": 57, "side": 57, "bottom": 57, "solid": true, "opaque": true, "hard": 0.5, "tool": "shovel"},
	40: {"name": "Замшелый булыжник", "top": 58, "side": 58, "bottom": 58, "solid": true, "opaque": true, "hard": 2.0, "tool": "pickaxe", "tier": 1},
	41: {"name": "Цветущая листва", "top": 59, "side": 59, "bottom": 59, "solid": true, "opaque": false, "hard": 0.2, "drop": 0},
	42: {"name": "Кровать", "top": 51, "side": 52, "bottom": 8, "solid": true, "opaque": false, "hard": 0.4, "low": true, "drop": 34},
	43: {"name": "Глубинный сланец", "top": 61, "side": 61, "bottom": 61, "solid": true, "opaque": true, "hard": 3.0, "tool": "pickaxe", "tier": 1},
	44: {"name": "Медная руда", "top": 62, "side": 62, "bottom": 62, "solid": true, "opaque": true, "hard": 3.0, "tool": "pickaxe", "tier": 2},
	45: {"name": "Изумрудная руда", "top": 63, "side": 63, "bottom": 63, "solid": true, "opaque": true, "hard": 3.5, "tool": "pickaxe", "tier": 3, "drop": 151},
	46: {"name": "Красная руда", "top": 103, "side": 103, "bottom": 103, "solid": true, "opaque": true, "hard": 3.0, "tool": "pickaxe", "tier": 3, "drop": 152, "n": 4},
	47: {"name": "Глубинная угольная руда", "top": 104, "side": 104, "bottom": 104, "solid": true, "opaque": true, "hard": 4.0, "tool": "pickaxe", "tier": 1, "drop": 110},
	48: {"name": "Глубинная железная руда", "top": 105, "side": 105, "bottom": 105, "solid": true, "opaque": true, "hard": 4.0, "tool": "pickaxe", "tier": 2, "drop": 16},
	49: {"name": "Глубинная золотая руда", "top": 106, "side": 106, "bottom": 106, "solid": true, "opaque": true, "hard": 4.0, "tool": "pickaxe", "tier": 3, "drop": 17},
	50: {"name": "Глубинная алмазная руда", "top": 107, "side": 107, "bottom": 107, "solid": true, "opaque": true, "hard": 4.5, "tool": "pickaxe", "tier": 3, "drop": 113},
	51: {"name": "Глубинная медная руда", "top": 108, "side": 108, "bottom": 108, "solid": true, "opaque": true, "hard": 4.0, "tool": "pickaxe", "tier": 2, "drop": 44},
	52: {"name": "Глубинная красная руда", "top": 109, "side": 109, "bottom": 109, "solid": true, "opaque": true, "hard": 4.0, "tool": "pickaxe", "tier": 3, "drop": 152, "n": 4},
}

var ITEM_INFO := {}
var RECIPES: Array = []
var CREATIVE_ITEMS: Array = []

# Быстрые массивы для генерации мешей (читаются из потоков)
var SOLID := PackedByteArray()
var OPAQUE := PackedByteArray()
var PLANT := PackedByteArray()
var LEAF := PackedByteArray()
var SHAPED := PackedByteArray()
var TOPH := PackedFloat32Array()
var SHAPE_BOXES: Array = []
var LOW := PackedByteArray()
var TINT := PackedByteArray()
var T_TOP := PackedInt32Array()
var T_SIDE := PackedInt32Array()
var T_BOT := PackedInt32Array()

# ---------- ресурсы ----------
var atlas_img: Image
var atlas_tex: ImageTexture
var terrain_tex: ImageTexture
var detail_tex: ImageTexture
var _last_tq := -1
var crack_tex: ImageTexture
var terrain_mat: ShaderMaterial
var plant_mat: ShaderMaterial
var water_mat: ShaderMaterial
var cloud_mat: ShaderMaterial
var sky_mat: ShaderMaterial
var hand_mat: StandardMaterial3D
var drop_mat: StandardMaterial3D
var _icons := {}
var _noise_cache := {}
var _heart := []
var _food := []
var _shield := []
var _bubble: ImageTexture

const HEART_SHAPE := ["..##.##..", ".#######.", "#########", "#########", ".#######.", "..#####..", "...###...", "....#...."]


func _ready() -> void:
	SOLID.resize(128)
	OPAQUE.resize(128)
	PLANT.resize(128)
	LOW.resize(128)
	LEAF.resize(128)
	for lid in [6, 24, 25, 41]:
		LEAF[lid] = 1
	SHAPE_BOXES = BlocksExt.register(BLOCK_INFO)
	SHAPED.resize(128)
	TOPH.resize(128)
	for sid in 128:
		var bxs: Array = SHAPE_BOXES[sid]
		if bxs.size() > 0:
			SHAPED[sid] = 1
			var mh := 0.0
			for bx in bxs:
				mh = maxf(mh, float(bx[4]))
			TOPH[sid] = mh
		elif sid == 60:
			SHAPED[sid] = 1
			TOPH[sid] = 1.5
		else:
			TOPH[sid] = 1.0
	TINT.resize(128)
	TINT[GRASS] = 1
	TINT[LEAVES] = 1
	TINT[TALL_GRASS] = 1
	T_TOP.resize(128)
	T_SIDE.resize(128)
	T_BOT.resize(128)
	for id in BLOCK_INFO:
		var b = BLOCK_INFO[id]
		SOLID[id] = 1 if b["solid"] else 0
		OPAQUE[id] = 1 if b["opaque"] else 0
		PLANT[id] = 1 if b.get("plant", false) else 0
		LOW[id] = 1 if b.get("low", false) else 0
		T_TOP[id] = b["top"]
		T_SIDE[id] = b["side"]
		T_BOT[id] = b["bottom"]
	_build_items()
	_build_recipes()

	load_settings()
	atlas_img = Atlas.build()
	atlas_tex = ImageTexture.create_from_image(atlas_img)
	terrain_tex = ImageTexture.new()
	detail_tex = _make_detail_tex()
	crack_tex = ImageTexture.create_from_image(Atlas.build_cracks())
	_build_materials()
	rebuild_terrain_texture()

	for s in 3:
		_heart.append(ImageTexture.create_from_image(Atlas.build_heart(s)))
		_food.append(ImageTexture.create_from_image(Atlas.build_food(s)))
		_shield.append(ImageTexture.create_from_image(Atlas.build_shield(s)))
	_bubble = ImageTexture.create_from_image(Atlas.build_bubble())
	load_settings()
	apply_runtime()


# =====================================================================
#  ПРЕДМЕТЫ / РЕЦЕПТЫ
# =====================================================================
func _build_items() -> void:
	ITEM_INFO[100] = {"name": "Палка", "tile": 24}
	ITEM_INFO[109] = {"name": "Сырое мясо", "tile": 33, "food": 3}
	ITEM_INFO[110] = {"name": "Уголь", "tile": 34}
	ITEM_INFO[111] = {"name": "Железный слиток", "tile": 64}
	ITEM_INFO[112] = {"name": "Золотой слиток", "tile": 65}
	ITEM_INFO[113] = {"name": "Алмаз", "tile": 66}
	ITEM_INFO[114] = {"name": "Кожа", "tile": 67}
	ITEM_INFO[115] = {"name": "Жареное мясо", "tile": 68, "food": 8}
	ITEM_INFO[116] = {"name": "Яблоко", "tile": 69, "food": 4}
	ITEM_INFO[125] = {"name": "Сырая рыба", "tile": 93, "food": 2}
	ITEM_INFO[126] = {"name": "Жареная рыба", "tile": 94, "food": 6}
	ITEM_INFO[150] = {"name": "Медный слиток", "tile": 100}
	ITEM_INFO[151] = {"name": "Изумруд", "tile": 101}
	ITEM_INFO[152] = {"name": "Красная пыль", "tile": 102}
	ITEM_INFO[153] = {"name": "Пшеница", "tile": 125}
	ITEM_INFO[154] = {"name": "Семена", "tile": 126}
	ITEM_INFO[155] = {"name": "Хлеб", "tile": 124, "food": 5}

	var kinds := ["pickaxe", "axe", "shovel", "sword"]
	var knames := ["кирка", "топор", "лопата", "меч"]
	var tiers := [
		{"adj": ["Деревянная", "Деревянный", "Деревянная", "Деревянный"], "tier": 1, "tile": 25, "id": 101, "dmg": [2, 3, 2, 4]},
		{"adj": ["Каменная", "Каменный", "Каменная", "Каменный"], "tier": 2, "tile": 29, "id": 105, "dmg": [3, 4, 3, 5]},
		{"adj": ["Железная", "Железный", "Железная", "Железный"], "tier": 3, "tile": 72, "id": 117, "dmg": [4, 5, 4, 6]},
		{"adj": ["Алмазная", "Алмазный", "Алмазная", "Алмазный"], "tier": 4, "tile": 76, "id": 121, "dmg": [5, 6, 5, 7]},
	]
	for t in tiers:
		for i in 4:
			ITEM_INFO[t["id"] + i] = {"name": "%s %s" % [t["adj"][i], knames[i]], "tile": t["tile"] + i, "tool": kinds[i], "tier": t["tier"], "dmg": t["dmg"][i]}

	var anames := [
		["Кожаный шлем", "Кожаный нагрудник", "Кожаные поножи", "Кожаные ботинки"],
		["Железный шлем", "Железный нагрудник", "Железные поножи", "Железные ботинки"],
		["Алмазный шлем", "Алмазный нагрудник", "Алмазные поножи", "Алмазные ботинки"],
	]
	var adef := [[1, 3, 2, 1], [2, 5, 3, 1], [3, 8, 6, 3]]
	var acol := [Color(0.55, 0.36, 0.22), Color(0.85, 0.85, 0.88), Color(0.35, 0.92, 0.92)]
	for a in 3:
		for i in 4:
			ITEM_INFO[130 + a * 4 + i] = {"name": anames[a][i], "tile": 80 + a * 4 + i, "armor": i, "def": adef[a][i], "col": acol[a], "atier": a}

	CREATIVE_ITEMS = [1, 2, 3, 4, 15, 5, 23, 31, 6, 24, 25, 7, 8, 22, 20, 26, 10, 12, 19, 13, 16, 17, 18, 21, 27, 28, 29, 30, 14, 32, 34, 33, 35, 36, 37, 38, 39, 40, 41, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 60, 61, 70, 71, 72, 73, 74, 80, 84, 88, 92]
	var itm := ITEM_INFO.keys()
	itm.sort()
	for k in itm:
		CREATIVE_ITEMS.append(k)


func _build_recipes() -> void:
	# st: 0 без станции, 1 верстак, 2 печь
	RECIPES = [
		{"out": 7, "n": 4, "in": {5: 1}, "st": 0},
		{"out": 7, "n": 4, "in": {23: 1}, "st": 0},
		{"out": 7, "n": 4, "in": {31: 1}, "st": 0},
		{"out": 100, "n": 4, "in": {7: 2}, "st": 0},
		{"out": 12, "n": 1, "in": {7: 4}, "st": 0},
		{"out": 19, "n": 1, "in": {8: 8}, "st": 1},
		{"out": 22, "n": 4, "in": {3: 4}, "st": 1},
		{"out": 20, "n": 1, "in": {4: 4}, "st": 0},
		# печь
		{"out": 111, "n": 1, "in": {16: 1, 110: 1}, "st": 2},
		{"out": 112, "n": 1, "in": {17: 1, 110: 1}, "st": 2},
		{"out": 150, "n": 1, "in": {44: 1, 110: 1}, "st": 2},
		{"out": 70, "n": 6, "in": {7: 3}, "st": 1},
		{"out": 71, "n": 6, "in": {8: 3}, "st": 1},
		{"out": 72, "n": 6, "in": {3: 3}, "st": 1},
		{"out": 73, "n": 6, "in": {22: 3}, "st": 1},
		{"out": 74, "n": 6, "in": {20: 3}, "st": 1},
		{"out": 80, "n": 4, "in": {7: 6}, "st": 1},
		{"out": 84, "n": 4, "in": {8: 6}, "st": 1},
		{"out": 88, "n": 4, "in": {22: 6}, "st": 1},
		{"out": 92, "n": 4, "in": {20: 6}, "st": 1},
		{"out": 61, "n": 3, "in": {7: 6}, "st": 1},
		{"out": 60, "n": 3, "in": {7: 4, 100: 2}, "st": 1},
		{"out": 54, "n": 1, "in": {7: 8}, "st": 1},
		{"out": 155, "n": 1, "in": {153: 3}, "st": 0},
		{"out": 53, "n": 1, "in": {153: 9}, "st": 0},
		{"out": 115, "n": 1, "in": {109: 1, 110: 1}, "st": 2},
		{"out": 3, "n": 1, "in": {8: 1, 110: 1}, "st": 2},
		{"out": 10, "n": 1, "in": {4: 1, 110: 1}, "st": 2},
		{"out": 126, "n": 1, "in": {125: 1, 110: 1}, "st": 2},
		{"out": 32, "n": 4, "in": {110: 1, 100: 1}, "st": 0},
		{"out": 34, "n": 1, "in": {26: 3, 7: 3}, "st": 1},
	]
	var mats := [7, 8, 111, 113]
	var base_ids := [101, 105, 117, 121]
	var cost := [[3, 2], [3, 2], [1, 2], [2, 1]]  # (материал, палки): кирка, топор, лопата, меч
	var kind_order := [0, 1, 2, 3]
	for t in 4:
		for k in kind_order:
			var c: Array = cost[k]
			RECIPES.append({"out": base_ids[t] + k, "n": 1, "in": {mats[t]: c[0], 100: c[1]}, "st": 1})
	# кирка и топор одинаково, но cost[1] должен быть как у кирки (3+2)
	var amats := [114, 111, 113]
	var acount := [5, 8, 7, 4]
	for a in 3:
		for i in 4:
			RECIPES.append({"out": 130 + a * 4 + i, "n": 1, "in": {amats[a]: acount[i]}, "st": 1})


func is_block(id: int) -> bool:
	return id > 0 and id < 100


func is_plant(id: int) -> bool:
	return id > 0 and id < 128 and PLANT[id] == 1


func is_solid_id(id: int) -> bool:
	if id < 0:
		return true
	return SOLID[id] == 1


func item_name(id: int) -> String:
	if BLOCK_INFO.has(id):
		return BLOCK_INFO[id]["name"]
	if ITEM_INFO.has(id):
		return ITEM_INFO[id]["name"]
	return "?"


func item_tile(id: int) -> int:
	if BLOCK_INFO.has(id):
		return BLOCK_INFO[id]["side"]
	if ITEM_INFO.has(id):
		return ITEM_INFO[id]["tile"]
	return 0


func icon(id: int) -> Texture2D:
	if _icons.has(id):
		return _icons[id]
	var t := item_tile(id)
	var at := AtlasTexture.new()
	at.atlas = atlas_tex
	at.region = Rect2((t % Atlas.COLS) * 16, (t / Atlas.COLS) * 16, 16, 16)
	_icons[id] = at
	return at


func heart_tex(state: int) -> Texture2D:
	return _heart[state]


func food_tex(state: int) -> Texture2D:
	return _food[state]


func shield_tex(state: int) -> Texture2D:
	return _shield[state]


func bubble_tex() -> Texture2D:
	return _bubble


func held_info(id: int) -> Dictionary:
	if ITEM_INFO.has(id):
		return ITEM_INFO[id]
	return {}


func armor_slot(id: int) -> int:
	var hi := held_info(id)
	return int(hi.get("armor", -1))


func armor_points(id: int) -> int:
	var hi := held_info(id)
	return int(hi.get("def", 0))


func break_time(block: int, held: int) -> float:
	var info = BLOCK_INFO[block]
	var hard: float = info["hard"]
	if hard < 0.0:
		return -1.0
	if mode == "creative":
		return 0.0 if hard == 0.0 else 0.15
	if hard == 0.0:
		return 0.0
	var tool_type: String = info.get("tool", "")
	var req := int(info.get("tier", 0))
	var hi := held_info(held)
	var right: bool = tool_type != "" and hi.get("tool", "") == tool_type
	var tier := int(hi.get("tier", 0)) if right else 0
	if req > tier:
		return hard * 5.0
	var speed := 1.0
	if right:
		speed = [1.0, 2.0, 4.0, 6.0, 8.0][clampi(tier, 0, 4)]
	return hard * 1.5 / speed


func drop_for(block: int, held: int) -> int:
	var info = BLOCK_INFO[block]
	var req := int(info.get("tier", 0))
	if req > 0:
		var hi := held_info(held)
		var tier := 0
		if hi.get("tool", "") == info.get("tool", ""):
			tier = int(hi.get("tier", 0))
		if tier < req:
			return 0
	return int(info.get("drop", block))


func item_damage(id: int) -> float:
	if mode == "creative":
		return 100.0
	var hi := held_info(id)
	return float(hi.get("dmg", 1))


## Небольшая шумная текстура для моделей животных
func noise_tex(c: Color) -> Texture2D:
	var key := c.to_html()
	if _noise_cache.has(key):
		return _noise_cache[key]
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(key)
	var img := Image.create(8, 8, false, Image.FORMAT_RGBA8)
	for y in 8:
		for x in 8:
			var f := 1.0 + rng.randf_range(-0.09, 0.09)
			img.set_pixel(x, y, Color(clampf(c.r * f, 0, 1), clampf(c.g * f, 0, 1), clampf(c.b * f, 0, 1), 1.0))
	var tex := ImageTexture.create_from_image(img)
	_noise_cache[key] = tex
	return tex


func _make_heart(state: int) -> ImageTexture:
	var img := Image.create(9, 9, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in 8:
		var row: String = HEART_SHAPE[y]
		for x in 9:
			if row[x] == "#":
				var c := Color(0.15, 0.05, 0.05, 0.8)
				if state == 2 or (state == 1 and x < 5):
					c = Color(0.92, 0.12, 0.12)
					if x == 2 and y == 1:
						c = Color(1.0, 0.7, 0.7)
				img.set_pixel(x, y, c)
	return ImageTexture.create_from_image(img)


func _make_food(state: int) -> ImageTexture:
	var img := Image.create(9, 9, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in 9:
		for x in 9:
			if Vector2(x - 5.0, y - 3.5).length() < 3.7:
				var c := Color(0.15, 0.08, 0.04, 0.8)
				if state == 2 or (state == 1 and x < 5):
					c = Color(0.78, 0.45, 0.18)
					if x == 4 and y == 2:
						c = Color(0.95, 0.7, 0.4)
				img.set_pixel(x, y, c)
	var bone := Color(0.95, 0.95, 0.9) if state > 0 else Color(0.3, 0.3, 0.3, 0.8)
	for p in [[0, 8], [1, 7], [2, 6], [0, 7], [1, 8], [3, 5]]:
		img.set_pixel(p[0], p[1], bone)
	return ImageTexture.create_from_image(img)


# =====================================================================
#  ШЕЙДЕРЫ И МАТЕРИАЛЫ
# =====================================================================

func _make_detail_tex() -> ImageTexture:
	var n := FastNoiseLite.new()
	n.seed = 99
	n.frequency = 0.045
	n.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	n.fractal_type = FastNoiseLite.FRACTAL_FBM
	n.fractal_octaves = 3
	var img: Image = n.get_seamless_image(128, 128)
	img.generate_mipmaps()
	return ImageTexture.create_from_image(img)


## Пересобирает атлас блоков под выбранное качество (0 — 16px, 1 — 1K, 2 — 2K)
func rebuild_terrain_texture() -> void:
	if tex_quality <= 0:
		terrain_tex.set_image(atlas_img)
	else:
		var sc := 4 if tex_quality == 1 else 8
		terrain_tex.set_image(Atlas.build_hires(atlas_img, sc))
	if terrain_mat:
		terrain_mat.shader.code = Shaders.terrain(tex_quality > 0)
		plant_mat.shader.code = Shaders.plant(tex_quality > 0)
	_last_tq = tex_quality
	apply_shader_settings()


func apply_shader_settings() -> void:
	if terrain_mat == null:
		return
	var steps: int = [0, 7, 12][clampi(shadows, 0, 2)]
	var soft: int = [1, 2, 4][clampi(shadows, 0, 2)]
	for m in [terrain_mat, plant_mat]:
		m.set_shader_parameter("sh_steps", steps)
		m.set_shader_parameter("sh_soft", soft)
	terrain_mat.set_shader_parameter("model_r", 14.5 if real_models else 0.0)
	World.inst_material().set_shader_parameter("model_r", 14.5)
	terrain_mat.set_shader_parameter("detail_amt", 0.0 if tex_quality == 0 else 0.45)


func set_shadow_map(tex: Texture2D, origin: Vector2) -> void:
	for m in [terrain_mat, plant_mat]:
		m.set_shader_parameter("hmap", tex)
		m.set_shader_parameter("sh_origin", origin)


func _shader_mat(code: String) -> ShaderMaterial:
	var sh := Shader.new()
	sh.code = code
	var m := ShaderMaterial.new()
	m.shader = sh
	return m


func _build_materials() -> void:
	terrain_mat = _shader_mat(Shaders.terrain(tex_quality > 0))
	terrain_mat.set_shader_parameter("atlas", terrain_tex)
	terrain_mat.set_shader_parameter("detail", detail_tex)
	plant_mat = _shader_mat(Shaders.plant(tex_quality > 0))
	plant_mat.set_shader_parameter("atlas", terrain_tex)
	water_mat = _shader_mat(Shaders.WATER)
	cloud_mat = _shader_mat(Shaders.CLOUD)
	sky_mat = _shader_mat(Shaders.SKY)

	hand_mat = StandardMaterial3D.new()
	hand_mat.albedo_texture = atlas_tex
	hand_mat.vertex_color_use_as_albedo = true
	hand_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	hand_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	hand_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	hand_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	hand_mat.no_depth_test = true
	hand_mat.render_priority = 10

	drop_mat = StandardMaterial3D.new()
	drop_mat.albedo_texture = atlas_tex
	drop_mat.vertex_color_use_as_albedo = true
	drop_mat.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	drop_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	drop_mat.alpha_scissor_threshold = 0.5
	drop_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	drop_mat.cull_mode = BaseMaterial3D.CULL_DISABLED


## Обновление параметров освещения/неба во всех шейдерах (вызывает Game каждый кадр)
func set_light(d: float, sun: Vector3, sun_col: Color, amb_d: Color, amb_n: Color, top: Color, hor: Color, stars: float) -> void:
	for m in [terrain_mat, plant_mat]:
		m.set_shader_parameter("sky_col", Vector3(hor.r, hor.g, hor.b))
		m.set_shader_parameter("day", d)
		m.set_shader_parameter("sun_dir", sun)
		m.set_shader_parameter("sun_color", Vector3(sun_col.r, sun_col.g, sun_col.b))
		m.set_shader_parameter("amb_day", Vector3(amb_d.r, amb_d.g, amb_d.b))
		m.set_shader_parameter("amb_night", Vector3(amb_n.r, amb_n.g, amb_n.b))
	water_mat.set_shader_parameter("day", d)
	World.inst_material().set_shader_parameter("day", d)
	water_mat.set_shader_parameter("sun_dir", sun)
	water_mat.set_shader_parameter("sky_color", Vector3(hor.r, hor.g, hor.b))
	cloud_mat.set_shader_parameter("day", d)
	sky_mat.set_shader_parameter("day", d)
	sky_mat.set_shader_parameter("sun_dir", sun)
	sky_mat.set_shader_parameter("top_col", Vector3(top.r, top.g, top.b))
	sky_mat.set_shader_parameter("hor_col", Vector3(hor.r, hor.g, hor.b))
	sky_mat.set_shader_parameter("star_amt", stars)


func set_weather(wet: float, wind: float, overcast: float) -> void:
	for m in [terrain_mat, plant_mat]:
		m.set_shader_parameter("wet", wet)
		m.set_shader_parameter("wind_str", wind)
	cloud_mat.set_shader_parameter("coverage", lerpf(0.5, 0.08, overcast))
	cloud_mat.set_shader_parameter("gray", overcast)


## Максимальная прочность инструмента или брони (0 — не изнашивается)
func max_dur(id: int) -> int:
	var hi := held_info(id)
	if hi.has("tool"):
		return [0, 60, 132, 251, 1562][clampi(int(hi.get("tier", 1)), 0, 4)]
	if hi.has("armor"):
		var base: Array = [[55, 80, 75, 65], [165, 240, 225, 195], [363, 528, 495, 429]][clampi(int(hi.get("atier", 0)), 0, 2)]
		return int(base[int(hi["armor"])])
	return 0


func set_player_light(pos: Vector3, l: float) -> void:
	for m in [terrain_mat, plant_mat]:
		m.set_shader_parameter("player_pos", pos)
		m.set_shader_parameter("lamp", l)


# =====================================================================
#  UI-ПОМОЩНИКИ
# =====================================================================
func panel_style(bg: Color, border: Color) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(2)
	sb.set_corner_radius_all(6)
	sb.set_content_margin_all(12)
	return sb


var _btn_cache := {}


## Детализированная кнопка: каменная текстура со скошенными краями (как в майнкрафте)
func _btn_style(accent: String, state: String) -> StyleBoxTexture:
	var key := accent + state
	if _btn_cache.has(key):
		return _btn_cache[key]
	var base := Color(0.46, 0.46, 0.5)
	if accent == "green":
		base = Color(0.3, 0.55, 0.26)
	elif accent == "red":
		base = Color(0.6, 0.24, 0.22)
	elif accent == "blue":
		base = Color(0.26, 0.42, 0.66)
	if state == "hover":
		base = base.lightened(0.18)
	elif state == "pressed":
		base = base.darkened(0.18)
	elif state == "disabled":
		base = Color(0.3, 0.3, 0.32)
	var n := 24
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	var rng := RandomNumberGenerator.new()
	rng.seed = 5
	for y in n:
		for x in n:
			var f := 1.0 + rng.randf_range(-0.045, 0.045)
			var c := Color(base.r * f, base.g * f, base.b * f)
			var hi := 0.0
			var lo := 0.0
			if state == "pressed":
				if x < 4 or y < 4:
					lo = 0.3
				if x >= n - 3 or y >= n - 3:
					hi = 0.12
			else:
				if (x >= 1 and x < 4 and y >= 1 and y < n - 3) or (y >= 1 and y < 4 and x >= 1 and x < n - 1):
					hi = 0.28
				if (x >= n - 4 and x < n - 1 and y >= 3) or (y >= n - 5 and y < n - 1 and x >= 3):
					lo = 0.34
			if hi > 0.0:
				c = c.lightened(hi)
			elif lo > 0.0:
				c = c.darkened(lo)
			if x == 0 or y == 0 or x == n - 1 or y == n - 1:
				c = Color(0.04, 0.04, 0.06)
			if (x == 0 or x == n - 1) and (y == 0 or y == n - 1):
				c = Color(0, 0, 0, 0)
			img.set_pixel(x, y, c)
	var sb := StyleBoxTexture.new()
	sb.texture = ImageTexture.create_from_image(img)
	sb.set_texture_margin_all(7)
	sb.set_content_margin_all(8)
	sb.axis_stretch_horizontal = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	sb.axis_stretch_vertical = StyleBoxTexture.AXIS_STRETCH_MODE_STRETCH
	_btn_cache[key] = sb
	return sb


func make_button(text: String, min_size := Vector2(260, 64), font_size := 24, accent := "") -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.add_theme_font_size_override("font_size", font_size)
	for k in ["normal", "hover", "pressed", "disabled"]:
		b.add_theme_stylebox_override(k, _btn_style(accent, k))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color(0.9, 0.9, 0.9))
	b.add_theme_color_override("font_disabled_color", Color(0.55, 0.55, 0.55))
	b.add_theme_constant_override("outline_size", 4)
	b.add_theme_color_override("font_outline_color", Color(0.08, 0.08, 0.1))
	return b


func make_label(text: String, size := 24, color := Color.WHITE) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_constant_override("outline_size", 5)
	l.add_theme_color_override("font_outline_color", Color(0.05, 0.05, 0.05))
	return l


func dirt_bg() -> Texture2D:
	var img := atlas_img.get_region(Rect2i(2 * 16, 0, 16, 16))
	img.resize(64, 64, Image.INTERPOLATE_NEAREST)
	return ImageTexture.create_from_image(img)


# =====================================================================
#  НАСТРОЙКИ
# =====================================================================
func save_settings() -> void:
	var cf := ConfigFile.new()
	for k in ["render_distance", "max_fps", "ao", "waves", "clouds", "fog", "msaa", "res_scale", "show_fps", "sens", "btn_scale", "hud_alpha", "scheme", "floating_joy", "autojump", "lefty", "tex_quality", "shadows", "glow", "volume", "music", "auto_tune", "leaf_depth", "grass_level", "water_q"]:
		cf.set_value("g", k, get(k))
	cf.save("user://settings.cfg")


func load_settings() -> void:
	var cf := ConfigFile.new()
	if cf.load("user://settings.cfg") != OK:
		return
	for k in ["render_distance", "max_fps", "ao", "waves", "clouds", "fog", "msaa", "res_scale", "show_fps", "sens", "btn_scale", "hud_alpha", "scheme", "floating_joy", "autojump", "lefty", "tex_quality", "shadows", "glow", "volume", "music", "auto_tune", "leaf_depth", "grass_level", "water_q"]:
		if cf.has_section_key("g", k):
			set(k, cf.get_value("g", k))


## Определяет мощность устройства: 0 слабое … 3 мощное
func device_tier() -> int:
	var cores := OS.get_processor_count()
	var mem := 0
	var mi := OS.get_memory_info()
	if mi.has("physical"):
		mem = int(mi["physical"])
	var gpu := RenderingServer.get_video_adapter_name().to_lower()
	var score := 0
	if cores >= 8:
		score += 2
	elif cores >= 6:
		score += 1
	elif cores <= 3:
		score -= 1
	if mem > 0:
		if mem >= 7 * 1024 * 1024 * 1024:
			score += 2
		elif mem >= 4 * 1024 * 1024 * 1024:
			score += 1
		elif mem < 3 * 1024 * 1024 * 1024:
			score -= 1
	var digits := ""
	for ch in gpu:
		if ch >= "0" and ch <= "9":
			digits += ch
		elif digits != "":
			break
	var gnum := int(digits) if digits != "" else 0
	if "adreno" in gpu:
		if gnum >= 730:
			score += 3
		elif gnum >= 640:
			score += 2
		elif gnum >= 610:
			score += 1
		elif gnum > 0 and gnum < 540:
			score -= 2
	elif "mali" in gpu:
		if gnum >= 78:
			score += 3
		elif gnum >= 76 or gnum >= 710:
			score += 1
		elif gnum > 0 and gnum < 72:
			score -= 2
	elif "apple" in gpu or "rtx" in gpu or "radeon rx" in gpu or "geforce" in gpu:
		score += 3
	elif "intel" in gpu:
		score += 0
	elif "swiftshader" in gpu or "llvmpipe" in gpu or "software" in gpu:
		score -= 4
	if score >= 6:
		return 3
	if score >= 4:
		return 2
	if score >= 1:
		return 1
	return 0


func auto_tune_apply() -> void:
	var t := device_tier()
	tier_name = ["слабое", "среднее", "хорошее", "мощное"][t]
	var rds := [4, 5, 7, 9]
	var ress := [0.6, 0.75, 0.9, 1.0]
	render_distance = rds[t]
	res_scale = ress[t]
	msaa = 2 if t == 3 else 0
	shadows = [0, 1, 1, 2][t]
	tex_quality = 1
	auto_blade_n = [18, 24, 30, 36][t]
	auto_blade_chunks = [2, 3, 3, 4][t]
	apply_grass()
	ao = t >= 1
	glow = t >= 3
	water_q = [0, 1, 1, 2][t]
	leaf_depth = t >= 1
	max_fps = [30, 45, 60, 60][t]
	var tq_changed := tex_quality != _last_tq
	if tq_changed:
		rebuild_terrain_texture()
	apply_shader_settings()
	apply_runtime()


## Применяет уровень 3D-травы/листьев (0 — по мощности устройства)
func apply_grass() -> void:
	match grass_level:
		1:
			blade_n = 0
		2:
			blade_n = 12
			blade_chunks = 2
		3:
			blade_n = 24
			blade_chunks = 3
		4:
			blade_n = 36
			blade_chunks = 4
		5:
			blade_n = 60
			blade_chunks = 5
		_:
			blade_n = auto_blade_n
			blade_chunks = auto_blade_chunks


func apply_runtime() -> void:
	Engine.max_fps = max_fps
	var vs := DisplayServer.VSYNC_ENABLED if (max_fps != 0 and max_fps <= 60) else DisplayServer.VSYNC_DISABLED
	DisplayServer.window_set_vsync_mode(vs)
	var vp := get_tree().root
	vp.msaa_3d = [Viewport.MSAA_DISABLED, Viewport.MSAA_2X, Viewport.MSAA_4X][clampi(msaa, 0, 2)]
	vp.scaling_3d_scale = clampf(res_scale, 0.5, 1.0)
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.0001)))
	if water_mat:
		waves = water_q > 0
		water_mat.set_shader_parameter("waves", 1.0 if waves else 0.0)
		water_mat.set_shader_parameter("quality", water_q)


## Пресеты: 0 — слабый телефон, 1 — мощный (как Quality.LOW / HIGH)
func apply_preset(p: int) -> void:
	auto_tune = false
	if p == 0:
		res_scale = 0.7
		msaa = 0
		shadows = 0
		water_q = 0
		ao = false
		glow = false
		grass_level = 2
		render_distance = 4
		max_fps = 30
	else:
		res_scale = 1.0
		msaa = 1
		shadows = 2
		water_q = 2
		ao = true
		glow = true
		grass_level = 4
		render_distance = 8
		max_fps = 60
	changed()


func changed() -> void:
	apply_grass()
	save_settings()
	if tex_quality != _last_tq:
		rebuild_terrain_texture()
	apply_shader_settings()
	apply_runtime()
	settings_changed.emit()


# =====================================================================
#  МИРЫ (сохранения)
# =====================================================================
const WORLDS_DIR := "user://worlds"


func _ensure_dir() -> void:
	DirAccess.make_dir_recursive_absolute(WORLDS_DIR)


func list_worlds() -> Array:
	_ensure_dir()
	var out := []
	var da := DirAccess.open(WORLDS_DIR)
	if da == null:
		return out
	for f in da.get_files():
		if f.ends_with(".meta"):
			var fa := FileAccess.open("%s/%s" % [WORLDS_DIR, f], FileAccess.READ)
			if fa:
				var m = fa.get_var()
				fa.close()
				if m is Dictionary:
					out.append(m)
	out.sort_custom(func(a, b): return int(a.get("played", 0)) > int(b.get("played", 0)))
	return out


var opts := {"coords": false, "always_day": false, "cheats": true}


func load_opts(meta: Dictionary) -> void:
	opts = {"coords": false, "always_day": false, "cheats": true}
	var o = meta.get("opts", {})
	if o is Dictionary:
		for k in o:
			opts[k] = o[k]


func set_opt(k: String, v) -> void:
	opts[k] = v
	if current_world == "":
		return
	var m := get_world_meta(current_world)
	if m.is_empty():
		return
	m["opts"] = opts
	_write_meta(m)


func create_world(wname: String, wmode: String, wseed: int, wopts := {}) -> String:
	_ensure_dir()
	var id := "%d_%d" % [int(Time.get_unix_time_from_system()), randi() % 10000]
	var meta := {"id": id, "name": wname, "mode": wmode, "seed": wseed, "opts": wopts, "created": int(Time.get_unix_time_from_system()), "played": int(Time.get_unix_time_from_system())}
	_write_meta(meta)
	return id


func _write_meta(meta: Dictionary) -> void:
	var f := FileAccess.open("%s/%s.meta" % [WORLDS_DIR, meta["id"]], FileAccess.WRITE)
	if f:
		f.store_var(meta)
		f.close()


func get_world_meta(id: String) -> Dictionary:
	var p := "%s/%s.meta" % [WORLDS_DIR, id]
	if not FileAccess.file_exists(p):
		return {}
	var f := FileAccess.open(p, FileAccess.READ)
	var m = f.get_var()
	f.close()
	if m is Dictionary:
		return m
	return {}


func delete_world(id: String) -> void:
	for ext in [".meta", ".dat"]:
		var p: String = "%s/%s%s" % [WORLDS_DIR, id, ext]
		if FileAccess.file_exists(p):
			DirAccess.remove_absolute(p)


func save_game(data: Dictionary) -> void:
	if current_world == "":
		return
	_ensure_dir()
	var f := FileAccess.open("%s/%s.dat" % [WORLDS_DIR, current_world], FileAccess.WRITE)
	if f:
		f.store_var(data)
		f.close()
	var meta := get_world_meta(current_world)
	if not meta.is_empty():
		meta["played"] = int(Time.get_unix_time_from_system())
		_write_meta(meta)


func load_game():
	if current_world == "":
		return null
	var p := "%s/%s.dat" % [WORLDS_DIR, current_world]
	if not FileAccess.file_exists(p):
		return null
	var f := FileAccess.open(p, FileAccess.READ)
	if f == null:
		return null
	var d = f.get_var()
	f.close()
	if d is Dictionary:
		return d
	return null
