class_name WorldList
extends VBoxContainer
## Окно «Мои миры»: сверху кнопка «Создать мир», ниже список сохранений.

signal play_world(id: String)
signal create_requested

var list_box: VBoxContainer


func _ready() -> void:
	add_theme_constant_override("separation", 12)
	var cr := G.make_button("+  Создать новый мир", Vector2(0, 76), 30, "green")
	cr.pressed.connect(func(): create_requested.emit())
	add_child(cr)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(sc)
	list_box = VBoxContainer.new()
	list_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_box.add_theme_constant_override("separation", 10)
	sc.add_child(list_box)
	refresh()


func refresh() -> void:
	if list_box == null:
		return
	for c in list_box.get_children():
		c.queue_free()
	var worlds := G.list_worlds()
	if worlds.is_empty():
		list_box.add_child(G.make_label("Пока нет миров. Нажми «Создать новый мир»!", 24, Color(0.85, 0.85, 0.85)))
		return
	for m in worlds:
		list_box.add_child(_card(m))


func _card(m: Dictionary) -> Control:
	var pc := PanelContainer.new()
	pc.add_theme_stylebox_override("panel", G.panel_style(Color(0.1, 0.11, 0.15, 0.9), Color(0.5, 0.55, 0.62, 0.9)))
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	pc.add_child(h)
	var cm: bool = m.get("mode", "survival") == "creative"
	var ic := ColorRect.new()
	ic.custom_minimum_size = Vector2(64, 64)
	ic.color = Color(0.9, 0.7, 0.2) if cm else Color(0.36, 0.64, 0.26)
	var icl := G.make_label("Т" if cm else "В", 38, Color(1, 1, 1))
	icl.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	icl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	icl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	ic.add_child(icl)
	h.add_child(ic)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(v)
	v.add_child(G.make_label(str(m.get("name", "Мир")), 28))
	var md := "Творческий" if cm else "Выживание"
	var dt := Time.get_datetime_dict_from_unix_time(int(m.get("played", 0)) + 3 * 3600)
	var when := "%02d.%02d.%d %02d:%02d" % [dt["day"], dt["month"], dt["year"], dt["hour"], dt["minute"]]
	v.add_child(G.make_label("%s · сид %s · %s" % [md, str(m.get("seed", 0)), when], 17, Color(0.75, 0.78, 0.85)))
	var id: String = m["id"]
	var play := G.make_button("Играть", Vector2(150, 60), 24, "green")
	play.pressed.connect(func(): play_world.emit(id))
	h.add_child(play)
	var del := G.make_button("Удалить", Vector2(130, 60), 20, "red")
	var armed := [false]
	del.pressed.connect(func():
		if armed[0]:
			G.delete_world(id)
			refresh()
		else:
			armed[0] = true
			del.text = "Точно?"
			get_tree().create_timer(3.0).timeout.connect(func():
				if is_instance_valid(del):
					armed[0] = false
					del.text = "Удалить"))
	h.add_child(del)
	return pc
