class_name ChunkMesher
extends RefCounted
## Построение мешей чанка (вызывается из потока). Использует копию блоков с «рамкой» в 1 блок.

const CS := 16
const CH := 64
const PW := 18
const PS := 324          # PW * PW
const LMIN := 0.22
const EPS := 0.02
const TILE := 0.0625     # 1 / 16
const AO_LV := [0.5, 0.68, 0.84, 1.0]

const DIRS := [Vector3i(0, 1, 0), Vector3i(0, -1, 0), Vector3i(1, 0, 0), Vector3i(-1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1)]
const FACE_ORIGIN := [Vector3(0, 1, 0), Vector3(0, 0, 0), Vector3(1, 0, 0), Vector3(0, 0, 0), Vector3(0, 0, 1), Vector3(0, 0, 0)]
const FACE_U := [Vector3i(1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 0, 1), Vector3i(0, 1, 0), Vector3i(0, 1, 0), Vector3i(1, 0, 0)]
const FACE_V := [Vector3i(0, 0, 1), Vector3i(1, 0, 0), Vector3i(0, 1, 0), Vector3i(0, 0, 1), Vector3i(1, 0, 0), Vector3i(0, 1, 0)]
const UV_MODE := [0, 0, 1, 2, 2, 1]
const CI := [0.0, 1.0, 1.0, 0.0]
const CJ := [0.0, 0.0, 1.0, 1.0]


class Buf:
	var v := PackedVector3Array()
	var n := PackedVector3Array()
	var c := PackedColorArray()
	var t := PackedVector2Array()
	var i := PackedInt32Array()

	func to_arrays() -> Array:
		if v.size() == 0:
			return []
		var arr := []
		arr.resize(Mesh.ARRAY_MAX)
		arr[Mesh.ARRAY_VERTEX] = v
		arr[Mesh.ARRAY_NORMAL] = n
		arr[Mesh.ARRAY_COLOR] = c
		arr[Mesh.ARRAY_TEX_UV] = t
		arr[Mesh.ARRAY_INDEX] = i
		return arr


static func _op(P: PackedByteArray, opq: PackedByteArray, x: int, y: int, z: int) -> int:
	if x < 0 or x >= PW or z < 0 or z >= PW or y < 0 or y >= CH:
		return 0
	return opq[P[x + z * PW + y * PS]]


## chunks9 / hms9: 9 массивов (индекс (dz+1)*3 + (dx+1)), null если чанка нет.
static func _blight(torches: Array, x: int, y: int, z: int) -> float:
	var m := 0.0
	for t in torches:
		var tv: Vector3i = t
		var dd := absi(x - tv.x) + absi(y - tv.y) + absi(z - tv.z)
		if dd < 8:
			m = maxf(m, 1.0 - float(dd) / 8.0)
	return m


const BIO_TINT := [1, 2, 4, 2, 2, 1, 1, 1, 3, 1]


static func build(chunks9: Array, hms9: Array, bio: PackedByteArray, maxy: int, cfg: Dictionary) -> Dictionary:
	var ao: bool = cfg["ao"]
	var opq: PackedByteArray = cfg["opq"]
	var plant: PackedByteArray = cfg["plant"]
	var low: PackedByteArray = cfg["low"]
	var tint: PackedByteArray = cfg["tint"]
	var tcol := PackedFloat32Array()
	tcol.resize(CS * CS)
	for tz in CS:
		for tx in CS:
			var acc := 0.0
			var cnt := 0.0
			for dz in range(-2, 3):
				for dx in range(-2, 3):
					var nx := clampi(tx + dx, 0, CS - 1)
					var nz := clampi(tz + dz, 0, CS - 1)
					acc += float(BIO_TINT[bio[nx + nz * CS]])
					cnt += 1.0
			tcol[tx + tz * CS] = acc / cnt
	var t_top: PackedInt32Array = cfg["t_top"]
	var t_bot: PackedInt32Array = cfg["t_bot"]
	var t_side: PackedInt32Array = cfg["t_side"]
	var water_id: int = cfg["water"]
	var torch_id: int = cfg["torch"]
	var weed_id: int = cfg["weed"]
	var cobble_id: int = cfg["cobble"]
	var nblades: int = cfg["blades"]
	var tall_id: int = cfg["tall"]
	var ox0: int = cfg["ox"]
	var oz0: int = cfg["oz"]
	var stone_id: int = cfg["stone"]
	var s_pos := PackedVector3Array()
	var s_inf := PackedVector2Array()
	var c_pos := PackedVector3Array()
	var c_inf := PackedVector2Array()
	var leaf: PackedByteArray = cfg["leaf"]
	var leaf_depth: bool = cfg["leaf_depth"]
	var shaped: PackedByteArray = cfg["shaped"]
	var boxes_tab: Array = cfg["boxes"]
	var fence_id: int = cfg["fence"]
	var P := PackedByteArray()
	P.resize(PW * PW * CH)
	var H := PackedByteArray()
	H.resize(PW * PW)
	var ymax := mini(maxy + 1, CH - 1)

	for cz in 3:
		for cx in 3:
			var src = chunks9[cz * 3 + cx]
			if src == null:
				continue
			var hs: PackedByteArray = hms9[cz * 3 + cx]
			var lx0 := 0
			var n := 16
			var px0 := 1
			if cx == 0:
				lx0 = 15
				n = 1
				px0 = 0
			elif cx == 2:
				n = 1
				px0 = 17
			var lz0 := 0
			var m := 16
			var pz0 := 1
			if cz == 0:
				lz0 = 15
				m = 1
				pz0 = 0
			elif cz == 2:
				m = 1
				pz0 = 17
			for j in m:
				var lz := lz0 + j
				var pz := pz0 + j
				for k in n:
					H[(px0 + k) + pz * PW] = hs[(lx0 + k) + lz * CS]
				for y in range(0, ymax + 1):
					var si := lx0 + lz * CS + y * 256
					var pi := px0 + pz * PW + y * PS
					for k in n:
						P[pi + k] = src[si + k]

	var torches := []
	var ti := P.find(torch_id, 0)
	while ti >= 0:
		var ty := ti / PS
		var rem := ti - ty * PS
		var tz := rem / PW
		torches.append(Vector3i(rem - tz * PW, ty, tz))
		ti = P.find(torch_id, ti + 1)
	var fi := P.find(int(cfg["furnace"]), 0)
	while fi >= 0:
		var fy := fi / PS
		var frem := fi - fy * PS
		var fz := frem / PW
		torches.append(Vector3i(frem - fz * PW, fy, fz))
		fi = P.find(int(cfg["furnace"]), fi + 1)
	var has_torch := torches.size() > 0

	var main := Buf.new()
	var wat := Buf.new()
	var pl := Buf.new()
	var offs := [PS, -PS, 1, -1, PW, -PW]

	for y in range(0, ymax + 1):
		for lz in CS:
			for lx in CS:
				var pi := (lx + 1) + (lz + 1) * PW + y * PS
				var id := P[pi]
				if id == 0:
					continue
				if id == weed_id and (y + 1 >= CH or P[pi + PS] == 0):
					# поверхность воды над водорослью (иначе в воде дыра и видно всё насквозь)
					var wb := wat.v.size()
					var wtile: int = t_top[water_id]
					var wtc := wtile % 16
					var wtr := wtile / 16
					var wo: Vector3 = FACE_ORIGIN[0]
					var wu := Vector3(FACE_U[0])
					var wv := Vector3(FACE_V[0])
					for k in 4:
						var wci: float = CI[k]
						var wcj: float = CJ[k]
						var wp := Vector3(lx, y, lz) + wo + wu * wci + wv * wcj
						if wp.y > y + 0.99:
							wp.y -= 0.12
						wat.v.push_back(wp)
						wat.n.push_back(Vector3(0, 1, 0))
						wat.c.push_back(Color(1.0, 1.0, 0.0, 1.0))
						wat.t.push_back(Vector2((float(wtc) + EPS + wci * (1.0 - 2.0 * EPS)) * TILE, (float(wtr) + EPS + wcj * (1.0 - 2.0 * EPS)) * TILE))
					wat.i.append_array(PackedInt32Array([wb, wb + 1, wb + 2, wb, wb + 2, wb + 3]))
				if nblades > 0 and id == tall_id:
					continue
				if plant[id] == 1:
					var ta := 1.0
					if tint[id] == 1:
						ta = 1.0 - tcol[lx + lz * CS] * 0.2
					_plant(pl, H, lx, y, lz, t_top[id], ta, id == torch_id)
					continue
				if shaped[id] == 1:
					var sh_ta := 1.0
					if tint[id] == 1:
						sh_ta = 1.0 - tcol[lx + lz * CS] * 0.2
					var sht := H[(lx + 1) + (lz + 1) * PW]
					var shl := 1.0
					if y < sht:
						shl = maxf(LMIN, 1.0 - float(sht - y) * 0.17)
					var shb := 0.0
					if has_torch:
						shb = _blight(torches, lx + 1, y, lz + 1)
					var blist: Array = boxes_tab[id]
					if id == fence_id:
						blist = _fence_boxes(P, opq, id, lx, y, lz)
					for bxv in blist:
						_boxf(main, P, opq, id, lx, y, lz, bxv, t_top[id], t_side[id], t_bot[id], shl, shb, sh_ta, water_id)
					continue
				var is_water := id == water_id
				var water_top := false
				if is_water:
					water_top = y + 1 >= CH or P[pi + PS] != water_id
				var ta2 := 1.0
				if tint[id] == 1:
					ta2 = 1.0 - tcol[lx + lz * CS] * 0.2
				if nblades > 0:
					if id == 1 and (y + 1 >= CH or P[pi + PS] == 0):
						var bta := 1.0 - tcol[lx + lz * CS] * 0.2
						_blades(pl, lx, y, lz, ox0 + lx, oz0 + lz, nblades, bta)
					elif leaf[id] == 1:
						var lta := 1.0
						if tint[id] == 1:
							lta = 1.0 - tcol[lx + lz * CS] * 0.2
						var lht := H[(lx + 1) + (lz + 1) * PW]
						var llt := 1.0
						if y < lht:
							llt = maxf(LMIN, 1.0 - float(lht - y) * 0.17)
						for f3 in 6:
							var nid3 := 1
							if not (f3 == 0 and y + 1 >= CH):
								if f3 == 1 and y == 0:
									continue
								nid3 = P[pi + offs[f3]]
							else:
								nid3 = 0
							if nid3 == 0:
								_leaf_cards(pl, lx, y, lz, ox0 + lx, oz0 + lz, f3, lta, llt)
				if id == stone_id or id == cobble_id:
					var ex := false
					for f2 in 6:
						if f2 == 1 and y == 0:
							continue
						var nid2 := 0
						if not (f2 == 0 and y + 1 >= CH):
							nid2 = P[pi + offs[f2]]
						if opq[nid2] == 0:
							ex = true
							break
					if ex:
						var mht := H[(lx + 1) + (lz + 1) * PW]
						var mlt := 1.0
						if y < mht:
							mlt = maxf(LMIN, 1.0 - float(mht - y) * 0.17)
						var mbl := 0.0
						if has_torch:
							mbl = _blight(torches, lx + 1, y, lz + 1)
						if id == stone_id and s_pos.size() < 3000:
							s_pos.push_back(Vector3(lx + 0.5, y + 0.5, lz + 0.5))
							s_inf.push_back(Vector2(mlt, mbl))
						elif id == cobble_id and c_pos.size() < 3000:
							c_pos.push_back(Vector3(lx + 0.5, y + 0.5, lz + 0.5))
							c_inf.push_back(Vector2(mlt, mbl))
				var is_low := low[id] == 1
				for f in 6:
					if f == 1 and y == 0:
						continue
					var nid := 0
					if f == 0 and y + 1 >= CH:
						nid = 0
					else:
						nid = P[pi + offs[f]]
					var vis := false
					if is_water:
						vis = nid == 0 or (plant[nid] == 1 and nid != weed_id)
					else:
						vis = nid == 0 or nid == water_id or plant[nid] == 1 or (opq[nid] == 0 and nid != id)
					if not vis:
						continue
					var dv: Vector3i = DIRS[f]
					var U: Vector3i = FACE_U[f]
					var V: Vector3i = FACE_V[f]
					var fx := lx + 1 + dv.x
					var fy := y + dv.y
					var fz := lz + 1 + dv.z
					var ht := H[fx + fz * PW]
					var lt := 1.0
					if fy < ht:
						lt = maxf(LMIN, 1.0 - float(ht - fy) * 0.17)
					var tile := 0
					if f == 0:
						tile = t_top[id]
					elif f == 1:
						tile = t_bot[id]
					else:
						tile = t_side[id]
					var tc := tile % 16
					var tr := tile / 16
					var um: int = UV_MODE[f]
					var o: Vector3 = FACE_ORIGIN[f]
					var base := Vector3(lx, y, lz) + o
					var aol := [1.0, 1.0, 1.0, 1.0]
					if ao and not is_water:
						for k in 4:
							var su := 1 if CI[k] > 0.5 else -1
							var sv := 1 if CJ[k] > 0.5 else -1
							var s1 := _op(P, opq, fx + U.x * su, fy + U.y * su, fz + U.z * su)
							var s2 := _op(P, opq, fx + V.x * sv, fy + V.y * sv, fz + V.z * sv)
							var s3 := _op(P, opq, fx + U.x * su + V.x * sv, fy + U.y * su + V.y * sv, fz + U.z * su + V.z * sv)
							var lv := 0
							if not (s1 == 1 and s2 == 1):
								lv = 3 - (s1 + s2 + s3)
							aol[k] = AO_LV[lv]
					var bl := 0.0
					if has_torch:
						bl = _blight(torches, fx, fy, fz)
					if id == cobble_id:
						_relief_face(main, base, Vector3(U), Vector3(V), Vector3(dv), tc, tr, um, aol, lt, bl, ta2)
						continue
					var buf: Buf = wat if is_water else main
					var b := buf.v.size()
					var nrm := Vector3(dv)
					var fu := Vector3(U)
					var fv := Vector3(V)
					for k in 4:
						var ci: float = CI[k]
						var cj: float = CJ[k]
						var pp := base + fu * ci + fv * cj
						if is_water and water_top and f != 1 and pp.y > y + 0.99:
							pp.y -= 0.12
						if is_low:
							pp.y = y + (pp.y - y) * 0.56
						buf.v.push_back(pp)
						buf.n.push_back(nrm)
						buf.c.push_back(Color(aol[k], lt, bl, ta2))
						var tu := ci
						var tv := cj
						if um == 1:
							tv = 1.0 - cj
						elif um == 2:
							tu = cj
							tv = 1.0 - ci
						buf.t.push_back(Vector2((float(tc) + EPS + tu * (1.0 - 2.0 * EPS)) * TILE, (float(tr) + EPS + tv * (1.0 - 2.0 * EPS)) * TILE))
					if float(aol[1]) + float(aol[3]) > float(aol[0]) + float(aol[2]):
						buf.i.push_back(b + 1)
						buf.i.push_back(b + 2)
						buf.i.push_back(b + 3)
						buf.i.push_back(b + 1)
						buf.i.push_back(b + 3)
						buf.i.push_back(b)
					else:
						buf.i.push_back(b)
						buf.i.push_back(b + 1)
						buf.i.push_back(b + 2)
						buf.i.push_back(b)
						buf.i.push_back(b + 2)
						buf.i.push_back(b + 3)
					if leaf_depth and leaf[id] == 1:
						var b2 := main.v.size()
						for k in 4:
							var cx2: float = CI[k]
							var cy2: float = CJ[k]
							main.v.push_back(base + fu * cx2 + fv * cy2 - nrm * 0.34)
							main.n.push_back(nrm)
							main.c.push_back(Color(float(aol[k]) * 0.6, lt * 0.8, bl, ta2))
							var tu2 := cx2
							var tv2 := cy2
							if um == 1:
								tv2 = 1.0 - cy2
							elif um == 2:
								tu2 = cy2
								tv2 = 1.0 - cx2
							main.t.push_back(Vector2((float(tc) + EPS + (1.0 - tu2) * (1.0 - 2.0 * EPS)) * TILE, (float(tr) + EPS + (1.0 - tv2) * (1.0 - 2.0 * EPS)) * TILE))
						main.i.push_back(b2)
						main.i.push_back(b2 + 1)
						main.i.push_back(b2 + 2)
						main.i.push_back(b2)
						main.i.push_back(b2 + 2)
						main.i.push_back(b2 + 3)

	return {"main": main.to_arrays(), "water": wat.to_arrays(), "plant": pl.to_arrays(), "s_pos": s_pos, "s_inf": s_inf, "c_pos": c_pos, "c_inf": c_inf}


static func _fence_boxes(P: PackedByteArray, opq: PackedByteArray, id: int, lx: int, y: int, lz: int) -> Array:
	var res := [PackedFloat32Array([0.375, 0.0, 0.375, 0.625, 1.0, 0.625])]
	var pi := (lx + 1) + (lz + 1) * PW + y * PS
	var offs := [1, -1, PW, -PW]
	for k in 4:
		var nid: int = P[pi + int(offs[k])]
		if nid != id and (nid == 0 or opq[nid] == 0):
			continue
		for rail in 2:
			var y0 := 0.375 if rail == 0 else 0.75
			var y1 := y0 + 0.1875
			if k == 0:
				res.append(PackedFloat32Array([0.625, y0, 0.4375, 1.0, y1, 0.5625]))
			elif k == 1:
				res.append(PackedFloat32Array([0.0, y0, 0.4375, 0.375, y1, 0.5625]))
			elif k == 2:
				res.append(PackedFloat32Array([0.4375, y0, 0.625, 0.5625, y1, 1.0]))
			else:
				res.append(PackedFloat32Array([0.4375, y0, 0.0, 0.5625, y1, 0.375]))
	return res


const UA := [0, 2, 2, 1, 1, 0]
const VA := [2, 0, 1, 2, 0, 1]


## Грани одного бокса внутри блока (плиты, ступени, двери, сундук, забор)
const RN := 6
static var _rel_h := PackedFloat32Array()


static func _relief_heights() -> void:
	if _rel_h.size() > 0:
		return
	_rel_h.resize((RN + 1) * (RN + 1))
	var img: Image = null
	if ResourceLoader.exists("res://assets/hd/tile_9.png"):
		img = load("res://assets/hd/tile_9.png").get_image()
	for j in RN + 1:
		for i in RN + 1:
			var h := 0.0
			if img != null and i > 0 and j > 0 and i < RN and j < RN:
				var px := int(float(i) / RN * (img.get_width() - 1))
				var py := int(float(j) / RN * (img.get_height() - 1))
				var l := img.get_pixel(px, py).get_luminance()
				h = clampf((l - 0.22) * 0.22, 0.0, 0.07)
			_rel_h[j * (RN + 1) + i] = h


## Грань булыжника с настоящим рельефом (выпуклые камни), а не плоская текстура
static func _relief_face(buf: Buf, base: Vector3, fu: Vector3, fv: Vector3, nrm: Vector3, tc: int, tr: int, um: int, aol: Array, lt: float, bl: float, ta2: float) -> void:
	_relief_heights()
	var b0 := buf.v.size()
	for j in RN + 1:
		for i in RN + 1:
			var ci := float(i) / RN
			var cj := float(j) / RN
			var h: float = _rel_h[j * (RN + 1) + i]
			buf.v.push_back(base + fu * ci + fv * cj + nrm * h)
			buf.n.push_back(nrm)
			# билинейная интерполяция AO по углам (0:(0,0) 1:(1,0) 2:(1,1) 3:(0,1) — как в CI/CJ)
			var a := lerpf(lerpf(float(aol[0]), float(aol[1]), ci), lerpf(float(aol[3]), float(aol[2]), ci), cj)
			var shade := 0.92 + h * 2.0
			buf.c.push_back(Color(a * minf(shade, 1.15), lt, bl, ta2))
			var tu := ci
			var tv := cj
			if um == 1:
				tv = 1.0 - cj
			elif um == 2:
				tu = cj
				tv = 1.0 - ci
			buf.t.push_back(Vector2((float(tc) + EPS + tu * (1.0 - 2.0 * EPS)) * TILE, (float(tr) + EPS + tv * (1.0 - 2.0 * EPS)) * TILE))
	for j in RN:
		for i in RN:
			var a0 := b0 + j * (RN + 1) + i
			var a1 := a0 + 1
			var a2 := a0 + RN + 1
			var a3 := a2 + 1
			buf.i.append_array(PackedInt32Array([a0, a1, a3, a0, a3, a2]))


static func _boxf(buf: Buf, P: PackedByteArray, opq: PackedByteArray, id: int, lx: int, y: int, lz: int, bx: PackedFloat32Array, ttop: int, tside: int, tbot: int, lt: float, bl: float, ta2: float, water_id: int) -> void:
	var lo := [bx[0], bx[1], bx[2]]
	var hi := [bx[3], bx[4], bx[5]]
	var pi := (lx + 1) + (lz + 1) * PW + y * PS
	var offs := [PS, -PS, 1, -1, PW, -PW]
	for f in 6:
		var a: int = 1 if f < 2 else (0 if f < 4 else 2)
		var pos_dir := f % 2 == 0
		var on_edge := (pos_dir and float(hi[a]) >= 0.999) or ((not pos_dir) and float(lo[a]) <= 0.001)
		if on_edge:
			if f == 1 and y == 0:
				continue
			var nid := 0
			if f == 0 and y + 1 >= CH:
				nid = 0
			else:
				nid = P[pi + int(offs[f])]
			if nid > 0 and nid != water_id and (opq[nid] == 1 or nid == id):
				continue
		var plane: float = float(hi[a]) if pos_dir else float(lo[a])
		var ua: int = UA[f]
		var va: int = VA[f]
		var um: int = UV_MODE[f]
		var tile := ttop if f == 0 else (tbot if f == 1 else tside)
		var tc := tile % 16
		var tr := tile / 16
		var b := buf.v.size()
		var nrm := Vector3(DIRS[f])
		for k in 4:
			var ci: float = CI[k]
			var cj: float = CJ[k]
			var uu := lerpf(float(lo[ua]), float(hi[ua]), ci)
			var vv := lerpf(float(lo[va]), float(hi[va]), cj)
			var pp := [0.0, 0.0, 0.0]
			pp[a] = plane
			pp[ua] = uu
			pp[va] = vv
			buf.v.push_back(Vector3(float(lx) + float(pp[0]), float(y) + float(pp[1]), float(lz) + float(pp[2])))
			buf.n.push_back(nrm)
			buf.c.push_back(Color(1.0, lt, bl, ta2))
			var tu := uu
			var tv := vv
			if um == 1:
				tv = 1.0 - vv
			elif um == 2:
				tu = vv
				tv = 1.0 - uu
			buf.t.push_back(Vector2((float(tc) + EPS + tu * (1.0 - 2.0 * EPS)) * TILE, (float(tr) + EPS + tv * (1.0 - 2.0 * EPS)) * TILE))
		buf.i.push_back(b)
		buf.i.push_back(b + 1)
		buf.i.push_back(b + 2)
		buf.i.push_back(b)
		buf.i.push_back(b + 2)
		buf.i.push_back(b + 3)


static func _rnd(a: int, b: int, c: int, d: int) -> float:
	var n := (a * 374761393 + b * 668265263 + c * 1274126177 + d * 1442695041) & 0x7fffffff
	n = ((n ^ (n >> 13)) * 1274126177) & 0x7fffffff
	n = n ^ (n >> 16)
	return float(n & 0xffff) / 65535.0


## 3D-травинки на верхней грани блока травы (как в твоём grass-block.html)
static func _blades(b: Buf, lx: int, y: int, lz: int, wx: int, wz: int, n: int, ta: float) -> void:
	var clumps := maxi(n / 6, 1)
	for cl in clumps:
		var cx := lx + 0.12 + _rnd(wx, y, wz, cl * 31 + 1) * 0.76
		var cz := lz + 0.12 + _rnd(wx, y, wz, cl * 31 + 2) * 0.76
		var chh := 0.8 + _rnd(wx, y, wz, cl * 31 + 3) * 0.5
		for k in 6:
			var s := cl * 31 + 5 + k * 6
			var a0 := _rnd(wx, y, wz, s) * TAU
			var rr := _rnd(wx, y, wz, s + 1) * 0.11
			var px := cx + cos(a0) * rr
			var pz := cz + sin(a0) * rr
			# направление изгиба — от центра пучка наружу (пучок «веером»)
			var out := Vector3(cos(a0), 0.0, sin(a0))
			if rr < 0.02:
				out = Vector3(cos(a0 + 1.0), 0.0, sin(a0 + 1.0))
			var side := Vector3(-out.z, 0.0, out.x)
			var r := _rnd(wx, y, wz, s + 2)
			var hgt := (0.3 + r * r * 0.55) * chh
			var base := Vector3(clampf(px, lx + 0.03, lx + 0.97), y + 1.0, clampf(pz, lz + 0.03, lz + 0.97))
			var w := (0.06 + r * 0.03) if n <= 36 else (0.042 + r * 0.02)
			var hm := hgt * 0.5
			var bend := 0.9 + _rnd(wx, y, wz, s + 3) * 0.7
			var p0 := base - side * w
			var p1 := base + side * w
			var p2 := base + Vector3(0, hm, 0) + out * (hm * hm * bend) - side * (w * 0.65)
			var p3 := base + Vector3(0, hm, 0) + out * (hm * hm * bend) + side * (w * 0.65)
			var p4 := base + Vector3(0, hgt, 0) + out * (hgt * hgt * bend)
			var o := b.v.size()
			var u := (0.1 + _rnd(wx, y, wz, s + 4) * 0.8) * TILE
			var v := (0.1 + r * 0.8) * TILE
			var sw := [0.0, 0.0, 0.5, 0.5, 1.0]
			var ps := [p0, p1, p2, p3, p4]
			for i in 5:
				b.v.push_back(ps[i])
				b.n.push_back(Vector3(0, 1, 0))
				b.t.push_back(Vector2(u, v))
				b.c.push_back(Color(1.2, 1.0, sw[i], ta))
			b.i.append_array(PackedInt32Array([o, o + 1, o + 3, o, o + 3, o + 2, o + 2, o + 3, o + 4]))


## 3D-листья (отдельные листики с прожилками) на открытой грани блока листвы
static func _leaf_cards(b: Buf, lx: int, y: int, lz: int, wx: int, wz: int, f: int, ta: float, lt: float) -> void:
	var nrm := Vector3(DIRS[f])
	var U := Vector3(FACE_U[f])
	var V := Vector3(FACE_V[f])
	var c0 := Vector3(lx + 0.5, y + 0.5, lz + 0.5)
	var tu0 := (15.0 + 0.02) * TILE
	var tu1 := (16.0 - 0.02) * TILE
	var tv0 := (15.0 + 0.02) * TILE
	var tv1 := (16.0 - 0.02) * TILE
	for k in 3:
		var s := f * 11 + k * 3
		var cx := (_rnd(wx, y, wz, s + 100) - 0.5) * 0.85
		var cy := (_rnd(wx, y, wz, s + 101) - 0.5) * 0.85
		var t := _rnd(wx, y, wz, s + 102) * TAU
		var tilt := 0.35 + _rnd(wx, y, wz, s + 103) * 0.5
		var sz := 0.2 + _rnd(wx, y, wz, s + 104) * 0.14
		var cen := c0 + nrm * (0.46 + _rnd(wx, y, wz, s + 105) * 0.08) + U * cx + V * cy
		var ax := (U * cos(t) + V * sin(t)).normalized()
		var ay := ((U * -sin(t) + V * cos(t)) * tilt + nrm * (1.0 - tilt * 0.5)).normalized()
		var o := b.v.size()
		var w2 := ax * (sz * 0.5)
		var len := ay * sz
		b.v.push_back(cen - w2)
		b.v.push_back(cen + w2)
		b.v.push_back(cen + w2 + len)
		b.v.push_back(cen - w2 + len)
		b.t.push_back(Vector2(tu0, tv1))
		b.t.push_back(Vector2(tu1, tv1))
		b.t.push_back(Vector2(tu1, tv0))
		b.t.push_back(Vector2(tu0, tv0))
		for i in 4:
			b.n.push_back(nrm)
			b.c.push_back(Color(1.0, lt, 0.55 if i >= 2 else 0.1, ta))
		b.i.append_array(PackedInt32Array([o, o + 1, o + 2, o, o + 2, o + 3]))


static func _plant(b: Buf, H: PackedByteArray, lx: int, y: int, lz: int, tile: int, ta: float, is_torch: bool) -> void:
	var ht := H[(lx + 1) + (lz + 1) * PW]
	var lt := 1.0
	if y < ht:
		lt = maxf(LMIN, 1.0 - float(ht - y) * 0.17)
	var tc := tile % 16
	var tr := tile / 16
	var u0 := (float(tc) + EPS) * TILE
	var u1 := (float(tc) + 1.0 - EPS) * TILE
	var v0 := (float(tr) + EPS) * TILE
	var v1 := (float(tr) + 1.0 - EPS) * TILE
	var hs := ((lx * 73 + lz * 151 + y * 31) & 15) / 15.0
	var ox := (hs - 0.5) * 0.3
	var oz := (float((lx * 37 + lz * 91) & 15) / 15.0 - 0.5) * 0.3
	var hh := 1.0
	var p0 := Vector3(lx + ox, y, lz + oz)
	var quads := [
		[Vector3(0.08, 0, 0.08), Vector3(0.92, 0, 0.92)],
		[Vector3(0.92, 0, 0.08), Vector3(0.08, 0, 0.92)],
	]
	if is_torch:
		p0 = Vector3(lx, y, lz)
		quads = [
			[Vector3(0.1, 0, 0.5), Vector3(0.9, 0, 0.5)],
			[Vector3(0.5, 0, 0.1), Vector3(0.5, 0, 0.9)],
		]
	else:
		hh = 0.8 + hs * 0.2
		quads.append([Vector3(0.0, 0, 0.5), Vector3(1.0, 0, 0.5)])
	for q in quads:
		var a: Vector3 = q[0]
		var c: Vector3 = q[1]
		var base := b.v.size()
		b.v.push_back(p0 + a)
		b.v.push_back(p0 + c)
		b.v.push_back(p0 + c + Vector3(0, hh, 0))
		b.v.push_back(p0 + a + Vector3(0, hh, 0))
		b.t.push_back(Vector2(u0, v1))
		b.t.push_back(Vector2(u1, v1))
		b.t.push_back(Vector2(u1, v0))
		b.t.push_back(Vector2(u0, v0))
		for k in 4:
			b.n.push_back(Vector3(0, 1, 0))
			if is_torch:
				b.c.push_back(Color(2.0, lt, 0.0, ta))
			else:
				b.c.push_back(Color(1.0, lt, 1.0 if k >= 2 else 0.0, ta))
		b.i.push_back(base)
		b.i.push_back(base + 1)
		b.i.push_back(base + 2)
		b.i.push_back(base)
		b.i.push_back(base + 2)
		b.i.push_back(base + 3)
