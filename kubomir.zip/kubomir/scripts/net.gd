class_name NetSession
extends Node
## Сеть на двоих (ENet/UDP): один хостит, второй подключается по IP. Синхронизация: позиции, блоки,
## время, чат, скины и голосовой чат. Живёт в корне дерева и переживает смену сцен.

signal status(msg: String)
signal joined_world

const PORT := 24565
const VOICE_DIV := 4

static var inst: NetSession = null

var active := false
var is_host := false
var game = null
var avatar: Node3D = null
var model: SkinModel = null
var tag: Label3D = null
var my_name := "Игрок"
var remote_name := "Гость"
var remote_skin_png := PackedByteArray()
var pending := {}                # данные мира для клиента
var target_pos := Vector3.ZERO
var target_yaw := 0.0
var target_pitch := 0.0
var walk_t := 0.0
var send_t := 0.0
var sync_t := 0.0
var connecting_t := -1.0
var public_ip := ""
var upnp_msg := ""

# голос
var mic_on := false
var capture: AudioEffectCapture = null
var mic_player: AudioStreamPlayer = null
var voice_player: AudioStreamPlayer = null
var voice_pb: AudioStreamGeneratorPlayback = null
var voice_rate := 0
var voice_accum := PackedByteArray()
var talk_hold := 0.0
var remote_talk := 0.0
var last_voice_t := -10.0


static func get_inst(tree: SceneTree) -> NetSession:
	if inst == null or not is_instance_valid(inst):
		inst = NetSession.new()
		inst.name = "NetSession"
		tree.root.add_child(inst)
	return inst


func _ready() -> void:
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_left)
	multiplayer.connected_to_server.connect(_on_connected)
	multiplayer.connection_failed.connect(_on_failed)
	multiplayer.server_disconnected.connect(_on_server_gone)


# ---------------------------------------------------------------- подключение
func local_ips() -> Array:
	var out := []
	for a in IP.get_local_addresses():
		var s: String = a
		if s.count(".") == 3 and not s.begins_with("127.") and not s.begins_with("169.254."):
			out.append(s)
	return out


func host(g) -> bool:
	close()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_server(PORT, 1)
	if err != OK:
		status.emit("Не удалось открыть порт %d" % PORT)
		return false
	multiplayer.multiplayer_peer = peer
	active = true
	is_host = true
	my_name = "Хост"
	attach_game(g)
	_start_upnp()
	_setup_mic()
	return true


func join(ip: String) -> void:
	close()
	var peer := ENetMultiplayerPeer.new()
	var err := peer.create_client(ip.strip_edges(), PORT)
	if err != OK:
		status.emit("Неверный адрес")
		return
	multiplayer.multiplayer_peer = peer
	active = true
	is_host = false
	my_name = "Гость"
	connecting_t = 0.0
	status.emit("Подключаюсь к %s…" % ip)


func close() -> void:
	if multiplayer.multiplayer_peer != null:
		multiplayer.multiplayer_peer.close()
		multiplayer.multiplayer_peer = null
	active = false
	is_host = false
	connecting_t = -1.0
	_remove_avatar()
	game = null
	_stop_mic()


func _start_upnp() -> void:
	WorkerThreadPool.add_task(func():
		var u := UPNP.new()
		if u.discover(2000) == UPNP.UPNP_RESULT_SUCCESS and u.get_gateway() != null and u.get_gateway().is_valid_gateway():
			u.add_port_mapping(PORT, PORT, "Kubomir", "UDP")
			public_ip = u.query_external_address()
			upnp_msg = "UPnP: порт открыт автоматически"
		else:
			upnp_msg = "UPnP недоступен: для игры через интернет пробрось UDP-порт %d или используй VPN (Tailscale/ZeroTier)" % PORT)


func _on_peer_connected(id: int) -> void:
	if is_host:
		status.emit("Игрок подключается…")


func _on_peer_left(_id: int) -> void:
	_remove_avatar()
	if game != null:
		game.hud.say("[Сеть] Игрок вышел")


func _on_connected() -> void:
	connecting_t = -1.0
	status.emit("Подключено, загружаю мир…")
	rpc_id(1, "req_world", PlayerSkin.current().save_png_to_buffer(), my_name)


func _on_failed() -> void:
	connecting_t = -1.0
	active = false
	status.emit("Не удалось подключиться. Проверь IP, порт и что хост открыл игру.")


func _on_server_gone() -> void:
	status.emit("Хост закрыл игру")
	if game != null:
		game.hud.toast("Хост закрыл игру")
		game.exit_to_menu(false)
	close()


# ---------------------------------------------------------------- RPC
@rpc("any_peer", "call_remote", "reliable")
func req_world(skin_png: PackedByteArray, pname: String) -> void:
	if not is_host or game == null:
		return
	var id := multiplayer.get_remote_sender_id()
	remote_name = pname
	remote_skin_png = skin_png
	_make_avatar()
	game.hud.say("[Сеть] %s подключился" % pname)
	var info := {
		"seed": G.seed_value, "mode": G.mode, "opts": G.opts, "edits": game.world.edits_flat(),
		"tod": game.tod, "pos": game.player.position, "name": my_name,
		"skin": PlayerSkin.current().save_png_to_buffer(),
	}
	rpc_id(id, "recv_world", info)


@rpc("authority", "call_remote", "reliable")
func recv_world(info: Dictionary) -> void:
	remote_name = String(info.get("name", "Хост"))
	remote_skin_png = info.get("skin", PackedByteArray())
	pending = info
	G.seed_value = int(info["seed"])
	G.mode = String(info["mode"])
	G.current_world = ""
	G.opts = info["opts"]
	joined_world.emit()
	get_tree().change_scene_to_file("res://scenes/game.tscn")


@rpc("any_peer", "call_remote", "unreliable")
func pos(p: Vector3, yaw: float, pitch: float) -> void:
	target_pos = p
	target_yaw = yaw
	target_pitch = pitch
	if avatar == null and game != null and (is_host == false or remote_skin_png.size() > 0):
		_make_avatar()


@rpc("any_peer", "call_remote", "reliable")
func block(x: int, y: int, z: int, id: int) -> void:
	if game == null:
		return
	var w: World = game.world
	var key := Vector2i(x >> 4, z >> 4)
	if w.chunks.has(key):
		w.applying_remote = true
		w.set_block(x, y, z, id)
		w.applying_remote = false
	else:
		if not w.edits.has(key):
			w.edits[key] = {}
		w.edits[key][Vector3i(x, y, z)] = id


@rpc("any_peer", "call_remote", "reliable")
func chat(text: String, from: String) -> void:
	if game != null:
		game.hud.say("<%s> %s" % [from, text])


@rpc("authority", "call_remote", "reliable")
func sync_time(tod: float, weather: int) -> void:
	if game != null:
		game.tod = tod
		game.weather.state = weather
		game.weather.timer = 120.0


@rpc("any_peer", "call_remote", "unreliable_ordered")
func voice(data: PackedByteArray, rate: int) -> void:
	_play_voice(data, rate)


# ---------------------------------------------------------------- игра
func attach_game(g) -> void:
	game = g
	if not g.world.edited.is_connected(_on_local_edit):
		g.world.edited.connect(_on_local_edit)
	if not is_host:
		_setup_mic()
		_make_avatar()


func _on_local_edit(x: int, y: int, z: int, id: int) -> void:
	if active and multiplayer.get_peers().size() > 0:
		rpc("block", x, y, z, id)


func send_chat(text: String) -> void:
	if active and multiplayer.get_peers().size() > 0:
		rpc("chat", text, my_name)


func _make_avatar() -> void:
	if game == null or avatar != null:
		return
	avatar = Node3D.new()
	model = SkinModel.new()
	avatar.add_child(model)
	var img := Image.new()
	if remote_skin_png.size() > 0 and img.load_png_from_buffer(remote_skin_png) == OK:
		img = PlayerSkin.normalize(img)
	else:
		img = PlayerSkin.default_image()
	model.build(img)
	tag = Label3D.new()
	tag.text = remote_name
	tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	tag.no_depth_test = true
	tag.pixel_size = 0.008
	tag.font_size = 56
	tag.outline_size = 14
	tag.position = Vector3(0, 2.35, 0)
	avatar.add_child(tag)
	avatar.position = target_pos
	game.add_child(avatar)


func _remove_avatar() -> void:
	if avatar != null and is_instance_valid(avatar):
		avatar.queue_free()
	avatar = null
	model = null
	tag = null


func _process(dt: float) -> void:
	if connecting_t >= 0.0:
		connecting_t += dt
		if connecting_t > 12.0:
			connecting_t = -1.0
			status.emit("Время ожидания вышло. Проверь IP и сеть.")
			close()
	if not active or game == null:
		return
	if multiplayer.get_peers().is_empty():
		return
	send_t += dt
	if send_t > 0.066:
		send_t = 0.0
		var p: Player = game.player
		rpc("pos", p.position, p.yaw, p.pitch)
	if is_host:
		sync_t += dt
		if sync_t > 4.0:
			sync_t = 0.0
			rpc("sync_time", game.tod, game.weather.state)
	if avatar != null and model != null and not model.parts.is_empty():
		var old := avatar.position
		avatar.position = avatar.position.lerp(target_pos, minf(1.0, dt * 12.0))
		var spd := Vector2(avatar.position.x - old.x, avatar.position.z - old.z).length() / maxf(dt, 0.001)
		avatar.rotation.y = lerp_angle(avatar.rotation.y, target_yaw, minf(1.0, dt * 12.0))
		var mv := clampf(spd / 4.0, 0.0, 1.0)
		walk_t += dt * (4.0 + spd * 1.6)
		model.pose(walk_t, mv)
		model.parts["head"].rotation.x = target_pitch
		remote_talk = maxf(0.0, remote_talk - dt)
		tag.modulate = Color(0.6, 1.0, 0.6) if remote_talk > 0.0 else Color.WHITE
		tag.text = ("🔊 " if remote_talk > 0.0 else "") + remote_name
	_process_mic(dt)


# ---------------------------------------------------------------- голос
func _setup_mic() -> void:
	if mic_player != null:
		return
	if OS.get_name() == "Android":
		OS.request_permission("RECORD_AUDIO")
	var bi := AudioServer.get_bus_index("VoiceMic")
	if bi < 0:
		AudioServer.add_bus()
		bi = AudioServer.bus_count - 1
		AudioServer.set_bus_name(bi, "VoiceMic")
		capture = AudioEffectCapture.new()
		AudioServer.add_bus_effect(bi, capture)
		AudioServer.set_bus_volume_db(bi, -80.0)
	else:
		capture = AudioServer.get_bus_effect(bi, 0) as AudioEffectCapture
	mic_player = AudioStreamPlayer.new()
	mic_player.stream = AudioStreamMicrophone.new()
	mic_player.bus = "VoiceMic"
	add_child(mic_player)
	mic_player.play()


func _stop_mic() -> void:
	if mic_player != null:
		mic_player.queue_free()
		mic_player = null
	capture = null


func _process_mic(dt: float) -> void:
	if capture == null or not mic_on:
		if capture != null:
			capture.clear_buffer()
		return
	var avail := capture.get_frames_available()
	if avail <= 0:
		return
	var buf := capture.get_buffer(avail)
	var rate := int(AudioServer.get_mix_rate() / VOICE_DIV)
	var peak := 0.0
	var i := 0
	var n := buf.size()
	while i + VOICE_DIV <= n:
		var acc := 0.0
		for k in VOICE_DIV:
			acc += (buf[i + k].x + buf[i + k].y) * 0.5
		acc /= VOICE_DIV
		peak = maxf(peak, absf(acc))
		var s := clampi(int(acc * 32000.0 * 2.0), -32768, 32767)
		voice_accum.append(s & 0xff)
		voice_accum.append((s >> 8) & 0xff)
		i += VOICE_DIV
	if peak > 0.02:
		talk_hold = 0.35
	talk_hold = maxf(0.0, talk_hold - dt)
	var chunk := int(rate * 0.04) * 2
	while voice_accum.size() >= chunk:
		var pk := voice_accum.slice(0, chunk)
		voice_accum = voice_accum.slice(chunk)
		if talk_hold > 0.0 and not multiplayer.get_peers().is_empty():
			rpc("voice", pk, rate)


func _play_voice(data: PackedByteArray, rate: int) -> void:
	if voice_player == null or voice_rate != rate:
		if voice_player != null:
			voice_player.queue_free()
		voice_player = AudioStreamPlayer.new()
		var gen := AudioStreamGenerator.new()
		gen.mix_rate = rate
		gen.buffer_length = 0.5
		voice_player.stream = gen
		voice_player.volume_db = 4.0
		add_child(voice_player)
		voice_player.play()
		voice_pb = voice_player.get_stream_playback()
		voice_rate = rate
	remote_talk = 0.4
	var now := Time.get_ticks_msec() / 1000.0
	var frames := PackedVector2Array()
	var cnt := data.size() / 2
	if now - last_voice_t > 0.5:
		for z in int(rate * 0.05):
			frames.append(Vector2.ZERO)
	last_voice_t = now
	for k in cnt:
		var v := int(data[k * 2]) | (int(data[k * 2 + 1]) << 8)
		if v >= 32768:
			v -= 65536
		var f := float(v) / 32768.0
		frames.append(Vector2(f, f))
	if voice_pb != null and voice_pb.get_frames_available() >= frames.size():
		voice_pb.push_buffer(frames)
