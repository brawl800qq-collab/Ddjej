class_name Loot
extends RefCounted
## Таблицы добычи для сундуков (случайно, как в майнкрафте): [id, мин, макс, вес]

const VILLAGE := [
	[155, 1, 4, 12], [153, 1, 5, 12], [154, 1, 4, 9], [116, 1, 3, 7], [111, 1, 2, 4],
	[110, 1, 4, 5], [112, 1, 2, 2], [151, 1, 2, 2], [7, 2, 6, 5], [5, 1, 3, 3],
	[115, 1, 2, 3], [32, 2, 6, 3], [53, 1, 2, 2], [150, 1, 3, 2], [113, 1, 1, 1],
	[105, 1, 1, 1], [100, 1, 4, 3],
]
const MINE := [
	[111, 1, 4, 10], [110, 2, 8, 12], [112, 1, 3, 5], [152, 2, 6, 6], [150, 1, 4, 5],
	[113, 1, 2, 2], [151, 1, 1, 1], [155, 1, 3, 6], [32, 3, 8, 8], [105, 1, 1, 3],
	[117, 1, 1, 1], [7, 3, 8, 4], [100, 2, 6, 5],
]


static func roll(rng: RandomNumberGenerator, table: Array, min_rolls: int, max_rolls: int) -> Array:
	var slots := []
	for i in 27:
		slots.append([0, 0, 0])
	var total := 0.0
	for e in table:
		total += float(e[3])
	var rolls := rng.randi_range(min_rolls, max_rolls)
	for r in rolls:
		var pick := rng.randf() * total
		var chosen: Array = table[0]
		for e in table:
			pick -= float(e[3])
			if pick <= 0.0:
				chosen = e
				break
		var n := rng.randi_range(int(chosen[1]), int(chosen[2]))
		var si := rng.randi() % 27
		var tries := 0
		while int(slots[si][0]) != 0 and tries < 27:
			si = (si + 1) % 27
			tries += 1
		slots[si] = [int(chosen[0]), n, 0]
	return slots
