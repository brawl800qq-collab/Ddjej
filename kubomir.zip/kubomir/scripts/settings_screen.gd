class_name SettingsScreen
extends VBoxContainer
## Экран настроек: вкладки «Графика» и «Управление».

var content: VBoxContainer
var tab_buttons: Array = []
var _grab: ImageTexture


func _ready() -> void:
	add_theme_constant_override("separation", 10)
	_grab = _make_grabber()

	var tabs := HBoxContainer.new()
	tabs.add_theme_constant_override("separation", 8)
	add_child(tabs)
	var names := ["Графика", "Управление"]
	for i in names.size():
		var b := G.make_button(names[i], Vector2(200, 52), 22)
		b.toggle_mode = true
		b.pressed.connect(_show_tab.bind(i))
		tabs.add_child(b)
		tab_buttons.append(b)

	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	add_child(sc)
	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 14)
	sc.add_child(content)
	_show_tab(0)


func _make_grabber() -> ImageTexture:
	var s := 40
	var img := Image.create(s, s, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in s:
		for x in s:
			var d := Vector2(x - s * 0.5 + 0.5, y - s * 0.5 + 0.5).length()
			if d < 18.0:
				img.set_pixel(x, y, Color(0.95, 0.95, 0.98) if d < 14.0 else Color(0.2, 0.2, 0.25))
	return ImageTexture.create_from_image(img)


func _show_tab(i: int) -> void:
	for k in tab_buttons.size():
		tab_buttons[k].button_pressed = (k == i)
	for c in content.get_children():
		c.queue_free()
	if i == 0:
		_preset_row()
		_toggle("Авто-настройка под устройство", "auto_tune")
		_slider("Дальность прорисовки", "render_distance", 3, 12, 1, "%d чанков")
		_slider("Лимит FPS", "max_fps", 30, 120, 15, "%d")
		_choice("Сглаживание (MSAA)", "msaa", ["Выкл", "2x", "4x"])
		_slider("Масштаб разрешения", "res_scale", 0.5, 1.0, 0.05, "%.2f")
		_toggle("Мягкие тени в углах (AO)", "ao")
		_toggle("Объёмная листва", "leaf_depth")
		_choice("3D-трава и листья (после захода в мир)", "grass_level", ["Авто", "Выкл", "Низкая", "Средняя", "Высокая", "Ультра"])
		_choice("Качество текстур", "tex_quality", ["Классика 16px", "Высокое 1K", "Ультра 2K"])
		_choice("Тени", "shadows", ["Выкл", "Средние", "Высокие"])
		_toggle("Свечение (Glow)", "glow")
		_choice("Качество воды", "water_q", ["Низкое (плоская)", "Среднее (волны)", "Высокое (волны+пена)"])
		_toggle("Облака", "clouds")
		_toggle("Показывать FPS", "show_fps")
	else:
		_choice("Схема управления", "scheme", ["Жесты (как Bedrock)", "Кнопки"])
		_slider("Чувствительность камеры", "sens", 0.3, 2.5, 0.05, "%.2f")
		_slider("Размер кнопок", "btn_scale", 0.7, 1.4, 0.05, "%.2f")
		_slider("Прозрачность интерфейса", "hud_alpha", 0.3, 1.0, 0.05, "%.2f")
		_toggle("Плавающий джойстик", "floating_joy")
		_toggle("Режим левши", "lefty")
		_toggle("Авто-прыжок", "autojump")


func _row(title: String) -> HBoxContainer:
	var r := HBoxContainer.new()
	r.add_theme_constant_override("separation", 16)
	r.custom_minimum_size = Vector2(0, 52)
	var l := G.make_label(title, 22)
	l.custom_minimum_size = Vector2(330, 0)
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	r.add_child(l)
	content.add_child(r)
	return r


func _slider(title: String, key: String, mn: float, mx: float, step: float, fmt: String) -> void:
	var r := _row(title)
	var s := HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = step
	s.value = float(G.get(key))
	s.custom_minimum_size = Vector2(300, 44)
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.add_theme_icon_override("grabber", _grab)
	s.add_theme_icon_override("grabber_highlight", _grab)
	s.add_theme_icon_override("grabber_disabled", _grab)
	var bg := StyleBoxFlat.new()
	bg.bg_color = Color(0.05, 0.05, 0.07)
	bg.set_corner_radius_all(5)
	bg.content_margin_top = 6
	bg.content_margin_bottom = 6
	s.add_theme_stylebox_override("slider", bg)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.45, 0.8, 0.35)
	fill.set_corner_radius_all(5)
	fill.content_margin_top = 6
	fill.content_margin_bottom = 6
	s.add_theme_stylebox_override("grabber_area", fill)
	s.add_theme_stylebox_override("grabber_area_highlight", fill)
	r.add_child(s)
	var is_int := step >= 1.0
	var val := G.make_label(fmt % (int(s.value) if is_int else s.value), 22, Color(0.8, 1.0, 0.7))
	val.custom_minimum_size = Vector2(130, 0)
	val.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	r.add_child(val)
	s.value_changed.connect(func(v: float):
		if is_int:
			G.set(key, int(v))
		else:
			G.set(key, v)
		val.text = fmt % (int(v) if is_int else v)
		G.settings_changed.emit())
	s.drag_ended.connect(func(_c: bool): G.changed())


func _toggle(title: String, key: String) -> void:
	var r := _row(title)
	var b := G.make_button("", Vector2(150, 48), 22)
	b.toggle_mode = true
	b.button_pressed = bool(G.get(key))
	b.text = "Вкл" if b.button_pressed else "Выкл"
	b.toggled.connect(func(on: bool):
		G.set(key, on)
		b.text = "Вкл" if on else "Выкл"
		G.changed())
	r.add_child(b)


func _preset_row() -> void:
	var r := _row("Пресет графики")
	var names := ["Слабый телефон", "Мощный телефон"]
	for i in 2:
		var b := G.make_button(names[i], Vector2(240, 48), 20)
		b.pressed.connect(func():
			G.apply_preset(i)
			b.text = "Применено ✓")
		r.add_child(b)


func _choice(title: String, key: String, options: Array) -> void:
	var r := _row(title)
	var b := G.make_button(options[int(G.get(key)) % options.size()], Vector2(300, 48), 22)
	b.pressed.connect(func():
		var v := (int(G.get(key)) + 1) % options.size()
		G.set(key, v)
		b.text = options[v]
		G.changed())
	r.add_child(b)
