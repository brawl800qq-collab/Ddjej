class_name InventoryUI
extends Control
## Инвентарь персонажа: броня, сетка предметов, крафт (с верстаком/печью) и креативный каталог.

signal closed

const SLOT := 50.0

var player: Player
var station := 0           # 0 — карманный крафт, 1 — верстак, 2 — печь
var picked := -1
var inv_slots: Array = []
var armor_slots: Array = []
var title_label: Label
var right_box: VBoxContainer
var action_bar: HBoxContainer
var action_label: Label
var equip_btn: Button
var char_view: CharacterView
var recipe_list: VBoxContainer
var recipe_scroll: ScrollContainer
var chest: Array = []
var chest_slots: Array = []


class CharacterView extends Control:
	var player: Player
	var tex: ImageTexture
	var skin_ver := -1

	func _init() -> void:
		custom_minimum_size = Vector2(130, 250)
		mouse_filter = Control.MOUSE_FILTER_IGNORE

	func _col(slot: int) -> Color:
		var id: int = player.armor[slot]
		if id == 0:
			return Color(0, 0, 0, 0)
		return G.held_info(id).get("col", Color(0.7, 0.7, 0.7))

	func _part(r: Rect2i, dst: Rect2) -> void:
		draw_texture_rect_region(tex, dst, Rect2(r))

	func _arm(c: Color, dst: Rect2, k := 1.0) -> void:
		if c.a > 0.0:
			draw_rect(dst, Color(c.r * k, c.g * k, c.b * k, 1.0))
			draw_rect(dst, Color(0, 0, 0, 0.5), false, 2.0)

	func _draw() -> void:
		if player == null:
			return
		if tex == null or skin_ver != PlayerSkin.version:
			skin_ver = PlayerSkin.version
			tex = ImageTexture.create_from_image(PlayerSkin.current())
		var s := 7.0
		var ox := (size.x - 16.0 * s) * 0.5
		var oy := 6.0
		draw_rect(Rect2(ox + 1 * s, oy + 32 * s + 2, 14 * s, 6), Color(0, 0, 0, 0.3))
		# ноги
		_part(Rect2i(4, 20, 4, 12), Rect2(ox + 4 * s, oy + 20 * s, 4 * s, 12 * s))
		_part(Rect2i(20, 52, 4, 12), Rect2(ox + 8 * s, oy + 20 * s, 4 * s, 12 * s))
		_part(Rect2i(4, 36, 4, 12), Rect2(ox + 4 * s, oy + 20 * s, 4 * s, 12 * s))
		_part(Rect2i(4, 52, 4, 12), Rect2(ox + 8 * s, oy + 20 * s, 4 * s, 12 * s))
		# тело и руки
		_part(Rect2i(20, 20, 8, 12), Rect2(ox + 4 * s, oy + 8 * s, 8 * s, 12 * s))
		_part(Rect2i(20, 36, 8, 12), Rect2(ox + 4 * s, oy + 8 * s, 8 * s, 12 * s))
		_part(Rect2i(44, 20, 4, 12), Rect2(ox + 0 * s, oy + 8 * s, 4 * s, 12 * s))
		_part(Rect2i(36, 52, 4, 12), Rect2(ox + 12 * s, oy + 8 * s, 4 * s, 12 * s))
		_part(Rect2i(44, 36, 4, 12), Rect2(ox + 0 * s, oy + 8 * s, 4 * s, 12 * s))
		_part(Rect2i(52, 52, 4, 12), Rect2(ox + 12 * s, oy + 8 * s, 4 * s, 12 * s))
		# голова
		_part(Rect2i(8, 8, 8, 8), Rect2(ox + 4 * s, oy, 8 * s, 8 * s))
		_part(Rect2i(40, 8, 8, 8), Rect2(ox + 4 * s, oy, 8 * s, 8 * s))
		# броня поверх
		var b := _col(3)
		var l := _col(2)
		var c := _col(1)
		var h := _col(0)
		_arm(b, Rect2(ox + 4 * s, oy + 28 * s, 4 * s, 4 * s))
		_arm(b, Rect2(ox + 8 * s, oy + 28 * s, 4 * s, 4 * s), 0.85)
		_arm(l, Rect2(ox + 4 * s, oy + 20 * s, 4 * s, 8 * s))
		_arm(l, Rect2(ox + 8 * s, oy + 20 * s, 4 * s, 8 * s), 0.85)
		_arm(c, Rect2(ox + 4 * s, oy + 8 * s, 8 * s, 12 * s))
		_arm(c, Rect2(ox + 0 * s, oy + 8 * s, 4 * s, 8 * s), 0.9)
		_arm(c, Rect2(ox + 12 * s, oy + 8 * s, 4 * s, 8 * s), 0.9)
		if h.a > 0.0:
			_arm(h, Rect2(ox + 4 * s, oy, 8 * s, 4 * s))
			_arm(h, Rect2(ox + 4 * s, oy + 4 * s, 2 * s, 4 * s), 0.9)
			_arm(h, Rect2(ox + 10 * s, oy + 4 * s, 2 * s, 4 * s), 0.9)
			draw_rect(Rect2(ox + 6 * s, oy + 4 * s, 4 * s, 1 * s), Color(0.05, 0.05, 0.08))
		for r in [Rect2(ox + 4 * s, oy, 8 * s, 8 * s), Rect2(ox + 4 * s, oy + 8 * s, 8 * s, 12 * s), Rect2(ox, oy + 8 * s, 4 * s, 12 * s), Rect2(ox + 12 * s, oy + 8 * s, 4 * s, 12 * s), Rect2(ox + 4 * s, oy + 20 * s, 8 * s, 12 * s)]:
			draw_rect(r, Color(0, 0, 0, 0.4), false, 2.0)


func setup(p: Player) -> void:
	player = p
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	player.inv_changed.connect(_on_changed)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.55)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(cc)
	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", G.panel_style(Color(0.14, 0.15, 0.19, 0.97), Color(0.03, 0.03, 0.04)))
	cc.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	panel.add_child(root)

	var top := HBoxContainer.new()
	root.add_child(top)
	title_label = G.make_label("Инвентарь", 28, Color(0.85, 1.0, 0.7))
	title_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(title_label)

	var cols := HBoxContainer.new()
	cols.add_theme_constant_override("separation", 18)
	root.add_child(cols)

	# ---- персонаж и броня ----
	var left := HBoxContainer.new()
	left.add_theme_constant_override("separation", 6)
	cols.add_child(left)
	char_view = CharacterView.new()
	char_view.player = player
	left.add_child(char_view)
	var av := VBoxContainer.new()
	av.add_theme_constant_override("separation", 4)
	left.add_child(av)
	for i in 4:
		var sv := HudW.SlotView.new()
		sv.custom_minimum_size = Vector2(SLOT, SLOT)
		sv.index = i
		sv.getter = func(k: int): return [player.armor[k], 1 if int(player.armor[k]) != 0 else 0, player.armor_wear[k]]
		sv.tapped.connect(_on_armor_tap)
		av.add_child(sv)
		armor_slots.append(sv)

	# ---- сетка предметов ----
	var mid := VBoxContainer.new()
	mid.add_theme_constant_override("separation", 6)
	cols.add_child(mid)
	for row in 3:
		var hb := HBoxContainer.new()
		hb.add_theme_constant_override("separation", 4)
		mid.add_child(hb)
		for c in 9:
			hb.add_child(_make_slot(9 + row * 9 + c))
	var sep := Control.new()
	sep.custom_minimum_size = Vector2(0, 8)
	mid.add_child(sep)
	var hb2 := HBoxContainer.new()
	hb2.add_theme_constant_override("separation", 4)
	mid.add_child(hb2)
	for c in 9:
		hb2.add_child(_make_slot(c))
	var gap2 := Control.new()
	gap2.custom_minimum_size = Vector2(6, 0)
	hb2.add_child(gap2)
	var x := G.make_button("✕", Vector2(SLOT + 14, SLOT), 26)
	x.pressed.connect(close)
	hb2.add_child(x)

	action_bar = HBoxContainer.new()
	action_bar.add_theme_constant_override("separation", 6)
	action_bar.visible = false
	mid.add_child(action_bar)
	action_label = G.make_label("", 18)
	action_label.custom_minimum_size = Vector2(150, 0)
	action_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	action_bar.add_child(action_label)
	equip_btn = G.make_button("Надеть", Vector2(100, 44), 18)
	equip_btn.pressed.connect(_equip_picked)
	action_bar.add_child(equip_btn)
	var d1 := G.make_button("Бросить 1", Vector2(110, 44), 18)
	d1.pressed.connect(func(): _drop_picked(false))
	action_bar.add_child(d1)
	var d2 := G.make_button("Все", Vector2(70, 44), 18)
	d2.pressed.connect(func(): _drop_picked(true))
	action_bar.add_child(d2)

	# ---- крафт / креатив ----
	right_box = VBoxContainer.new()
	right_box.custom_minimum_size = Vector2(390, 0)
	right_box.add_theme_constant_override("separation", 6)
	cols.add_child(right_box)


func _make_slot(i: int) -> HudW.SlotView:
	var sv := HudW.SlotView.new()
	sv.custom_minimum_size = Vector2(SLOT, SLOT)
	sv.index = i
	sv.getter = func(k: int): return player.inv[k]
	sv.tapped.connect(_on_slot)
	inv_slots.append(sv)
	return sv


# ---------------- открытие ----------------
func open(st: int) -> void:
	station = st
	picked = -1
	visible = true
	match st:
		1:
			title_label.text = "Верстак"
		2:
			title_label.text = "Печь"
		3:
			title_label.text = "Сундук"
		_:
			title_label.text = "Инвентарь"
	_build_right()
	_refresh()


func open_chest(arr: Array) -> void:
	chest = arr
	open(3)


func close() -> void:
	picked = -1
	visible = false
	closed.emit()


func _build_right() -> void:
	for c in right_box.get_children():
		c.queue_free()
	chest_slots.clear()
	if station == 3:
		recipe_list = null
		recipe_scroll = null
		right_box.add_child(G.make_label("Сундук (нажми на предмет — переложить)", 18, Color(0.9, 0.9, 0.6)))
		var gc3 := GridContainer.new()
		gc3.columns = 6
		gc3.add_theme_constant_override("h_separation", 4)
		gc3.add_theme_constant_override("v_separation", 4)
		right_box.add_child(gc3)
		for k in 27:
			var sv3 := HudW.SlotView.new()
			sv3.custom_minimum_size = Vector2(SLOT, SLOT)
			sv3.index = k
			sv3.getter = func(j: int): return chest[j]
			sv3.tapped.connect(_on_chest_slot)
			gc3.add_child(sv3)
			chest_slots.append(sv3)
		return
	if G.mode == "creative":
		right_box.add_child(G.make_label("Все предметы", 22, Color(0.9, 0.9, 0.6)))
		var sc := ScrollContainer.new()
		sc.custom_minimum_size = Vector2(0, 360)
		sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		right_box.add_child(sc)
		var gc := GridContainer.new()
		gc.columns = 6
		gc.add_theme_constant_override("h_separation", 4)
		gc.add_theme_constant_override("v_separation", 4)
		sc.add_child(gc)
		for k in G.CREATIVE_ITEMS.size():
			var sv := HudW.SlotView.new()
			sv.custom_minimum_size = Vector2(SLOT, SLOT)
			sv.index = k
			sv.getter = func(j: int): return [G.CREATIVE_ITEMS[j], 1]
			sv.tapped.connect(_on_creative_tap)
			gc.add_child(sv)
		return
	var head := "Крафт"
	if station == 1:
		head = "Крафт (верстак)"
	elif station == 2:
		head = "Плавка (печь)"
	right_box.add_child(G.make_label(head, 22, Color(0.9, 0.9, 0.6)))
	recipe_scroll = ScrollContainer.new()
	recipe_scroll.custom_minimum_size = Vector2(0, 360)
	recipe_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	right_box.add_child(recipe_scroll)
	recipe_list = VBoxContainer.new()
	recipe_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	recipe_list.add_theme_constant_override("separation", 6)
	recipe_scroll.add_child(recipe_list)
	_fill_recipes()


func _fill_recipes() -> void:
	if recipe_list == null:
		return
	var keep := recipe_scroll.scroll_vertical
	for c in recipe_list.get_children():
		c.queue_free()
	var ok_list := []
	var no_list := []
	for r in G.RECIPES:
		var st: int = r["st"]
		var avail := st == 0 or st == station
		var can := avail and player.can_craft(r)
		if can:
			ok_list.append(r)
		else:
			no_list.append(r)
	for r in ok_list:
		recipe_list.add_child(_recipe_row(r, true, ""))
	for r in no_list:
		var st2: int = r["st"]
		var hint := ""
		if st2 == 1 and station != 1:
			hint = "нужен верстак"
		elif st2 == 2 and station != 2:
			hint = "нужна печь"
		recipe_list.add_child(_recipe_row(r, false, hint))
	recipe_scroll.set_deferred("scroll_vertical", keep)


func _recipe_row(r: Dictionary, can: bool, hint: String) -> Control:
	var pc := PanelContainer.new()
	var bg := Color(0.2, 0.28, 0.2, 0.95) if can else Color(0.17, 0.17, 0.2, 0.9)
	pc.add_theme_stylebox_override("panel", G.panel_style(bg, Color(0.05, 0.05, 0.06)))
	(pc.get_theme_stylebox("panel") as StyleBoxFlat).set_content_margin_all(6)
	var h := HBoxContainer.new()
	h.add_theme_constant_override("separation", 8)
	pc.add_child(h)
	var ic := TextureRect.new()
	ic.texture = G.icon(int(r["out"]))
	ic.custom_minimum_size = Vector2(42, 42)
	ic.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	ic.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	h.add_child(ic)
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(v)
	var nm := G.item_name(int(r["out"]))
	if int(r["n"]) > 1:
		nm += " ×%d" % int(r["n"])
	v.add_child(G.make_label(nm, 18))
	var parts := []
	var need: Dictionary = r["in"]
	for id in need:
		parts.append("%s ×%d" % [G.item_name(id), int(need[id])])
	var txt := ", ".join(parts)
	if hint != "":
		txt = hint
	var il := G.make_label(txt, 14, Color(0.78, 0.8, 0.85) if hint == "" else Color(1.0, 0.7, 0.5))
	il.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	il.custom_minimum_size = Vector2(190, 0)
	v.add_child(il)
	var b := G.make_button("Создать", Vector2(92, 44), 16)
	b.disabled = not can
	b.pressed.connect(func(): player.craft(r))
	h.add_child(b)
	return pc


# ---------------- действия ----------------
func _on_changed() -> void:
	if visible:
		_refresh()
		if G.mode != "creative":
			_fill_recipes()


func _refresh() -> void:
	for sv in inv_slots:
		sv.highlight = sv.index == player.sel
		sv.marked = sv.index == picked
		sv.queue_redraw()
	for sv in armor_slots:
		sv.queue_redraw()
	for sv in chest_slots:
		sv.queue_redraw()
	char_view.queue_redraw()
	if picked >= 0 and int(player.inv[picked][0]) != 0:
		var id := int(player.inv[picked][0])
		action_bar.visible = true
		action_label.text = G.item_name(id)
		equip_btn.visible = G.armor_slot(id) >= 0
	else:
		picked = -1
		action_bar.visible = false


func _on_chest_slot(k: int) -> void:
	var s: Array = chest[k]
	if int(s[0]) == 0:
		return
	var left := player.add_item(int(s[0]), int(s[1]), int(s[2]))
	if left <= 0:
		s[0] = 0
		s[1] = 0
		s[2] = 0
	else:
		s[1] = left
	_refresh()


func _store_in_chest(i: int) -> void:
	var s: Array = player.inv[i]
	if int(s[0]) == 0:
		return
	var ms := Player.max_stack(int(s[0]))
	for c in chest:
		if int(c[0]) == int(s[0]) and int(c[1]) < ms:
			var m := mini(ms - int(c[1]), int(s[1]))
			c[1] += m
			s[1] -= m
			if int(s[1]) <= 0:
				break
	if int(s[1]) > 0:
		for c2 in chest:
			if int(c2[0]) == 0:
				c2[0] = s[0]
				c2[1] = s[1]
				c2[2] = s[2]
				s[1] = 0
				break
	if int(s[1]) <= 0:
		s[0] = 0
		s[1] = 0
		s[2] = 0
	player.inv_changed.emit()
	player.refresh_hand()
	_refresh()


func _on_slot(i: int) -> void:
	if station == 3:
		_store_in_chest(i)
		return
	if picked == -1:
		if int(player.inv[i][0]) != 0:
			picked = i
		if i < 9:
			player.sel = i
			player.refresh_hand()
	elif picked == i:
		picked = -1
	else:
		_move(picked, i)
		picked = -1
	_refresh()


func _move(a: int, b: int) -> void:
	var sa: Array = player.inv[a]
	var sb: Array = player.inv[b]
	if sa[0] == sb[0] and sa[0] != 0 and Player.max_stack(int(sa[0])) > 1:
		var m := mini(int(sa[1]), Player.max_stack(int(sa[0])) - int(sb[1]))
		sb[1] += m
		sa[1] -= m
		if sa[1] <= 0:
			sa[0] = 0
			sa[1] = 0
	else:
		var t0 = sa[0]
		var t1 = sa[1]
		var t2 = sa[2]
		sa[0] = sb[0]
		sa[1] = sb[1]
		sa[2] = sb[2]
		sb[0] = t0
		sb[1] = t1
		sb[2] = t2
	player.inv_changed.emit()
	player.refresh_hand()


func _on_armor_tap(a: int) -> void:
	if int(player.armor[a]) != 0:
		player.unequip(a)
	elif picked >= 0 and G.armor_slot(int(player.inv[picked][0])) == a:
		_equip_picked()
	_refresh()


func _equip_picked() -> void:
	if picked < 0:
		return
	player.equip_from(picked)
	picked = -1
	_refresh()


func _drop_picked(all: bool) -> void:
	if picked < 0:
		return
	player.drop_slot(picked, all)
	if int(player.inv[picked][0]) == 0:
		picked = -1
	_refresh()


func _on_creative_tap(k: int) -> void:
	var id: int = G.CREATIVE_ITEMS[k]
	var n := Player.max_stack(id)
	player.add_item(id, n)
	_refresh()
